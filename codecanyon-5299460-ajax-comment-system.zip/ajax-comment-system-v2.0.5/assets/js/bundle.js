/**
 * Simple JavaScript Templating
 * http://ejohn.org/blog/javascript-micro-templating
 *
 * Copyright John Resig - http://ejohn.org
 * Released under the MIT License
 */
(function(){
   var cache = {};

    this.tmpl = function(str, data) {
        var fn = !/[^A-Za-z0-9_-]/.test(str) ?
            cache[str] = cache[str] || tmpl(document.getElementById(str).innerHTML) :
                new Function('obj',
                    "var p=[],print=function(){p.push.apply(p,arguments);};" +
                    "with(obj){p.push('" +
                    str
                        .replace(/[\r\t\n]/g, " ")
                        .replace(/'(?=[^%]*%})/g,"\t")
                        .split("'").join("\\'")
                        .split("\t").join("'")
                        .replace(/{%=(.+?)%}/g, "',$1,'")
                        .split("{%").join("');")
                        .split("%}").join("p.push('")
                    + "');}return p.join('');"
                );

        return data ? fn(data) : fn;
    };
})();

/**
 * Timeago is a jQuery plugin that makes it easy to support automatically
 * updating fuzzy timestamps (e.g. "4 minutes ago" or "about 1 day ago").
 *
 * @name timeago
 * @version 1.4.1
 * @requires jQuery v1.2.3+
 * @author Ryan McGeary
 * @license MIT License - http://www.opensource.org/licenses/mit-license.php
 *
 * For usage and examples, visit:
 * http://timeago.yarp.com/
 *
 * Copyright (c) 2008-2013, Ryan McGeary (ryan -[at]- mcgeary [*dot*] org)
 */

(function (factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['jquery'], factory);
  } else {
    // Browser globals
    factory(jQuery);
  }
}(function ($) {
  $.timeago = function(timestamp) {
    if (timestamp instanceof Date) {
      return inWords(timestamp);
    } else if (typeof timestamp === "string") {
      return inWords($.timeago.parse(timestamp));
    } else if (typeof timestamp === "number") {
      return inWords(new Date(timestamp));
    } else {
      return inWords($.timeago.datetime(timestamp));
    }
  };
  var $t = $.timeago;

  $.extend($.timeago, {
    settings: {
      refreshMillis: 60000,
      allowPast: true,
      allowFuture: false,
      localeTitle: false,
      cutoff: 0,
      strings: {
        prefixAgo: null,
        prefixFromNow: null,
        suffixAgo: "ago",
        suffixFromNow: "from now",
        inPast: 'any moment now',
        seconds: "less than a minute",
        minute: "about a minute",
        minutes: "%d minutes",
        hour: "about an hour",
        hours: "about %d hours",
        day: "a day",
        days: "%d days",
        month: "about a month",
        months: "%d months",
        year: "about a year",
        years: "%d years",
        wordSeparator: " ",
        numbers: []
      }
    },

    inWords: function(distanceMillis) {
      if(!this.settings.allowPast && ! this.settings.allowFuture) {
          throw 'timeago allowPast and allowFuture settings can not both be set to false.';
      }

      var $l = this.settings.strings;
      var prefix = $l.prefixAgo;
      var suffix = $l.suffixAgo;
      if (this.settings.allowFuture) {
        if (distanceMillis < 0) {
          prefix = $l.prefixFromNow;
          suffix = $l.suffixFromNow;
        }
      }

      if(!this.settings.allowPast && distanceMillis >= 0) {
        return this.settings.strings.inPast;
      }

      var seconds = Math.abs(distanceMillis) / 1000;
      var minutes = seconds / 60;
      var hours = minutes / 60;
      var days = hours / 24;
      var years = days / 365;

      function substitute(stringOrFunction, number) {
        var string = $.isFunction(stringOrFunction) ? stringOrFunction(number, distanceMillis) : stringOrFunction;
        var value = ($l.numbers && $l.numbers[number]) || number;
        return string.replace(/%d/i, value);
      }

      var words = seconds < 45 && substitute($l.seconds, Math.round(seconds)) ||
        seconds < 90 && substitute($l.minute, 1) ||
        minutes < 45 && substitute($l.minutes, Math.round(minutes)) ||
        minutes < 90 && substitute($l.hour, 1) ||
        hours < 24 && substitute($l.hours, Math.round(hours)) ||
        hours < 42 && substitute($l.day, 1) ||
        days < 30 && substitute($l.days, Math.round(days)) ||
        days < 45 && substitute($l.month, 1) ||
        days < 365 && substitute($l.months, Math.round(days / 30)) ||
        years < 1.5 && substitute($l.year, 1) ||
        substitute($l.years, Math.round(years));

      var separator = $l.wordSeparator || "";
      if ($l.wordSeparator === undefined) { separator = " "; }
      return $.trim([prefix, words, suffix].join(separator));
    },

    parse: function(iso8601) {
      var s = $.trim(iso8601);
      s = s.replace(/\.\d+/,""); // remove milliseconds
      s = s.replace(/-/,"/").replace(/-/,"/");
      s = s.replace(/T/," ").replace(/Z/," UTC");
      s = s.replace(/([\+\-]\d\d)\:?(\d\d)/," $1$2"); // -04:00 -> -0400
      s = s.replace(/([\+\-]\d\d)$/," $100"); // +09 -> +0900
      return new Date(s);
    },
    datetime: function(elem) {
      var iso8601 = $t.isTime(elem) ? $(elem).attr("datetime") : $(elem).attr("title");
      return $t.parse(iso8601);
    },
    isTime: function(elem) {
      // jQuery's `is()` doesn't play well with HTML5 in IE
      return $(elem).get(0).tagName.toLowerCase() === "time"; // $(elem).is("time");
    }
  });

  // functions that can be called via $(el).timeago('action')
  // init is default when no action is given
  // functions are called with context of a single element
  var functions = {
    init: function(){
      var refresh_el = $.proxy(refresh, this);
      refresh_el();
      var $s = $t.settings;
      if ($s.refreshMillis > 0) {
        this._timeagoInterval = setInterval(refresh_el, $s.refreshMillis);
      }
    },
    update: function(time){
      var parsedTime = $t.parse(time);
      $(this).data('timeago', { datetime: parsedTime });
      if($t.settings.localeTitle) $(this).attr("title", parsedTime.toLocaleString());
      refresh.apply(this);
    },
    updateFromDOM: function(){
      $(this).data('timeago', { datetime: $t.parse( $t.isTime(this) ? $(this).attr("datetime") : $(this).attr("title") ) });
      refresh.apply(this);
    },
    dispose: function () {
      if (this._timeagoInterval) {
        window.clearInterval(this._timeagoInterval);
        this._timeagoInterval = null;
      }
    }
  };

  $.fn.timeago = function(action, options) {
    var fn = action ? functions[action] : functions.init;
    if(!fn){
      throw new Error("Unknown function name '"+ action +"' for timeago");
    }
    // each over objects here and call the requested function
    this.each(function(){
      fn.call(this, options);
    });
    return this;
  };

  function refresh() {
    var data = prepareData(this);
    var $s = $t.settings;

    if (!isNaN(data.datetime)) {
      if ( $s.cutoff == 0 || Math.abs(distance(data.datetime)) < $s.cutoff) {
        $(this).text(inWords(data.datetime));
      }
    }
    return this;
  }

  function prepareData(element) {
    element = $(element);
    if (!element.data("timeago")) {
      element.data("timeago", { datetime: $t.datetime(element) });
      var text = $.trim(element.text());
      if ($t.settings.localeTitle) {
        element.attr("title", element.data('timeago').datetime.toLocaleString());
      } else if (text.length > 0 && !($t.isTime(element) && element.attr("title"))) {
        element.attr("title", text);
      }
    }
    return element.data("timeago");
  }

  function inWords(date) {
    return $t.inWords(distance(date));
  }

  function distance(date) {
    return (new Date().getTime() - date.getTime());
  }

  // fix for IE6 suckage
  document.createElement("abbr");
  document.createElement("time");
}));

/*!
	Autosize 3.0.8
	license: MIT
	http://www.jacklmoore.com/autosize
*/
!function(e,t){if("function"==typeof define&&define.amd)define(["exports","module"],t);else if("undefined"!=typeof exports&&"undefined"!=typeof module)t(exports,module);else{var o={exports:{}};t(o.exports,o),e.autosize=o.exports}}(this,function(e,t){"use strict";function o(e){function t(){var t=window.getComputedStyle(e,null);"vertical"===t.resize?e.style.resize="none":"both"===t.resize&&(e.style.resize="horizontal"),u="content-box"===t.boxSizing?-(parseFloat(t.paddingTop)+parseFloat(t.paddingBottom)):parseFloat(t.borderTopWidth)+parseFloat(t.borderBottomWidth),i()}function o(t){var o=e.style.width;e.style.width="0px",e.offsetWidth,e.style.width=o,v=t,l&&(e.style.overflowY=t),n()}function n(){var t=window.pageYOffset,o=document.body.scrollTop,n=e.style.height;e.style.height="auto";var i=e.scrollHeight+u;return 0===e.scrollHeight?void(e.style.height=n):(e.style.height=i+"px",document.documentElement.scrollTop=t,void(document.body.scrollTop=o))}function i(){var t=e.style.height;n();var i=window.getComputedStyle(e,null);if(i.height!==e.style.height?"visible"!==v&&o("visible"):"hidden"!==v&&o("hidden"),t!==e.style.height){var r=document.createEvent("Event");r.initEvent("autosize:resized",!0,!1),e.dispatchEvent(r)}}var r=void 0===arguments[1]?{}:arguments[1],d=r.setOverflowX,s=void 0===d?!0:d,a=r.setOverflowY,l=void 0===a?!0:a;if(e&&e.nodeName&&"TEXTAREA"===e.nodeName&&!e.hasAttribute("data-autosize-on")){var u=null,v="hidden",f=function(t){window.removeEventListener("resize",i),e.removeEventListener("input",i),e.removeEventListener("keyup",i),e.removeAttribute("data-autosize-on"),e.removeEventListener("autosize:destroy",f),Object.keys(t).forEach(function(o){e.style[o]=t[o]})}.bind(e,{height:e.style.height,resize:e.style.resize,overflowY:e.style.overflowY,overflowX:e.style.overflowX,wordWrap:e.style.wordWrap});e.addEventListener("autosize:destroy",f),"onpropertychange"in e&&"oninput"in e&&e.addEventListener("keyup",i),window.addEventListener("resize",i),e.addEventListener("input",i),e.addEventListener("autosize:update",i),e.setAttribute("data-autosize-on",!0),l&&(e.style.overflowY="hidden"),s&&(e.style.overflowX="hidden",e.style.wordWrap="break-word"),t()}}function n(e){if(e&&e.nodeName&&"TEXTAREA"===e.nodeName){var t=document.createEvent("Event");t.initEvent("autosize:destroy",!0,!1),e.dispatchEvent(t)}}function i(e){if(e&&e.nodeName&&"TEXTAREA"===e.nodeName){var t=document.createEvent("Event");t.initEvent("autosize:update",!0,!1),e.dispatchEvent(t)}}var r=null;"undefined"==typeof window||"function"!=typeof window.getComputedStyle?(r=function(e){return e},r.destroy=function(e){return e},r.update=function(e){return e}):(r=function(e,t){return e&&Array.prototype.forEach.call(e.length?e:[e],function(e){return o(e,t)}),e},r.destroy=function(e){return e&&Array.prototype.forEach.call(e.length?e:[e],n),e},r.update=function(e){return e&&Array.prototype.forEach.call(e.length?e:[e],i),e}),t.exports=r});
/* http://prismjs.com/download.html?themes=prism-okaidia&languages=markup+css+clike+javascript+bash+c+csharp+cpp+java+less+php+php-extras+sql */
var _self="undefined"!=typeof window?window:"undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?self:{},Prism=function(){var e=/\blang(?:uage)?-(?!\*)(\w+)\b/i,t=_self.Prism={util:{encode:function(e){return e instanceof n?new n(e.type,t.util.encode(e.content),e.alias):"Array"===t.util.type(e)?e.map(t.util.encode):e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/\u00a0/g," ")},type:function(e){return Object.prototype.toString.call(e).match(/\[object (\w+)\]/)[1]},clone:function(e){var n=t.util.type(e);switch(n){case"Object":var a={};for(var r in e)e.hasOwnProperty(r)&&(a[r]=t.util.clone(e[r]));return a;case"Array":return e.map&&e.map(function(e){return t.util.clone(e)})}return e}},languages:{extend:function(e,n){var a=t.util.clone(t.languages[e]);for(var r in n)a[r]=n[r];return a},insertBefore:function(e,n,a,r){r=r||t.languages;var i=r[e];if(2==arguments.length){a=arguments[1];for(var l in a)a.hasOwnProperty(l)&&(i[l]=a[l]);return i}var s={};for(var o in i)if(i.hasOwnProperty(o)){if(o==n)for(var l in a)a.hasOwnProperty(l)&&(s[l]=a[l]);s[o]=i[o]}return t.languages.DFS(t.languages,function(t,n){n===r[e]&&t!=e&&(this[t]=s)}),r[e]=s},DFS:function(e,n,a){for(var r in e)e.hasOwnProperty(r)&&(n.call(e,r,e[r],a||r),"Object"===t.util.type(e[r])?t.languages.DFS(e[r],n):"Array"===t.util.type(e[r])&&t.languages.DFS(e[r],n,r))}},highlightAll:function(e,n){for(var a,r=document.querySelectorAll('code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'),i=0;a=r[i++];)t.highlightElement(a,e===!0,n)},highlightElement:function(a,r,i){for(var l,s,o=a;o&&!e.test(o.className);)o=o.parentNode;if(o&&(l=(o.className.match(e)||[,""])[1],s=t.languages[l]),a.className=a.className.replace(e,"").replace(/\s+/g," ")+" language-"+l,o=a.parentNode,/pre/i.test(o.nodeName)&&(o.className=o.className.replace(e,"").replace(/\s+/g," ")+" language-"+l),s){var u=a.textContent;if(u){u=u.replace(/^(?:\r?\n|\r)/,"");var g={element:a,language:l,grammar:s,code:u};if(t.hooks.run("before-highlight",g),r&&_self.Worker){var c=new Worker(t.filename);c.onmessage=function(e){g.highlightedCode=n.stringify(JSON.parse(e.data),l),t.hooks.run("before-insert",g),g.element.innerHTML=g.highlightedCode,i&&i.call(g.element),t.hooks.run("after-highlight",g)},c.postMessage(JSON.stringify({language:g.language,code:g.code}))}else g.highlightedCode=t.highlight(g.code,g.grammar,g.language),t.hooks.run("before-insert",g),g.element.innerHTML=g.highlightedCode,i&&i.call(a),t.hooks.run("after-highlight",g)}}},highlight:function(e,a,r){var i=t.tokenize(e,a);return n.stringify(t.util.encode(i),r)},tokenize:function(e,n){var a=t.Token,r=[e],i=n.rest;if(i){for(var l in i)n[l]=i[l];delete n.rest}e:for(var l in n)if(n.hasOwnProperty(l)&&n[l]){var s=n[l];s="Array"===t.util.type(s)?s:[s];for(var o=0;o<s.length;++o){var u=s[o],g=u.inside,c=!!u.lookbehind,f=0,h=u.alias;u=u.pattern||u;for(var p=0;p<r.length;p++){var d=r[p];if(r.length>e.length)break e;if(!(d instanceof a)){u.lastIndex=0;var m=u.exec(d);if(m){c&&(f=m[1].length);var y=m.index-1+f,m=m[0].slice(f),v=m.length,k=y+v,b=d.slice(0,y+1),w=d.slice(k+1),N=[p,1];b&&N.push(b);var O=new a(l,g?t.tokenize(m,g):m,h);N.push(O),w&&N.push(w),Array.prototype.splice.apply(r,N)}}}}}return r},hooks:{all:{},add:function(e,n){var a=t.hooks.all;a[e]=a[e]||[],a[e].push(n)},run:function(e,n){var a=t.hooks.all[e];if(a&&a.length)for(var r,i=0;r=a[i++];)r(n)}}},n=t.Token=function(e,t,n){this.type=e,this.content=t,this.alias=n};if(n.stringify=function(e,a,r){if("string"==typeof e)return e;if("Array"===t.util.type(e))return e.map(function(t){return n.stringify(t,a,e)}).join("");var i={type:e.type,content:n.stringify(e.content,a,r),tag:"span",classes:["token",e.type],attributes:{},language:a,parent:r};if("comment"==i.type&&(i.attributes.spellcheck="true"),e.alias){var l="Array"===t.util.type(e.alias)?e.alias:[e.alias];Array.prototype.push.apply(i.classes,l)}t.hooks.run("wrap",i);var s="";for(var o in i.attributes)s+=o+'="'+(i.attributes[o]||"")+'"';return"<"+i.tag+' class="'+i.classes.join(" ")+'" '+s+">"+i.content+"</"+i.tag+">"},!_self.document)return _self.addEventListener?(_self.addEventListener("message",function(e){var n=JSON.parse(e.data),a=n.language,r=n.code;_self.postMessage(JSON.stringify(t.util.encode(t.tokenize(r,t.languages[a])))),_self.close()},!1),_self.Prism):_self.Prism;var a=document.getElementsByTagName("script");return a=a[a.length-1],a&&(t.filename=a.src,document.addEventListener&&!a.hasAttribute("data-manual")&&document.addEventListener("DOMContentLoaded",t.highlightAll)),_self.Prism}();"undefined"!=typeof module&&module.exports&&(module.exports=Prism);;
Prism.languages.markup={comment:/<!--[\w\W]*?-->/,prolog:/<\?[\w\W]+?\?>/,doctype:/<!DOCTYPE[\w\W]+?>/,cdata:/<!\[CDATA\[[\w\W]*?]]>/i,tag:{pattern:/<\/?[^\s>\/]+(?:\s+[^\s>\/=]+(?:=(?:("|')(?:\\\1|\\?(?!\1)[\w\W])*\1|[^\s'">=]+))?)*\s*\/?>/i,inside:{tag:{pattern:/^<\/?[^\s>\/]+/i,inside:{punctuation:/^<\/?/,namespace:/^[^\s>\/:]+:/}},"attr-value":{pattern:/=(?:('|")[\w\W]*?(\1)|[^\s>]+)/i,inside:{punctuation:/[=>"']/}},punctuation:/\/?>/,"attr-name":{pattern:/[^\s>\/]+/,inside:{namespace:/^[^\s>\/:]+:/}}}},entity:/&#?[\da-z]{1,8};/i},Prism.hooks.add("wrap",function(t){"entity"===t.type&&(t.attributes.title=t.content.replace(/&amp;/,"&"))});;
Prism.languages.css={comment:/\/\*[\w\W]*?\*\//,atrule:{pattern:/@[\w-]+?.*?(;|(?=\s*\{))/i,inside:{rule:/@[\w-]+/}},url:/url\((?:(["'])(\\(?:\r\n|[\w\W])|(?!\1)[^\\\r\n])*\1|.*?)\)/i,selector:/[^\{\}\s][^\{\};]*?(?=\s*\{)/,string:/("|')(\\(?:\r\n|[\w\W])|(?!\1)[^\\\r\n])*\1/,property:/(\b|\B)[\w-]+(?=\s*:)/i,important:/\B!important\b/i,"function":/[-a-z0-9]+(?=\()/i,punctuation:/[(){};:]/},Prism.languages.css.atrule.inside.rest=Prism.util.clone(Prism.languages.css),Prism.languages.markup&&(Prism.languages.insertBefore("markup","tag",{style:{pattern:/<style[\w\W]*?>[\w\W]*?<\/style>/i,inside:{tag:{pattern:/<style[\w\W]*?>|<\/style>/i,inside:Prism.languages.markup.tag.inside},rest:Prism.languages.css},alias:"language-css"}}),Prism.languages.insertBefore("inside","attr-value",{"style-attr":{pattern:/\s*style=("|').*?\1/i,inside:{"attr-name":{pattern:/^\s*style/i,inside:Prism.languages.markup.tag.inside},punctuation:/^\s*=\s*['"]|['"]\s*$/,"attr-value":{pattern:/.+/i,inside:Prism.languages.css}},alias:"language-css"}},Prism.languages.markup.tag));;
Prism.languages.clike={comment:[{pattern:/(^|[^\\])\/\*[\w\W]*?\*\//,lookbehind:!0},{pattern:/(^|[^\\:])\/\/.*/,lookbehind:!0}],string:/("|')(\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,"class-name":{pattern:/((?:(?:class|interface|extends|implements|trait|instanceof|new)\s+)|(?:catch\s+\())[a-z0-9_\.\\]+/i,lookbehind:!0,inside:{punctuation:/(\.|\\)/}},keyword:/\b(if|else|while|do|for|return|in|instanceof|function|new|try|throw|catch|finally|null|break|continue)\b/,"boolean":/\b(true|false)\b/,"function":/[a-z0-9_]+(?=\()/i,number:/\b-?(0x[\dA-Fa-f]+|\d*\.?\d+([Ee]-?\d+)?)\b/,operator:/[-+]{1,2}|!|<=?|>=?|={1,3}|&{1,2}|\|?\||\?|\*|\/|~|\^|%/,punctuation:/[{}[\];(),.:]/};;
Prism.languages.javascript=Prism.languages.extend("clike",{keyword:/\b(as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|false|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|true|try|typeof|var|void|while|with|yield)\b/,number:/\b-?(0x[\dA-Fa-f]+|0b[01]+|0o[0-7]+|\d*\.?\d+([Ee][+-]?\d+)?|NaN|Infinity)\b/,"function":/(?!\d)[a-z0-9_$]+(?=\()/i}),Prism.languages.insertBefore("javascript","keyword",{regex:{pattern:/(^|[^/])\/(?!\/)(\[.+?]|\\.|[^/\\\r\n])+\/[gimyu]{0,5}(?=\s*($|[\r\n,.;})]))/,lookbehind:!0}}),Prism.languages.insertBefore("javascript","class-name",{"template-string":{pattern:/`(?:\\`|\\?[^`])*`/,inside:{interpolation:{pattern:/\$\{[^}]+\}/,inside:{"interpolation-punctuation":{pattern:/^\$\{|\}$/,alias:"punctuation"},rest:Prism.languages.javascript}},string:/[\s\S]+/}}}),Prism.languages.markup&&Prism.languages.insertBefore("markup","tag",{script:{pattern:/<script[\w\W]*?>[\w\W]*?<\/script>/i,inside:{tag:{pattern:/<script[\w\W]*?>|<\/script>/i,inside:Prism.languages.markup.tag.inside},rest:Prism.languages.javascript},alias:"language-javascript"}});;
Prism.languages.bash=Prism.languages.extend("clike",{comment:{pattern:/(^|[^"{\\])#.*/,lookbehind:!0},string:{pattern:/("|')(\\?[\s\S])*?\1/,inside:{property:/\$([a-zA-Z0-9_#\?\-\*!@]+|\{[^\}]+\})/}},number:{pattern:/([^\w\.])-?(0x[\dA-Fa-f]+|\d*\.?\d+([Ee]-?\d+)?)\b/,lookbehind:!0},"function":/\b(?:alias|apropos|apt-get|aptitude|aspell|awk|basename|bash|bc|bg|builtin|bzip2|cal|cat|cd|cfdisk|chgrp|chmod|chown|chroot|chkconfig|cksum|clear|cmp|comm|command|cp|cron|crontab|csplit|cut|date|dc|dd|ddrescue|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|du|egrep|eject|enable|env|ethtool|eval|exec|expand|expect|export|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|getopts|git|grep|groupadd|groupdel|groupmod|groups|gzip|hash|head|help|hg|history|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|jobs|join|kill|killall|less|link|ln|locate|logname|logout|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|make|man|mkdir|mkfifo|mkisofs|mknod|more|most|mount|mtools|mtr|mv|mmv|nano|netstat|nice|nl|nohup|notify-send|nslookup|open|op|passwd|paste|pathchk|ping|pkill|popd|pr|printcap|printenv|printf|ps|pushd|pv|pwd|quota|quotacheck|quotactl|ram|rar|rcp|read|readarray|readonly|reboot|rename|renice|remsync|rev|rm|rmdir|rsync|screen|scp|sdiff|sed|seq|service|sftp|shift|shopt|shutdown|sleep|slocate|sort|source|split|ssh|stat|strace|su|sudo|sum|suspend|sync|tail|tar|tee|test|time|timeout|times|touch|top|traceroute|trap|tr|tsort|tty|type|ulimit|umask|umount|unalias|uname|unexpand|uniq|units|unrar|unshar|uptime|useradd|userdel|usermod|users|uuencode|uudecode|v|vdir|vi|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yes|zip)\b/,keyword:/\b(if|then|else|elif|fi|for|break|continue|while|in|case|function|select|do|done|until|echo|exit|return|set|declare)\b/}),Prism.languages.insertBefore("bash","keyword",{property:/\$([a-zA-Z0-9_#\?\-\*!@]+|\{[^}]+\})/}),Prism.languages.insertBefore("bash","comment",{important:/^#!\s*\/bin\/bash|^#!\s*\/bin\/sh/});;
Prism.languages.c=Prism.languages.extend("clike",{keyword:/\b(asm|typeof|inline|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|union|unsigned|void|volatile|while)\b/,operator:/\-[>-]?|\+\+?|!=?|<<?=?|>>?=?|==?|&&?|\|?\||[~^%?*\/]/}),Prism.languages.insertBefore("c","string",{macro:{pattern:/(^\s*)#\s*[a-z]+([^\r\n\\]|\\.|\\(?:\r\n?|\n))*/im,lookbehind:!0,alias:"property",inside:{string:{pattern:/(#\s*include\s*)(<.+?>|("|')(\\?.)+?\3)/,lookbehind:!0}}}}),delete Prism.languages.c["class-name"],delete Prism.languages.c["boolean"];;
Prism.languages.csharp=Prism.languages.extend("clike",{keyword:/\b(abstract|as|async|await|base|bool|break|byte|case|catch|char|checked|class|const|continue|decimal|default|delegate|do|double|else|enum|event|explicit|extern|false|finally|fixed|float|for|foreach|goto|if|implicit|in|int|interface|internal|is|lock|long|namespace|new|null|object|operator|out|override|params|private|protected|public|readonly|ref|return|sbyte|sealed|short|sizeof|stackalloc|static|string|struct|switch|this|throw|true|try|typeof|uint|ulong|unchecked|unsafe|ushort|using|virtual|void|volatile|while|add|alias|ascending|async|await|descending|dynamic|from|get|global|group|into|join|let|orderby|partial|remove|select|set|value|var|where|yield)\b/,string:[/@("|')(\1\1|\\\1|\\?(?!\1)[\s\S])*\1/,/("|')(\\?.)*?\1/],number:/\b-?(0x[\da-f]+|\d*\.?\d+)\b/i}),Prism.languages.insertBefore("csharp","keyword",{preprocessor:{pattern:/(^\s*)#.*/m,lookbehind:!0}});;
Prism.languages.cpp=Prism.languages.extend("c",{keyword:/\b(alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|class|compl|const|constexpr|const_cast|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|float|for|friend|goto|if|inline|int|long|mutable|namespace|new|noexcept|nullptr|operator|private|protected|public|register|reinterpret_cast|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/,"boolean":/\b(true|false)\b/,operator:/[-+]{1,2}|!=?|<{1,2}=?|>{1,2}=?|\->|:{1,2}|={1,2}|\^|~|%|&{1,2}|\|?\||\?|\*|\/|\b(and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/}),Prism.languages.insertBefore("cpp","keyword",{"class-name":{pattern:/(class\s+)[a-z0-9_]+/i,lookbehind:!0}});;
Prism.languages.java=Prism.languages.extend("clike",{keyword:/\b(abstract|continue|for|new|switch|assert|default|goto|package|synchronized|boolean|do|if|private|this|break|double|implements|protected|throw|byte|else|import|public|throws|case|enum|instanceof|return|transient|catch|extends|int|short|try|char|final|interface|static|void|class|finally|long|strictfp|volatile|const|float|native|super|while)\b/,number:/\b0b[01]+\b|\b0x[\da-f]*\.?[\da-fp\-]+\b|\b\d*\.?\d+[e]?[\d]*[df]\b|\b\d*\.?\d+\b/i,operator:{pattern:/(^|[^\.])(?:\+=|\+\+?|-=|--?|!=?|<{1,2}=?|>{1,3}=?|==?|&=|&&?|\|=|\|\|?|\?|\*=?|\/=?|%=?|\^=?|:|~)/m,lookbehind:!0}});;
Prism.languages.less=Prism.languages.extend("css",{comment:[/\/\*[\w\W]*?\*\//,{pattern:/(^|[^\\])\/\/.*/,lookbehind:!0}],atrule:{pattern:/@[\w-]+?(?:\([^{}]+\)|[^(){};])*?(?=\s*\{)/i,inside:{punctuation:/[:()]/}},selector:{pattern:/(?:@\{[\w-]+\}|[^{};\s@])(?:@\{[\w-]+\}|\([^{}]*\)|[^{};@])*?(?=\s*\{)/,inside:{variable:/@+[\w-]+/}},property:/(\b|\B)(?:@\{[\w-]+\}|[\w-])+(?:\+_?)?(?=\s*:)/i,punctuation:/[{}();:,]/,operator:/[+\-*\/]/}),Prism.languages.insertBefore("less","punctuation",{"function":Prism.languages.less.function}),Prism.languages.insertBefore("less","property",{variable:[{pattern:/@[\w-]+\s*:/,inside:{punctuation:/:/}},/@@?[\w-]+/],"mixin-usage":{pattern:/([{;]\s*)[.#](?!\d)[\w-]+.*?(?=[(;])/,lookbehind:!0,alias:"function"}});;
Prism.languages.php=Prism.languages.extend("clike",{keyword:/\b(and|or|xor|array|as|break|case|cfunction|class|const|continue|declare|default|die|do|else|elseif|enddeclare|endfor|endforeach|endif|endswitch|endwhile|extends|for|foreach|function|include|include_once|global|if|new|return|static|switch|use|require|require_once|var|while|abstract|interface|public|implements|private|protected|parent|throw|null|echo|print|trait|namespace|final|yield|goto|instanceof|finally|try|catch)\b/i,constant:/\b[A-Z0-9_]{2,}\b/,comment:{pattern:/(^|[^\\])(\/\*[\w\W]*?\*\/|(^|[^:])(\/\/).*?(\r?\n|$))/,lookbehind:!0}}),Prism.languages.insertBefore("php","class-name",{"shell-comment":{pattern:/(^|[^\\])#.*?(\r?\n|$)/,lookbehind:!0,alias:"comment"}}),Prism.languages.insertBefore("php","keyword",{delimiter:/(\?>|<\?php|<\?)/i,variable:/(\$\w+)\b/i,"package":{pattern:/(\\|namespace\s+|use\s+)[\w\\]+/,lookbehind:!0,inside:{punctuation:/\\/}}}),Prism.languages.insertBefore("php","operator",{property:{pattern:/(->)[\w]+/,lookbehind:!0}}),Prism.languages.markup&&(Prism.hooks.add("before-highlight",function(e){"php"===e.language&&(e.tokenStack=[],e.backupCode=e.code,e.code=e.code.replace(/(?:<\?php|<\?)[\w\W]*?(?:\?>)/gi,function(n){return e.tokenStack.push(n),"{{{PHP"+e.tokenStack.length+"}}}"}))}),Prism.hooks.add("before-insert",function(e){"php"===e.language&&(e.code=e.backupCode,delete e.backupCode)}),Prism.hooks.add("after-highlight",function(e){if("php"===e.language){for(var n,a=0;n=e.tokenStack[a];a++)e.highlightedCode=e.highlightedCode.replace("{{{PHP"+(a+1)+"}}}",Prism.highlight(n,e.grammar,"php"));e.element.innerHTML=e.highlightedCode}}),Prism.hooks.add("wrap",function(e){"php"===e.language&&"markup"===e.type&&(e.content=e.content.replace(/(\{\{\{PHP[0-9]+\}\}\})/g,'<span class="token php">$1</span>'))}),Prism.languages.insertBefore("php","comment",{markup:{pattern:/<[^?]\/?(.*?)>/,inside:Prism.languages.markup},php:/\{\{\{PHP[0-9]+\}\}\}/}));;
Prism.languages.insertBefore("php","variable",{"this":/\$this/,global:/\$_?(GLOBALS|SERVER|GET|POST|FILES|REQUEST|SESSION|ENV|COOKIE|HTTP_RAW_POST_DATA|argc|argv|php_errormsg|http_response_header)/,scope:{pattern:/\b[\w\\]+::/,inside:{keyword:/(static|self|parent)/,punctuation:/(::|\\)/}}});;
Prism.languages.sql={comment:{pattern:/(^|[^\\])(\/\*[\w\W]*?\*\/|((--)|(\/\/)|#).*?(\r?\n|$))/,lookbehind:!0},string:{pattern:/(^|[^@])("|')(\\?[\s\S])*?\2/,lookbehind:!0},variable:/@[\w.$]+|@("|'|`)(\\?[\s\S])+?\1/,"function":/\b(?:COUNT|SUM|AVG|MIN|MAX|FIRST|LAST|UCASE|LCASE|MID|LEN|ROUND|NOW|FORMAT)(?=\s*\()/i,keyword:/\b(?:ACTION|ADD|AFTER|ALGORITHM|ALTER|ANALYZE|APPLY|AS|ASC|AUTHORIZATION|BACKUP|BDB|BEGIN|BERKELEYDB|BIGINT|BINARY|BIT|BLOB|BOOL|BOOLEAN|BREAK|BROWSE|BTREE|BULK|BY|CALL|CASCADE|CASCADED|CASE|CHAIN|CHAR VARYING|CHARACTER VARYING|CHECK|CHECKPOINT|CLOSE|CLUSTERED|COALESCE|COLUMN|COLUMNS|COMMENT|COMMIT|COMMITTED|COMPUTE|CONNECT|CONSISTENT|CONSTRAINT|CONTAINS|CONTAINSTABLE|CONTINUE|CONVERT|CREATE|CROSS|CURRENT|CURRENT_DATE|CURRENT_TIME|CURRENT_TIMESTAMP|CURRENT_USER|CURSOR|DATA|DATABASE|DATABASES|DATETIME|DBCC|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFINER|DELAYED|DELETE|DENY|DESC|DESCRIBE|DETERMINISTIC|DISABLE|DISCARD|DISK|DISTINCT|DISTINCTROW|DISTRIBUTED|DO|DOUBLE|DOUBLE PRECISION|DROP|DUMMY|DUMP|DUMPFILE|DUPLICATE KEY|ELSE|ENABLE|ENCLOSED BY|END|ENGINE|ENUM|ERRLVL|ERRORS|ESCAPE|ESCAPED BY|EXCEPT|EXEC|EXECUTE|EXIT|EXPLAIN|EXTENDED|FETCH|FIELDS|FILE|FILLFACTOR|FIRST|FIXED|FLOAT|FOLLOWING|FOR|FOR EACH ROW|FORCE|FOREIGN|FREETEXT|FREETEXTTABLE|FROM|FULL|FUNCTION|GEOMETRY|GEOMETRYCOLLECTION|GLOBAL|GOTO|GRANT|GROUP|HANDLER|HASH|HAVING|HOLDLOCK|IDENTITY|IDENTITY_INSERT|IDENTITYCOL|IF|IGNORE|IMPORT|INDEX|INFILE|INNER|INNODB|INOUT|INSERT|INT|INTEGER|INTERSECT|INTO|INVOKER|ISOLATION LEVEL|JOIN|KEY|KEYS|KILL|LANGUAGE SQL|LAST|LEFT|LIMIT|LINENO|LINES|LINESTRING|LOAD|LOCAL|LOCK|LONGBLOB|LONGTEXT|MATCH|MATCHED|MEDIUMBLOB|MEDIUMINT|MEDIUMTEXT|MERGE|MIDDLEINT|MODIFIES SQL DATA|MODIFY|MULTILINESTRING|MULTIPOINT|MULTIPOLYGON|NATIONAL|NATIONAL CHAR VARYING|NATIONAL CHARACTER|NATIONAL CHARACTER VARYING|NATIONAL VARCHAR|NATURAL|NCHAR|NCHAR VARCHAR|NEXT|NO|NO SQL|NOCHECK|NOCYCLE|NONCLUSTERED|NULLIF|NUMERIC|OF|OFF|OFFSETS|ON|OPEN|OPENDATASOURCE|OPENQUERY|OPENROWSET|OPTIMIZE|OPTION|OPTIONALLY|ORDER|OUT|OUTER|OUTFILE|OVER|PARTIAL|PARTITION|PERCENT|PIVOT|PLAN|POINT|POLYGON|PRECEDING|PRECISION|PREV|PRIMARY|PRINT|PRIVILEGES|PROC|PROCEDURE|PUBLIC|PURGE|QUICK|RAISERROR|READ|READS SQL DATA|READTEXT|REAL|RECONFIGURE|REFERENCES|RELEASE|RENAME|REPEATABLE|REPLICATION|REQUIRE|RESTORE|RESTRICT|RETURN|RETURNS|REVOKE|RIGHT|ROLLBACK|ROUTINE|ROWCOUNT|ROWGUIDCOL|ROWS?|RTREE|RULE|SAVE|SAVEPOINT|SCHEMA|SELECT|SERIAL|SERIALIZABLE|SESSION|SESSION_USER|SET|SETUSER|SHARE MODE|SHOW|SHUTDOWN|SIMPLE|SMALLINT|SNAPSHOT|SOME|SONAME|START|STARTING BY|STATISTICS|STATUS|STRIPED|SYSTEM_USER|TABLE|TABLES|TABLESPACE|TEMP(?:ORARY)?|TEMPTABLE|TERMINATED BY|TEXT|TEXTSIZE|THEN|TIMESTAMP|TINYBLOB|TINYINT|TINYTEXT|TO|TOP|TRAN|TRANSACTION|TRANSACTIONS|TRIGGER|TRUNCATE|TSEQUAL|TYPE|TYPES|UNBOUNDED|UNCOMMITTED|UNDEFINED|UNION|UNPIVOT|UPDATE|UPDATETEXT|USAGE|USE|USER|USING|VALUE|VALUES|VARBINARY|VARCHAR|VARCHARACTER|VARYING|VIEW|WAITFOR|WARNINGS|WHEN|WHERE|WHILE|WITH|WITH ROLLUP|WITHIN|WORK|WRITE|WRITETEXT)\b/i,"boolean":/\b(?:TRUE|FALSE|NULL)\b/i,number:/\b-?(0x)?\d*\.?[\da-f]+\b/,operator:/\b(?:ALL|AND|ANY|BETWEEN|EXISTS|IN|LIKE|NOT|OR|IS|UNIQUE|CHARACTER SET|COLLATE|DIV|OFFSET|REGEXP|RLIKE|SOUNDS LIKE|XOR)\b|[-+]|!|[=<>]{1,2}|(&){1,2}|\|?\||\?|\*|\//i,punctuation:/[;[\]()`,.]/};;

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

(function($) {
    'use strict';

    /**
     * Create a new instance.
     *
     * @param {Object} element
     * @param {Object} options
     */
    window.Comments = function(element, options) {
        this.element = element;
        this.options = $.extend({}, Comments.defaults, options);

        this.initOptions();
        this.bindEvents();
    };

    /**
     * Default options.
     */
    Comments.defaults = {
        storageKey: 'comment_author',
        commentTemplateId: 'commentTemplate',
        paginationTemplateId: 'paginationTemplate',
        messages: {
            comment: '1 comment',
            comments: '{num} comments',
            nocomments: 'no comments',
            error: 'Opps! Unexpected error.',
        },
    };

    /**
     * Initialize options.
     */
    Comments.prototype.initOptions = function() {
        var o = this.options, el = this.element;

        o.list  = el.find('.list');
        o.form  = el.find('form');
        o.sort  = el.find('.sort');
        o.total = el.find('.total');
        o.placeholder = el.find('.placeholder');
        o.pagination  = el.find('.pagination-container');
        o.currentPage = this.getParam('page', 1);
        o.linkedComment = this.getParam('comment', 0);

        $.ajaxSetup({headers: {'X-CSRF-TOKEN': this.options.csrfToken}});
    };

    /**
     * Bind events.
     */
    Comments.prototype.bindEvents = function() {
        var o = this.options;

        o.placeholder.on('click', this.showForm.bind(this));
        o.form.find('.cancel').on('click', this.hideForm.bind(this));
        this.element.on('keyup', 'textarea', this.characterCount.bind(this));
        this.element.on('click', '.captcha img', this.refreshCaptcha.bind(this));
        o.pagination.on('click', 'a', this.pageClick.bind(this));
        this.element.on('submit', '.post-form', this.formSubmit.bind(this));
        o.sort.on('click', 'a', this.sort.bind(this));

        // Comment events.
        o.list.on('click', '.reply', this.showReplyForm.bind(this));
        o.list.on('click', '.time, .parent', this.setLinkedComment.bind(this));
        o.list.on('click', '.collapse, .expand', this.toggleComment.bind(this));
        o.list.on('click', '.upvote, .downvote', this.vote.bind(this));
        o.list.on('click', '.quick-edit', this.showEditForm.bind(this));
        o.list.on('submit', '.edit-form', this.submitEditForm.bind(this));
        o.list.on('click', '.edit-form .cancel', this.hideEditForm.bind(this));

        this.selectSort();
        this.loadComments();
    };

    /**
     * Show form.
     */
    Comments.prototype.showForm = function(e) {
        this.getAuthor(this.options.form);
        this.options.placeholder.hide();
        this.options.form.show();

        autosize(this.options.form.find('textarea'));

    };

    /**
     * Hide form.
     */
    Comments.prototype.hideForm = function() {
        this.options.form.hide();
        this.clearForm(this.options.form);
        this.options.placeholder.show();

        autosize.destroy(this.options.form.find('textarea'));
    };

    /**
     * Textarea character count.
     */
    Comments.prototype.characterCount = function(e) {
        var textarea  = $(e.target),
            form      = textarea.closest('form'),
            value     = textarea.val(),
            maxlength = parseInt(textarea.attr('maxlength')) || 0;

        if (!maxlength) return;

        if (value.length > maxlength) {
            textarea.val(value.substr(0, maxlength));
            form.find('.character-count').text(0);
        } else {
            form.find('.character-count').text(maxlength - value.length);
        }
    };

    /**
     * Refresh captcha.
     */
    Comments.prototype.refreshCaptcha = function() {
        var images = this.element.find('.captcha img');

        if (!images.length) return;

        this.element.find('input[name="captcha"]').val('');

        this.ajax('GET', 'captcha', {})
            .done(function(src) {
                images.attr('src', src);
            });
    };

    /**
     * Handle pagination page click.
     */
    Comments.prototype.pageClick = function(e) {
        e.preventDefault();

        var li   = $(e.currentTarget).parent(),
            page = $(e.currentTarget).data('page');

        if (li.hasClass('disabled') || li.hasClass('active')) {
            e.preventDefault();
            return false;
        }

        window.location.hash = '#!page=' + page;

        $('body, html').animate({scrollTop: this.options.list.offset().top - 20}, 400);

        this.options.currentPage = page;
        this.options.linkedComment = 0;

        this.loadComments();
    }

    /**
     * Handle form submit.
     */
    Comments.prototype.formSubmit = function(e) {
        e.preventDefault();

        var self  = this,
            form  = $(e.target),
            data  = form.serialize(),
            list  = this.options.list,
            email = form.find('input[name="author_email"]').val(),
            depth = form.parents('.comment').length + 1;

        if (form.find('input[name="parent_id"]').val().length) {
            list = form.parent().parent().next('.list').first();
        }

        form.find('.response').hide();

        this.disable(form);

        this.ajax('POST', data)
            .done(function(comment) {
                var $comment = self.renderComment(comment, null, depth);

                $comment.prependTo(list);

                self.highlight($comment);
                self.setTotal(self.options.total.data('total') + 1);

                if (!comment.author.id) {
                    self.setAuthor($.extend(comment.author, {email: email}));
                }

                form.find('.cancel').trigger('click');
            })
            .fail(function(jqXHR) {
                self.alert(jqXHR.responseJSON || self.trans('error'), form);
            })
            .always(function() {
                self.enable(form);
                self.refreshCaptcha();
            });
    };

    /**
     * Handle comment sorting.
     */
    Comments.prototype.sort = function(e) {
        e.preventDefault();

        this.options.currentPage = 1;
        this.options.linkedComment = 0;
        this.options.sortBy = $(e.currentTarget).attr('data-sort');

        this.selectSort();
        this.loadComments();
    };

    /**
     * Set select sort.
     */
    Comments.prototype.selectSort = function() {
        this.options.sort.find('.current').text(this.options.sort.find('[data-sort="'+this.options.sortBy+'"]').text());
        this.options.sort.find('li').removeClass('selected');
        this.options.sort.find('[data-sort="'+this.options.sortBy+'"]').parent().addClass('selected');
    };

    /**
     * Load comments.
     */
    Comments.prototype.loadComments = function() {
        var self = this,
            data = {
                page: this.options.currentPage,
                page_id: this.options.pageId,
                linked: this.options.linkedComment,
                sort: this.options.sortBy,
            },
            toggleLoading = function() {
                self.element.find('.loader').toggle();
            };

        toggleLoading();

        this.ajax('GET', 'get', data)
            .done(function(data) {
                self.options.list.fadeOut(200, function() {
                    self.options.list.html('');

                    self.renderComments(data.comments, self.options.list);
                    self.highlight(self.options.list);

                    self.options.list.find('.list').show();

                    self.options.list.fadeIn('slow', function() {
                        if (self.options.linkedComment) {
                            self.scrollToComment(self.options.linkedComment);
                        }
                    });
                });

                self.renderPagination(data);
            })
            .always(toggleLoading);
    };

    /**
     * Render comments.
     *
     * @param {Object} comments
     * @param {Object} list
     * @param {Object} parent
     */
    Comments.prototype.renderComments = function(comments, list, parent, depth) {
        var i, $comment;

        depth = depth || 1;

        for (i in comments) {
            $comment = this.renderComment(comments[i], parent, depth);

            $comment.appendTo(list);

            if (comments[i].id === this.options.linkedComment) {
                $comment.find('.linked').show();
            }

            if (comments[i].replies) {
                if (!parent) {
                    comments[i].replies = this.hierarchical(comments[i].replies, comments[i].id);
                }

                this.renderComments(comments[i].replies, $comment.find('.list'), comments[i], depth + 1);
            }
        }
    };

    /**
     * @param  {Array}  comments
     * @param  {Number} parentId
     * @return {Object}
     */
    Comments.prototype.hierarchical = function(comments, parentId) {
        var i, comment, result = [];

        for (i in comments) {
            if (comments[i].parent_id === parentId) {
                comment = comments[i];
                comment.replies = this.hierarchical(comments, comment.id);
                result.push(comment);
            }
        }

        return result;
    };

    /**
     * Render comment.
     *
     * @param  {Object} comment
     * @param  {Object} parent
     * @return {Object}
     */
    Comments.prototype.renderComment = function(comment, parent, depth) {
        comment.parent = parent;
        comment.reply = this.options.replies;

        if (this.options.maxDepth && depth > this.options.maxDepth) {
            comment.reply = false;
        }

        var $comment =  this.renderTemplate(comment, this.options.commentTemplateId);

        $comment.find('.text img:not(.smiley)').addClass('img-thumbnail');

        $comment.find('.timeago').timeago();

        return $comment;
    }

    /**
     * Render pagination.
     *
     * @param {Object} data
     */
    Comments.prototype.renderPagination = function(data) {
        this.setTotal(data.comments.length ? data.total : 0);

        var pagination = data.pagination;

        if (!pagination || !pagination.per_page || pagination.total <= pagination.per_page) {
            return;
        }

        this.options.pagination.html(this.renderTemplate(pagination, this.options.paginationTemplateId));
    };

    /**
     * Set the total number of comments.
     *
     * @param {Number}
     */
    Comments.prototype.setTotal = function(value) {
        var total = value ? (value === 1 ? this.trans('comment') : this.trans('comments', {num: value})) : this.trans('nocomments');
        this.options.total.text(total).data('total', value).show();
    };

    /**
     * Toggle comment.
     */
    Comments.prototype.toggleComment = function(e) {
        $(e.currentTarget).closest('.comment').toggleClass('collapsed');
    }

    /**
     * Vote comment.
     */
    Comments.prototype.vote = function (e) {
        e.preventDefault();

        var UP = 'up',
            DOWN = 'down',
            REMOVE_UP = '-up',
            REMOVE_DOWN = '-down',
            type,
            $el        = $(e.currentTarget),
            $votes     = $el.parent(),
            $upvote    = $votes.find('.upvote'),
            $downvote  = $votes.find('.downvote'),
            $upvotes   = $votes.find('.upvotes'),
            $downvotes = $votes.find('.downvotes'),
            upvotes    = parseInt($upvotes.data('votes')),
            downvotes  = parseInt($downvotes.data('votes')),
            setUpvotes = function(val) {
                $upvotes.data('votes', val).text(val || '');
            },
            setDownvotes = function(val) {
                $downvotes.data('votes', val).text(val || '');
            };

        // Click on upvote.
        if ($el.hasClass('upvote')) {
            // Remove upvote.
            if ($el.hasClass('voted')) {
                $el.removeClass('voted');
                setUpvotes(upvotes - 1);
                type = REMOVE_UP;
            }
            // Upvote.
            else {
                type = UP;

                if ($downvote.hasClass('voted')) {
                    $downvote.removeClass('voted');
                    setDownvotes(downvotes - 1);
                }

                $el.addClass('voted');
                setUpvotes(upvotes + 1);
            }
        }
        // Click on downvote.
        else {
            // Remove downvote.
            if ($el.hasClass('voted')) {
                $el.removeClass('voted');
                setDownvotes(downvotes - 1);
                type = REMOVE_DOWN;
            }
            // Downvote.
            else {
                type = DOWN;

                if ($upvote.hasClass('voted')) {
                    $upvote.removeClass('voted');
                    setUpvotes(upvotes - 1);
                }

                $el.addClass('voted');
                setDownvotes(downvotes + 1);
            }
        }

        this.ajax('POST', 'vote', {id: $votes.closest('.comment').data('id'), type: type});
    };

    /**
     * Show reply form.
     */
    Comments.prototype.showReplyForm = function(e) {
        e.preventDefault();

        var replybox = $(e.currentTarget).parent().parent().parent().find('.replybox'),
            rootId   = $(e.currentTarget).data('root'),
            parentId = $(e.currentTarget).data('parent');

        if (replybox.html().length) {
            return replybox.find('.cancel').trigger('click');
        }

        this.options.form.find('.cancel').trigger('click');

        var form = this.options.form.clone();

        form.find('.cancel').bind('click', this.hideReplyForm.bind(this));

        this.clearForm(form);
        form.appendTo(replybox);

        form.find('input[name="root_id"]').val(rootId);
        form.find('input[name="parent_id"]').val(parentId);

        this.getAuthor(form);

        form.show();

        autosize(form.find('textarea'));
    }

    /**
     * Hide reply form.
     */
    Comments.prototype.hideReplyForm = function(e) {
        $(e.target).closest('form').remove();
    };

    /**
     * Show edit form.
     */
    Comments.prototype.showEditForm = function(e) {
        e.preventDefault();

        var body = $(e.currentTarget).closest('.body'),
            form = body.find('.edit-form'),
            textarea = form.find('textarea');

        body.find('.text').hide();
        textarea.val(textarea.data('content'));
        form.show();

        autosize(textarea);
    };

    /**
     * Hide edit form.
     */
    Comments.prototype.hideEditForm = function(e) {
        var body = $(e.currentTarget).closest('.body');

        body.find('.edit-form').hide();
        body.find('.text').show();
    }

    /**
     * Submit edit form.
     */
    Comments.prototype.submitEditForm = function(e) {
        e.preventDefault();

        var self = this,
            form = $(e.target),
            data = form.serialize(),
            body = form.closest('.body'),
            text = body.find('.text'),
            decode = function(str) {
                return $('<textarea/>').html(str).text();
            };

        form.find('.response').hide();
        this.disable(form);

        this.ajax('POST', data)
            .done(function(comment) {
                text.html(comment.content.formated);
                form.find('textarea').data('content', decode(comment.content.raw));

                self.highlight(text);
                self.hideEditForm(e);

                if (comment.status !== 'approved') {
                    body.find('.on-hold').addClass('show');
                    body.find('.edit-menu').remove();
                }
            })
            .fail(function(jqXHR) {
                self.alert(jqXHR.responseJSON || self.trans('error'), form);
            })
            .always(function() {
                self.enable(form);
            });
    }

    /**
     * Clear form.
     *
     * @param {Object} form
     */
    Comments.prototype.clearForm = function(form) {
        form.find('.response').hide();
        form.find('input[type="text"], textarea').val('');
        form.find('.character-count').text(form.find('textarea').attr('maxlength'));
    };

    /**
     * Set linked comment.
     */
    Comments.prototype.setLinkedComment = function(e) {
        e.preventDefault();

        var target = $(e.currentTarget);

        if (target.data('parent')) {
            var comment = this.options.list.find('[data-id="'+target.data('parent')+'"]');
        } else {
            var comment = target.closest('.comment');
        }

        window.location.hash = '#!comment=' + comment.data('id');

        this.options.list.find('.linked').hide();

        comment.find('.linked').first().show();
    }

    /**
     * Scroll to linked comment.
     *
     * @param {Object} comment
     */
    Comments.prototype.scrollToComment = function(comment) {
        if (!(comment instanceof $)) {
            comment = this.options.list.find('[data-id="' + comment+'"]');
        }

        if (comment.length) {
            $('body, html').animate({scrollTop: comment.offset().top - 20}, 100);
        }
    };

    /**
     * Show alert.
     *
     * @param  {Array|String} message
     * @param  {Object}       form
     */
    Comments.prototype.alert = function(message, form) {
        form.find('.response')
            .html(this.renderTemplate({message: message}, 'alertTemplate'))
            .slideDown(200);
    };

    /**
     * Ajax helper.
     *
     * @param  {String} type
     * @param  {String} action
     * @param  {Object} data
     * @return {Object}
     */
    Comments.prototype.ajax = function(type, action, data) {
        if (data) {
            data.action = action;
        } else {
            data = action;
        }

        return $.ajax({
            url: this.options.ajaxUrl,
            type: type,
            data: data,
            dataType: 'json',
        });
    }

    /**
     * Get param.
     *
     * @param  {String} name
     * @param  {Number} _default
     * @return {Number}
     */
    Comments.prototype.getParam = function(name, _default) {
        var val, fragment = this.extractParam('_escaped_fragment_', location.search);

        if (fragment) {
            val = this.extractParam(name, '#'+fragment, true);
        } else {
            val = this.extractParam(name, window.location.hash.replace('#!', '#'), true);
        }

        return parseInt(val) || _default;
    };

    /**
     * Extract param from query / hash.
     *
     * @param  {String}  name
     * @param  {String}  str
     * @param  {Boolean} hash
     * @return {String}
     */
    Comments.prototype.extractParam = function(name, str, hash) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');

        var regex = new RegExp((hash ? '[\\#]' : '[\\?&]') + name + '=([^&#]*)'),
            results = regex.exec(str);

        if (results) {
            return decodeURIComponent(results[1].replace(/\+/g, ' '));
        }

        return null;
    };

    /**
     * Remember author in the local storage.
     *
     * @param {Object} author
     */
    Comments.prototype.setAuthor = function(author) {
        author = {name: author.name, email: author.email, url: author.url};
        window.localStorage.setItem(this.options.storageKey, JSON.stringify(author));
    };

    /**
     * Get author from local storage and fill the form.
     *
     * @param {Object} $form
     */
    Comments.prototype.getAuthor = function($form) {
        var author = window.localStorage.getItem(this.options.storageKey);

        try {
            author = JSON.parse(author);
        } catch (error) {
        }

        if (author) {
            $form.find('input[name="author_name"]').val(author.name);
            $form.find('input[name="author_email"]').val(author.email);
            $form.find('input[name="author_url"]').val(author.url);
        }
    };

    /**
     * Render template.
     *
     * @param  {Object} data
     * @param  {String} templateId
     * @return {Object}
     */
    Comments.prototype.renderTemplate = function(data, templateId) {
        return $(tmpl(templateId, data));
    };

    /**
     * Translage message.
     *
     * @param  {String} message
     * @param  {Object} replace
     * @return {String}
     */
    Comments.prototype.trans = function(message, replace) {
        message = this.options.messages[message] || message.toString();

        if (replace) {
           $.each(replace, function(key, value) {
               message = message.replace('{' + key + '}', value);
           });
        }

        return message;
    };

    /**
     * Highlight code.
     *
     * @param {Object} $element
     */
    Comments.prototype.highlight = function($element) {
        if (window.Prism) {
            $('pre code').each(function(i, block) {
                Prism.highlightElement(block);
            });
        }
    }

    /**
     * Disable form inputs and buttons.
     *
     * @param {Object}  form
     * @param {Boolean} state
     */
    Comments.prototype.disable = function(form, state) {
        state = (state === undefined) ? true : state;

        form.find('button, input, textarea').prop('disabled', state);

        if ($.fn.button) {
            form.find('button[type="submit"]').button(state ? 'loading' : 'reset');
        }
    }

    /**
     * Enable form inputs and buttons.
     *
     * @param {Object} form
     */
    Comments.prototype.enable = function(form) {
        this.disable(form, false);
    }
})(jQuery);
