/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

(function($) {
    'use strict';

    /**
     * Create a new instance.
     *
     * @param {Object} element
     * @param {Object} options
     */
    window.Comments = function(element, options) {
        this.element = element;
        this.options = $.extend({}, Comments.defaults, options);

        this.initOptions();
        this.bindEvents();
    };

    /**
     * Default options.
     */
    Comments.defaults = {
        storageKey: 'comment_author',
        commentTemplateId: 'commentTemplate',
        paginationTemplateId: 'paginationTemplate',
        messages: {
            comment: '1 comment',
            comments: '{num} comments',
            nocomments: 'no comments',
            error: 'Opps! Unexpected error.',
        },
    };

    /**
     * Initialize options.
     */
    Comments.prototype.initOptions = function() {
        var o = this.options, el = this.element;

        o.list  = el.find('.list');
        o.form  = el.find('form');
        o.sort  = el.find('.sort');
        o.total = el.find('.total');
        o.placeholder = el.find('.placeholder');
        o.pagination  = el.find('.pagination-container');
        o.currentPage = this.getParam('page', 1);
        o.linkedComment = this.getParam('comment', 0);

        $.ajaxSetup({headers: {'X-CSRF-TOKEN': this.options.csrfToken}});
    };

    /**
     * Bind events.
     */
    Comments.prototype.bindEvents = function() {
        var o = this.options;

        o.placeholder.on('click', this.showForm.bind(this));
        o.form.find('.cancel').on('click', this.hideForm.bind(this));
        this.element.on('keyup', 'textarea', this.characterCount.bind(this));
        this.element.on('click', '.captcha img', this.refreshCaptcha.bind(this));
        o.pagination.on('click', 'a', this.pageClick.bind(this));
        this.element.on('submit', '.post-form', this.formSubmit.bind(this));
        o.sort.on('click', 'a', this.sort.bind(this));

        // Comment events.
        o.list.on('click', '.reply', this.showReplyForm.bind(this));
        o.list.on('click', '.time, .parent', this.setLinkedComment.bind(this));
        o.list.on('click', '.collapse, .expand', this.toggleComment.bind(this));
        o.list.on('click', '.upvote, .downvote', this.vote.bind(this));
        o.list.on('click', '.quick-edit', this.showEditForm.bind(this));
        o.list.on('submit', '.edit-form', this.submitEditForm.bind(this));
        o.list.on('click', '.edit-form .cancel', this.hideEditForm.bind(this));

        this.selectSort();
        this.loadComments();
    };

    /**
     * Show form.
     */
    Comments.prototype.showForm = function(e) {
        this.getAuthor(this.options.form);
        this.options.placeholder.hide();
        this.options.form.show();

        autosize(this.options.form.find('textarea'));

    };

    /**
     * Hide form.
     */
    Comments.prototype.hideForm = function() {
        this.options.form.hide();
        this.clearForm(this.options.form);
        this.options.placeholder.show();

        autosize.destroy(this.options.form.find('textarea'));
    };

    /**
     * Textarea character count.
     */
    Comments.prototype.characterCount = function(e) {
        var textarea  = $(e.target),
            form      = textarea.closest('form'),
            value     = textarea.val(),
            maxlength = parseInt(textarea.attr('maxlength')) || 0;

        if (!maxlength) return;

        if (value.length > maxlength) {
            textarea.val(value.substr(0, maxlength));
            form.find('.character-count').text(0);
        } else {
            form.find('.character-count').text(maxlength - value.length);
        }
    };

    /**
     * Refresh captcha.
     */
    Comments.prototype.refreshCaptcha = function() {
        var images = this.element.find('.captcha img');

        if (!images.length) return;

        this.element.find('input[name="captcha"]').val('');

        this.ajax('GET', 'captcha', {})
            .done(function(src) {
                images.attr('src', src);
            });
    };

    /**
     * Handle pagination page click.
     */
    Comments.prototype.pageClick = function(e) {
        e.preventDefault();

        var li   = $(e.currentTarget).parent(),
            page = $(e.currentTarget).data('page');

        if (li.hasClass('disabled') || li.hasClass('active')) {
            e.preventDefault();
            return false;
        }

        window.location.hash = '#!page=' + page;

        $('body, html').animate({scrollTop: this.options.list.offset().top - 20}, 400);

        this.options.currentPage = page;
        this.options.linkedComment = 0;

        this.loadComments();
    }

    /**
     * Handle form submit.
     */
    Comments.prototype.formSubmit = function(e) {
        e.preventDefault();

        var self  = this,
            form  = $(e.target),
            data  = form.serialize(),
            list  = this.options.list,
            email = form.find('input[name="author_email"]').val(),
            depth = form.parents('.comment').length + 1;

        if (form.find('input[name="parent_id"]').val().length) {
            list = form.parent().parent().next('.list').first();
        }

        form.find('.response').hide();

        this.disable(form);

        this.ajax('POST', data)
            .done(function(comment) {
                var $comment = self.renderComment(comment, null, depth);

                $comment.prependTo(list);

                self.highlight($comment);
                self.setTotal(self.options.total.data('total') + 1);

                if (!comment.author.id) {
                    self.setAuthor($.extend(comment.author, {email: email}));
                }

                form.find('.cancel').trigger('click');
            })
            .fail(function(jqXHR) {
                self.alert(jqXHR.responseJSON || self.trans('error'), form);
            })
            .always(function() {
                self.enable(form);
                self.refreshCaptcha();
            });
    };

    /**
     * Handle comment sorting.
     */
    Comments.prototype.sort = function(e) {
        e.preventDefault();

        this.options.currentPage = 1;
        this.options.linkedComment = 0;
        this.options.sortBy = $(e.currentTarget).attr('data-sort');

        this.selectSort();
        this.loadComments();
    };

    /**
     * Set select sort.
     */
    Comments.prototype.selectSort = function() {
        this.options.sort.find('.current').text(this.options.sort.find('[data-sort="'+this.options.sortBy+'"]').text());
        this.options.sort.find('li').removeClass('selected');
        this.options.sort.find('[data-sort="'+this.options.sortBy+'"]').parent().addClass('selected');
    };

    /**
     * Load comments.
     */
    Comments.prototype.loadComments = function() {
        var self = this,
            data = {
                page: this.options.currentPage,
                page_id: this.options.pageId,
                linked: this.options.linkedComment,
                sort: this.options.sortBy,
            },
            toggleLoading = function() {
                self.element.find('.loader').toggle();
            };

        toggleLoading();

        this.ajax('GET', 'get', data)
            .done(function(data) {
                self.options.list.fadeOut(200, function() {
                    self.options.list.html('');

                    self.renderComments(data.comments, self.options.list);
                    self.highlight(self.options.list);

                    self.options.list.find('.list').show();

                    self.options.list.fadeIn('slow', function() {
                        if (self.options.linkedComment) {
                            self.scrollToComment(self.options.linkedComment);
                        }
                    });
                });

                self.renderPagination(data);
            })
            .always(toggleLoading);
    };

    /**
     * Render comments.
     *
     * @param {Object} comments
     * @param {Object} list
     * @param {Object} parent
     */
    Comments.prototype.renderComments = function(comments, list, parent, depth) {
        var i, $comment;

        depth = depth || 1;

        for (i in comments) {
            $comment = this.renderComment(comments[i], parent, depth);

            $comment.appendTo(list);

            if (comments[i].id === this.options.linkedComment) {
                $comment.find('.linked').show();
            }

            if (comments[i].replies) {
                if (!parent) {
                    comments[i].replies = this.hierarchical(comments[i].replies, comments[i].id);
                }

                this.renderComments(comments[i].replies, $comment.find('.list'), comments[i], depth + 1);
            }
        }
    };

    /**
     * @param  {Array}  comments
     * @param  {Number} parentId
     * @return {Object}
     */
    Comments.prototype.hierarchical = function(comments, parentId) {
        var i, comment, result = [];

        for (i in comments) {
            if (comments[i].parent_id === parentId) {
                comment = comments[i];
                comment.replies = this.hierarchical(comments, comment.id);
                result.push(comment);
            }
        }

        return result;
    };

    /**
     * Render comment.
     *
     * @param  {Object} comment
     * @param  {Object} parent
     * @return {Object}
     */
    Comments.prototype.renderComment = function(comment, parent, depth) {
        comment.parent = parent;
        comment.reply = this.options.replies;

        if (this.options.maxDepth && depth > this.options.maxDepth) {
            comment.reply = false;
        }

        var $comment =  this.renderTemplate(comment, this.options.commentTemplateId);

        $comment.find('.text img:not(.smiley)').addClass('img-thumbnail');

        $comment.find('.timeago').timeago();

        return $comment;
    }

    /**
     * Render pagination.
     *
     * @param {Object} data
     */
    Comments.prototype.renderPagination = function(data) {
        this.setTotal(data.comments.length ? data.total : 0);

        var pagination = data.pagination;

        if (!pagination || !pagination.per_page || pagination.total <= pagination.per_page) {
            return;
        }

        this.options.pagination.html(this.renderTemplate(pagination, this.options.paginationTemplateId));
    };

    /**
     * Set the total number of comments.
     *
     * @param {Number}
     */
    Comments.prototype.setTotal = function(value) {
        var total = value ? (value === 1 ? this.trans('comment') : this.trans('comments', {num: value})) : this.trans('nocomments');
        this.options.total.text(total).data('total', value).show();
    };

    /**
     * Toggle comment.
     */
    Comments.prototype.toggleComment = function(e) {
        $(e.currentTarget).closest('.comment').toggleClass('collapsed');
    }

    /**
     * Vote comment.
     */
    Comments.prototype.vote = function (e) {
        e.preventDefault();

        var UP = 'up',
            DOWN = 'down',
            REMOVE_UP = '-up',
            REMOVE_DOWN = '-down',
            type,
            $el        = $(e.currentTarget),
            $votes     = $el.parent(),
            $upvote    = $votes.find('.upvote'),
            $downvote  = $votes.find('.downvote'),
            $upvotes   = $votes.find('.upvotes'),
            $downvotes = $votes.find('.downvotes'),
            upvotes    = parseInt($upvotes.data('votes')),
            downvotes  = parseInt($downvotes.data('votes')),
            setUpvotes = function(val) {
                $upvotes.data('votes', val).text(val || '');
            },
            setDownvotes = function(val) {
                $downvotes.data('votes', val).text(val || '');
            };

        // Click on upvote.
        if ($el.hasClass('upvote')) {
            // Remove upvote.
            if ($el.hasClass('voted')) {
                $el.removeClass('voted');
                setUpvotes(upvotes - 1);
                type = REMOVE_UP;
            }
            // Upvote.
            else {
                type = UP;

                if ($downvote.hasClass('voted')) {
                    $downvote.removeClass('voted');
                    setDownvotes(downvotes - 1);
                }

                $el.addClass('voted');
                setUpvotes(upvotes + 1);
            }
        }
        // Click on downvote.
        else {
            // Remove downvote.
            if ($el.hasClass('voted')) {
                $el.removeClass('voted');
                setDownvotes(downvotes - 1);
                type = REMOVE_DOWN;
            }
            // Downvote.
            else {
                type = DOWN;

                if ($upvote.hasClass('voted')) {
                    $upvote.removeClass('voted');
                    setUpvotes(upvotes - 1);
                }

                $el.addClass('voted');
                setDownvotes(downvotes + 1);
            }
        }

        this.ajax('POST', 'vote', {id: $votes.closest('.comment').data('id'), type: type});
    };

    /**
     * Show reply form.
     */
    Comments.prototype.showReplyForm = function(e) {
        e.preventDefault();

        var replybox = $(e.currentTarget).parent().parent().parent().find('.replybox'),
            rootId   = $(e.currentTarget).data('root'),
            parentId = $(e.currentTarget).data('parent');

        if (replybox.html().length) {
            return replybox.find('.cancel').trigger('click');
        }

        this.options.form.find('.cancel').trigger('click');

        var form = this.options.form.clone();

        form.find('.cancel').bind('click', this.hideReplyForm.bind(this));

        this.clearForm(form);
        form.appendTo(replybox);

        form.find('input[name="root_id"]').val(rootId);
        form.find('input[name="parent_id"]').val(parentId);

        this.getAuthor(form);

        form.show();

        autosize(form.find('textarea'));
    }

    /**
     * Hide reply form.
     */
    Comments.prototype.hideReplyForm = function(e) {
        $(e.target).closest('form').remove();
    };

    /**
     * Show edit form.
     */
    Comments.prototype.showEditForm = function(e) {
        e.preventDefault();

        var body = $(e.currentTarget).closest('.body'),
            form = body.find('.edit-form'),
            textarea = form.find('textarea');

        body.find('.text').hide();
        textarea.val(textarea.data('content'));
        form.show();

        autosize(textarea);
    };

    /**
     * Hide edit form.
     */
    Comments.prototype.hideEditForm = function(e) {
        var body = $(e.currentTarget).closest('.body');

        body.find('.edit-form').hide();
        body.find('.text').show();
    }

    /**
     * Submit edit form.
     */
    Comments.prototype.submitEditForm = function(e) {
        e.preventDefault();

        var self = this,
            form = $(e.target),
            data = form.serialize(),
            body = form.closest('.body'),
            text = body.find('.text'),
            decode = function(str) {
                return $('<textarea/>').html(str).text();
            };

        form.find('.response').hide();
        this.disable(form);

        this.ajax('POST', data)
            .done(function(comment) {
                text.html(comment.content.formated);
                form.find('textarea').data('content', decode(comment.content.raw));

                self.highlight(text);
                self.hideEditForm(e);

                if (comment.status !== 'approved') {
                    body.find('.on-hold').addClass('show');
                    body.find('.edit-menu').remove();
                }
            })
            .fail(function(jqXHR) {
                self.alert(jqXHR.responseJSON || self.trans('error'), form);
            })
            .always(function() {
                self.enable(form);
            });
    }

    /**
     * Clear form.
     *
     * @param {Object} form
     */
    Comments.prototype.clearForm = function(form) {
        form.find('.response').hide();
        form.find('input[type="text"], textarea').val('');
        form.find('.character-count').text(form.find('textarea').attr('maxlength'));
    };

    /**
     * Set linked comment.
     */
    Comments.prototype.setLinkedComment = function(e) {
        e.preventDefault();

        var target = $(e.currentTarget);

        if (target.data('parent')) {
            var comment = this.options.list.find('[data-id="'+target.data('parent')+'"]');
        } else {
            var comment = target.closest('.comment');
        }

        window.location.hash = '#!comment=' + comment.data('id');

        this.options.list.find('.linked').hide();

        comment.find('.linked').first().show();
    }

    /**
     * Scroll to linked comment.
     *
     * @param {Object} comment
     */
    Comments.prototype.scrollToComment = function(comment) {
        if (!(comment instanceof $)) {
            comment = this.options.list.find('[data-id="' + comment+'"]');
        }

        if (comment.length) {
            $('body, html').animate({scrollTop: comment.offset().top - 20}, 100);
        }
    };

    /**
     * Show alert.
     *
     * @param  {Array|String} message
     * @param  {Object}       form
     */
    Comments.prototype.alert = function(message, form) {
        form.find('.response')
            .html(this.renderTemplate({message: message}, 'alertTemplate'))
            .slideDown(200);
    };

    /**
     * Ajax helper.
     *
     * @param  {String} type
     * @param  {String} action
     * @param  {Object} data
     * @return {Object}
     */
    Comments.prototype.ajax = function(type, action, data) {
        if (data) {
            data.action = action;
        } else {
            data = action;
        }

        return $.ajax({
            url: this.options.ajaxUrl,
            type: type,
            data: data,
            dataType: 'json',
        });
    }

    /**
     * Get param.
     *
     * @param  {String} name
     * @param  {Number} _default
     * @return {Number}
     */
    Comments.prototype.getParam = function(name, _default) {
        var val, fragment = this.extractParam('_escaped_fragment_', location.search);

        if (fragment) {
            val = this.extractParam(name, '#'+fragment, true);
        } else {
            val = this.extractParam(name, window.location.hash.replace('#!', '#'), true);
        }

        return parseInt(val) || _default;
    };

    /**
     * Extract param from query / hash.
     *
     * @param  {String}  name
     * @param  {String}  str
     * @param  {Boolean} hash
     * @return {String}
     */
    Comments.prototype.extractParam = function(name, str, hash) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');

        var regex = new RegExp((hash ? '[\\#]' : '[\\?&]') + name + '=([^&#]*)'),
            results = regex.exec(str);

        if (results) {
            return decodeURIComponent(results[1].replace(/\+/g, ' '));
        }

        return null;
    };

    /**
     * Remember author in the local storage.
     *
     * @param {Object} author
     */
    Comments.prototype.setAuthor = function(author) {
        author = {name: author.name, email: author.email, url: author.url};
        window.localStorage.setItem(this.options.storageKey, JSON.stringify(author));
    };

    /**
     * Get author from local storage and fill the form.
     *
     * @param {Object} $form
     */
    Comments.prototype.getAuthor = function($form) {
        var author = window.localStorage.getItem(this.options.storageKey);

        try {
            author = JSON.parse(author);
        } catch (error) {
        }

        if (author) {
            $form.find('input[name="author_name"]').val(author.name);
            $form.find('input[name="author_email"]').val(author.email);
            $form.find('input[name="author_url"]').val(author.url);
        }
    };

    /**
     * Render template.
     *
     * @param  {Object} data
     * @param  {String} templateId
     * @return {Object}
     */
    Comments.prototype.renderTemplate = function(data, templateId) {
        return $(tmpl(templateId, data));
    };

    /**
     * Translage message.
     *
     * @param  {String} message
     * @param  {Object} replace
     * @return {String}
     */
    Comments.prototype.trans = function(message, replace) {
        message = this.options.messages[message] || message.toString();

        if (replace) {
           $.each(replace, function(key, value) {
               message = message.replace('{' + key + '}', value);
           });
        }

        return message;
    };

    /**
     * Highlight code.
     *
     * @param {Object} $element
     */
    Comments.prototype.highlight = function($element) {
        if (window.Prism) {
            $('pre code').each(function(i, block) {
                Prism.highlightElement(block);
            });
        }
    }

    /**
     * Disable form inputs and buttons.
     *
     * @param {Object}  form
     * @param {Boolean} state
     */
    Comments.prototype.disable = function(form, state) {
        state = (state === undefined) ? true : state;

        form.find('button, input, textarea').prop('disabled', state);

        if ($.fn.button) {
            form.find('button[type="submit"]').button(state ? 'loading' : 'reset');
        }
    }

    /**
     * Enable form inputs and buttons.
     *
     * @param {Object} form
     */
    Comments.prototype.enable = function(form) {
        this.disable(form, false);
    }
})(jQuery);
