/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

(function($) {
    'use strict';

    /**
     * Create a new instance.
     *
     * @param {Object} options
     */
    window.Admin = function(options) {
        this.options = $.extend({}, Admin.defaults, options);
    };

    /**
     * Default options.
     */
    Admin.defaults = {
        messages: {
            saved: 'Your changes have been saved.',
            error: 'Opps! Unexpected error.',
        },
    };

    var PENDING  = 'pending',
        APPROVED = 'approved',
        SPAM     = 'spam',
        TRASH    = 'trash';

    /**
     * Init comments.
     *
     * @param {Object} options
     */
    Admin.prototype.initComments = function(options) {
        if (options) {
            this.options = $.extend(this.options, options);
        }

        var table = (this.options.table = this.options.table || $('#comments'));

        if (!this.options.editModal) {
            this.options.editModal = $('#edit-comment-modal');
        }

        this.options.editForm = this.options.editModal.find('form');

        $.ajaxSetup({headers: {'X-CSRF-TOKEN': this.options.csrfToken}});

        table.on('click', '.mark', this.mark.bind(this));
        table.on('click', '.mark-all', this.markAll.bind(this));
        table.on('click', '.approve', this.approve.bind(this));
        table.on('click', '.unapprove', this.unapprove.bind(this));
        table.on('click', '.spam', this.spam.bind(this));
        table.on('click', '.trash', this.trash.bind(this));
        table.on('click', '.delete', this._delete.bind(this));
        table.on('click', '.edit', this.editModal.bind(this));
        this.options.editForm.on('submit', this.editFormSubmit.bind(this));

        table.find('[data-toggle="tooltip"]').tooltip();

        var id = parseInt(this.getHashParam('edit')) || null;

        if (id ) {
            this.edit(id);
        }
    };

    /**
     * Approve comment.
     */
    Admin.prototype.approve = function(e) {
        e.preventDefault();

        var comment = $(e.currentTarget).closest('tr');

        if (this.options.status === PENDING || $(e.currentTarget).hasClass('not-spam')) {
            comment.fadeOut();
        } else {
            comment.removeClass('warning');
            comment.find('.approve').parent().hide();
            comment.find('.unapprove').parent().show();
        }

        this.post(comment.data('id'), {status: APPROVED});
    };

    /**
     * Unapprove comment.
     */
    Admin.prototype.unapprove = function(e) {
        e.preventDefault();

        var comment = $(e.currentTarget).closest('tr');

        if (this.options.status === APPROVED) {
            comment.fadeOut();
        } else {
            comment.addClass('warning');
            comment.find('.unapprove').parent().hide();
            comment.find('.approve').parent().show();
        }

        this.post(comment.data('id'), {status: PENDING});
    };

    /**
     * Spam comment.
     */
    Admin.prototype.spam = function(e) {
        e.preventDefault();

        var comment = $(e.currentTarget).closest('tr').fadeOut();
        this.post(comment.data('id'), {status: SPAM});
    };

    /**
     * Trash comment.
     */
    Admin.prototype.trash = function(e) {
        e.preventDefault();

        var comment = $(e.currentTarget).closest('tr').fadeOut();
        this.post(comment.data('id'), {status: TRASH});
    };

    /**
     * Delete comment.
     */
    Admin.prototype._delete = function(e) {
        e.preventDefault();

        var comment = $(e.currentTarget).closest('tr').fadeOut();
        this.post(comment.data('id'), {action: 'delete'});
    };

    function decode(str) {
        return $('<textarea/>').html(str).text();
    };

    /**
     * Edit comment.
     */
    Admin.prototype.edit = function(id) {
        var modal = this.options.editModal,
            oldStatus = null,
            self = this;

        modal.find('.alert').hide();

        $.get(this.options.ajaxUrl, {action: 'getComment', id: id}, function(comment) {
            oldStatus = comment.status;

            modal.find('input[name="id"]').val(comment.id);
            modal.find('input[name="author_name"]').val(comment.author.name);
            modal.find('input[name="author_email"]').val(comment.author.email);
            modal.find('input[name="author_url"]').val(comment.author.url);
            modal.find('select[name="status"]').val(comment.status);
            modal.find('textarea').val(decode(comment.content.raw));

            if (comment.author.id) {
                modal.find('input.guest').prop('readonly', true);
            }

            modal.modal('show');
        }).fail(function() {
            alert('Comment not found.');
            window.location.hash = '';
        });

        modal.off().on('hide.bs.modal', function() {
            window.location.hash = '';

            if (self._comment) {
                var comment  = self._comment,
                    $comment = self.options.table.find('[data-id="'+id+'"]');

                if (oldStatus !== comment.status) {
                    var klass = comment.status === PENDING ? '.unapprove' : '.'+comment.status;

                    $comment.find(klass).trigger('click');
                }

                $comment.find('.content').html(comment.content.raw);
                $comment.find('.name').text(comment.author.name);
                $comment.find('.email').text(comment.author.email)
                    .attr('href', 'mailto:'+comment.author.email);
                $comment.find('.avatar').attr('src', comment.author.avatar);

                self._comment = null;
            }
        });

    };

    Admin.prototype.editModal = function(e) {
        var id = $(e.currentTarget).closest('tr').data('id');
        this.edit(id);
    };

    /**
     * Edit form submit.
     */
    Admin.prototype.editFormSubmit = function(e) {
        e.preventDefault();

        var form   = this.options.editForm,
            submit = form.find('button[type="submit"]'),
            inputs = form.find('input, textarea, select'),
            alert  = form.find('.alert'),
            data   = form.serialize(),
            self   = this;

        submit.button('loading');
        inputs.prop('disabled', true);
        alert.hide().removeClass('alert-success alert-danger');

        $.post(this.options.ajaxUrl, data, function(data) {
            self._comment = data.comment;
            self.updateEditModal(data.comment);
            self.updateStatusCount(data.statuses);
            alert.addClass('alert-success').text(self.options.messages.saved).show();
        })
        .fail(function(jqXHR) {
            alert.addClass('alert-danger').text(jqXHR.responseJSON || self.options.messages.error).show();
        })
        .always(function() {
            submit.button('reset');
            inputs.prop('disabled', false);
        });
    };

    /**
     * Update edit modal.
     *
     * @param {Object} comment
     */
    Admin.prototype.updateEditModal = function(comment) {
        var modal = this.options.editModal;

        modal.find('input[name="author_name"]').val(comment.author.name);
        modal.find('input[name="author_email"]').val(comment.author.email);
        modal.find('input[name="author_url"]').val(comment.author.url);
        modal.find('select[name="status"]').val(comment.status);
        modal.find('textarea').val(comment.content.raw);
    };

    /**
     * Update comment status count.
     *
     * @param {Object} statuses
     */
    Admin.prototype.updateStatusCount = function(statuses) {
        $('.status-filter .count').text('(0)');

        for (var status in statuses) {
            $('.status-filter .'+status+' .count').text('('+statuses[status]+')');
        };
    };

    /**
     * Get param from the hash fragment.
     *
     * @param  {String} name
     * @return {String}
     */
    Admin.prototype.getHashParam = function(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');

        var hash = window.location.hash.replace('#!', '#'),
            regex = new RegExp('[\\#]' + name + '=([^&#]*)'),
            results = regex.exec(hash);

        if (results) {
            return decodeURIComponent(results[1].replace(/\+/g, ' '));
        }

        return null;
    };

    /**
     * Mark comment.
     */
    Admin.prototype.mark = function(e) {
        var checked = $(e.delegateTarget).find('.mark:checked').length;
            checked = $(e.delegateTarget).find('.mark').length === checked;
        $(e.delegateTarget).find('.select-all').prop('checked', checked);
    };

    /**
     * Mark all comments.
     */
    Admin.prototype.markAll = function(e) {
        $(e.delegateTarget).find('.mark').prop('checked', $(e.currentTarget).is(':checked'));
    };

    /**
     * Ajax post.
     *
     * @param  {Number} id
     * @param  {Object} data
     * @return {Object}
     */
    Admin.prototype.post = function(id, data) {
        var self = this,
            data = $.extend({id: id, action: 'update', page_id: this.options.pageId}, data);

        return $.post(this.options.ajaxUrl, data, function(data) {
            self.updateStatusCount(data.statuses);
        }, 'json');
    };
})(jQuery);
