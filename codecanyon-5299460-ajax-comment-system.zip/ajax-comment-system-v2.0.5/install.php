<?php

use ACS\User;
use ACS\Auth\Hasher;

require __DIR__.'/comments/start.php';
require __DIR__.'/comments/migrations/create_tables.php';

// Create an admin user.
if (Comments::userModel()) {
    User::unguard();
    User::create([
        'name'     => 'Admin',
        'email'    => 'admin',
        'password' => ACS\Auth\Hasher::make('admin'),
        'role'     => 'admin',
    ]);
}

?>

<h2>Warning!</h2>
<p>
    Make sure you delete <code>install.php</code> !
</p>
