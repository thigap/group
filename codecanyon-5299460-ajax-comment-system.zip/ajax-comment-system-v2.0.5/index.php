<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ajax Comment System</title>

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.css">
    <link rel="stylesheet" href="assets/css/vendor/prism-okaidia.css">
    <link rel="stylesheet" href="assets/css/comments.css">
    <link rel="stylesheet" href="assets/css/demo.css">

    <!-- JavaScript -->
    <script src="assets/js/vendor/jquery.js"></script>
    <script src="assets/js/vendor/bootstrap.js"></script>
    <script src="assets/js/bundle.js"></script>
</head>
<body>
    <?php require __DIR__.'/comments/views/demo-nav.php'; ?>

    <div class="container">
        <div id="demo" class="col-md-9 col-md-offset-2">
            <div class="pull-left">
                <a href="admin/index.php" class="btn btn-info btn-sm">Admin</a>
            </div>

            <!-- Init file. -->
            <?php require __DIR__.'/comments/start.php'; ?>

            <!-- Basic auth. -->
            <div class="pull-right">
                <?php if (Auth::check()) { ?>
                    Logged as <a href="user.php"><?php echo Auth::user()->name; ?></a> |
                    <a href="user.php?action=logout">Logout</a>
                <?php } else { ?>
                    <a href="user.php?action=login" class="btn btn-primary btn-sm">Log in</a>
                    <a href="user.php?action=signup" class="btn btn-primary btn-sm">Sign up</a>
                <?php } ?>
            </div>
            <div class="clearfix"></div>

            <!-- Display comments. -->
            <?php Comments::render('page1'); ?>
        </div>
    </div>
</body>
</html>
