<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Comments;

use Closure;
use Hazzard\Mail\Mail;

trait MailerTrait
{
    /**
     * Send email notification.
     *
     * @param  \ACS\Comments\Comment $comment
     * @param  mixed $callback
     * @return mixed
     */
    public function notification(Comment $comment, $callback = null)
    {
        if (!$this->debug()) {
            return $this->executeInBackground(function() use ($comment) {
                return $this->send($comment);
            }, $callback);
        }

        $this->send($comment);

        if (is_callable($callback)) {
            return call_user_func($callback);
        }
    }

    /**
     * @param  \ACS\Comments\Comment $comment
     * @return mixed
     */
    protected function send(Comment $comment)
    {
        $notify = $this['config']['general.notify_email'];

        if ($notify && $notify !== $comment->author_email && $comment->status !== Comment::SPAM) {
            $this['mailer']->send('emails.notification', compact('comment'), function ($m) use ($notify) {
                $m->to($notify);
            });
        }

        if (!$this['config']['general.reply_email'] || !$comment->parent) {
            return;
        }

        if ($comment->status !== Comment::APPROVED ||
            $comment->parent->author_email === $notify ||
            $comment->parent->author_email === $comment->author_email) {
            return;
        }

        $this['mailer']->send('emails.reply', compact('comment'), function ($m) use ($comment) {
            $m->to($comment->parent->author_email);
        });
    }

    /**
     * Execute callback in background.
     *
     * @param  mixed $callback
     * @param  mixed $finishCallback
     * @return mixed
     */
    protected function executeInBackground($callback, $finishCallback = null)
    {
        ignore_user_abort(true);
        set_time_limit(0);
        ob_start();

        if (is_callable($finishCallback)) {
            echo call_user_func($finishCallback);
        }

        $size = ob_get_length();

        header("Content-Length: $size");
        header('Connection: close');

        ob_end_flush();
        ob_flush();
        flush();

        if (session_id()) {
            session_write_close();
        }

        return call_user_func($callback);
    }
}
