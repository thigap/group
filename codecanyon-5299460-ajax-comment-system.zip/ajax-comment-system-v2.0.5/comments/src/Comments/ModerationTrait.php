<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Comments;

use DateTime;
use ACS\Support\Akismet;

trait ModerationTrait
{
    /**
     * Check for comment flood.
     *
     * @param  array $input
     * @return bool
     */
    public function checkFlood($input)
    {
        if (!$time = $this['config']['moderation.time_between']) {
            return false;
        }

        $hourAgo = (new DateTime)->setTimestamp(time() - 3600)->format('Y-m-d H:i:s');

        $query = Comment::where('created_at', '>=', $hourAgo)
                        ->orderBy('created_at', 'desc');

        if (isset($input['user_id'])) {
            $query->userId($input['user_id']);
        } else {
            $query->authorEmail($input['author_email']);
        }

        if ($lastTime = $query->pluck('created_at')) {
            return (time() - strtotime($lastTime)) < (int) $time;
        }

        return false;
    }

    /**
     * Check for duplicate comments.
     *
     * @param  array $input
     * @return bool
     */
    public function checkDuplicate($input)
    {
        if (!$this['config']['moderation.duplicate']) {
            return false;
        }

        $query = Comment::where('content', $input['content'])
                        ->where('page_id', $input['page_id']);

        if (isset($input['user_id'])) {
            $query->userId($input['user_id']);
        } else {
            $query->authorEmail($input['author_email']);
        }

        return $query->pluck('id') ? true : false;
    }

    /**
     * Check max pending comments.
     *
     * @param  array $input
     * @return bool
     */
    public function checkMaxPending($input)
    {
        if (!$maxPending = $this['config']['moderation.max_pending']) {
            return false;
        }

        if (isset($input['user_id'])) {
            $query = Comment::userId($input['user_id']);
        } else {
            $query = Comment::authorEmail($input['author_email']);
        }

        $pending = $query->status('!=', Comment::APPROVED)->count('id');

        return $pending >= $maxPending;
    }

    /**
     * Get comment status.
     *
     * @param  array $input
     * @return string
     */
    public function getCommentStatus(array $input)
    {
        if ($this['config']['moderation.moderation']) {
            return Comment::PENDING;
        }

        if ($this->contains($input, 'moderation_keys')) {
            return Comment::PENDING;
        }

        if ($this->contains($input, 'blacklist_keys')) {
            return Comment::SPAM;
        }

        if ($max = $this['config']['moderation.max_links']) {
            $count = preg_match_all('/<a [^>]*href/i', $this['clickable']->convert($input['content']));

            if ($count >= $max) {
                return Comment::PENDING;
            }
        }

        if ($this->akismetCheck($input)) {
            return Comment::SPAM;
        }

        return Comment::APPROVED;
    }

    /**
     * Check if contains specific keys.
     *
     * @param  string $input
     * @param  string $type
     * @return bool
     */
    protected function contains($input, $type)
    {
        $keys = $this['config']["moderation.$type"];

        foreach ($keys as $key) {
            if (is_array($input)) {
                foreach ($input as $field) {
                    if (preg_match('/\b'.$key.'\b/', $field)) {
                        return true;
                    }
                }
            } elseif (preg_match('/\b'.$key.'\b/', $input)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check comment for spam with Akismet.
     *
     * @param  array $input
     * @return bool
     */
    protected function akismetCheck($input)
    {
        if (!$this['config']['moderation.akismet']) {
            return false;
        }

        $key = $this['config']['services.akismet_key'];

        return (new Akismet($key))->commentCheck([
            'blog' => $this->getBlogUrl(),
            'user_ip' => $input['author_ip'],
            'referrer' => $input['referrer'],
            'permalink' => $input['permalink'],
            'user_agent' => $input['user_agent'],
            'comment_type' => 'comment',
            'comment_content' => $input['content'],
            'comment_author' => $input['author_name'],
            'comment_author_url' => $input['author_url'],
            'comment_author_email' => $input['author_email'],
        ]);
    }

    /**
     * @return string
     */
    protected function getBlogUrl()
    {
        $url = $this['config']['general.url'];

        if (!empty($url)) {
            return $url;
        }

        return (isset($_SERVER['HTTPS']) ? 'https' : 'http').'://'.$_SERVER['HTTP_HOST'];
    }
}
