<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Comments;

use ACS\Support\InputTrait;
use ACS\Support\BootstrapTrait;
use ACS\Support\ValidatesInput;
use Illuminate\Support\MessageBag;
use Illuminate\Container\Container;
use Illuminate\Contracts\Validation\ValidationException;

class Comments extends Container
{
    use BootstrapTrait, InputTrait, ValidatesInput, ModerationTrait, MailerTrait;

    const CAPTCHA_GUESTS = 1;
    const CAPTCHA_USERS  = 2;
    const CAPTCHA_ALL    = 3;

    const SORT_NEWEST = 1;
    const SORT_OLDEST = 2;
    const SORT_BEST   = 3;

    /**
     * Get comments for pagination.
     *
     * @param  array $args
     * @return \Comments\Comments\Paginator
     */
    public function get(array $args = [])
    {
        $this->setInputSource($args);

        $page    = $this->input('page', 1);
        $pageId  = $this->input('page_id', 0);
        $linked  = $this->input('linked');
        $sortby  = $this->input('sort');
        $status  = $this->input('status', Comment::APPROVED);
        $perPage = $this['config']['general.per_page'];

        list($column, $direction) = $this->getOrderBy($sortby);

        if ($linked && $perPage) {
            $page = $this->getPageNumber($linked) ?: $page;
        }

        $query = Comment::query();

        if (!is_null($pageId)) {
            $query->where('page_id', $pageId);
        }

        $this->whereStatus($query, $status);

        $count = $query->count('id');

        $query->whereNull('parent_id');

        $total = $query->count('id');

        $query->orderBy($column, $direction)
              ->loadUser($this->authUser('id'));

        if ($perPage) {
            $query->forPage($page, $perPage);
        }

        if ($this['config']['general.replies']) {
            $query->with(['replies' => function ($query) use ($status, $column, $direction) {
                $query->orderBy($column, $direction)
                      ->loadUser($this->authUser('id'));

                $this->whereStatus($query, $status);
            }]);
        }

        $comments = $query->get();

        if ($perPage) {
            return new Paginator($comments, $total, $perPage, $page, ['count' => $count]);
        }

        return ['comments' => $comments, 'total' => $count];
    }

    /**
     * Find comment by id.
     *
     * @param  int $id
     * @return \Comments\Comments\Comment|null
     */
    public function find($id)
    {
        return Comment::loadUser()->find($id);
    }

    /**
     * Post a new comment.
     *
     * @param  array $input
     * @return \Comments\Comments\Comment|null
     *
     * @throws \Illuminate\Contracts\Validation\ValidationException
     */
    public function post(array $input = [])
    {
        $this->setInputSource($input);

        $input = [
            'page_id'    => e($this->input('page_id')),
            'author_ip'  => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'root_id'    => $this->input('root_id'),
            'parent_id'  => $this->input('parent_id'),
            'content'    => e($this->input('content')),
            'permalink'  => e($this->input('permalink')),
            'referrer'   => $this->input('referrer'),
            'status'     => Comment::APPROVED,
            'captcha'    => $this->input('captcha'),
            'author_name'  => e($this->input('author_name')),
            'author_email' => $this->input('author_email'),
            'author_url'   => e($this->input('author_url')),
        ];

        $rules = [];

        if ($this->authUser()) {
            $input['user_id']      = $this->authUser('id');
            $input['author_name']  = $this->authUser('name');
            $input['author_email'] = $this->authUser('email');
            $input['author_url']   = $this->authUser('url');
        } else {
            $input['user_id'] = null;

            $rules['author_name']  = 'required|max:100';
            $rules['author_email'] = 'required|email|max:255';
            $rules['author_url']   = 'url|max:255';
        }

        if ($this->captchaRequired()) {
            $rules['captcha'] = 'required|captcha';
        }

        $rules['page_id']   = 'required';
        $rules['content']   = 'required|min:2';
        $rules['parent_id'] = 'exists:comments,id';
        $rules['root_id']   = 'exists:comments,id,parent_id,NULL';

        if ($max = $this['config']['general.maxlength']) {
            $rules['content'] .= "|max:$max";
        }

        // Extra validation for regular users.
        if (!$this->adminCheck()) {
            // $rules['root_id']   .= ',status,'.Comment::APPROVED;
            $rules['parent_id'] .= ',status,'.Comment::APPROVED;
            $rules['content']   .= '|flood|duplicate|max_pending';

            $this->extendValidator('flood', function () use ($input) {
                return !$this->checkFlood($input);
            })->extendValidator('duplicate', function () use ($input) {
                return !$this->checkDuplicate($input);
            })->extendValidator('max_pending', function () use ($input) {
                return !$this->checkMaxPending($input);
            });

            $input['status'] = $this->getCommentStatus($input);
        }

        if (empty($input['root_id']) || !$this['config']['general.replies']) {
            unset($input['root_id'], $input['parent_id']);
        }

        $this->validate($input, $rules);

        if ($this->authUser()) {
            unset($input['author_email'], $input['author_name'], $input['author_url']);
        } else {
            $this->setAuthorEmailCookie($input['author_email']);
        }

        $comment = Comment::create($input);

        return Comment::find($comment->id);
    }

    /**
     * Update comment.
     *
     * @param  array $input
     * @return int|null
     *
     * @throws \Illuminate\Contracts\Validation\ValidationException
     */
    public function update($input)
    {
        $this->setInputSource($input);

        if (!$comment = Comment::find($this->input('id'))) {
            return;
        }

        if ($comment->status !== Comment::APPROVED && !$this->adminCheck()) {
            return;
        }

        if (!$this->adminCheck() && !$this->quickEdit($comment)) {
            return;
        }

        $rules = [
            'content' => "required|min:2",
            'status'  => 'required|in:'.implode(',', Comment::statuses()),
        ];

        if ($max = $this['config']['general.maxlength']) {
            $rules['content'] .= "|max:$max";
        }

        if ($this->adminCheck()) {
            if ($comment->user_id) {
                $input = $this->only('content', 'status');
            } else {
                $rules['author_name']  = 'required|max:100';
                $rules['author_email'] = 'required|email|max:255';
                $rules['author_url']   = 'url|max:255';

                $input = $this->only('author_name', 'author_email', 'author_url', 'content', 'status');
            }
        } else {
            $input = $this->only('content');
            $input['status'] = $this->getCommentStatus($input);
        }

        $errors = new MessageBag;

        if (!$this->adminCheck()) {
            $this->validate($input, $rules);
        }

        try {
            $this->validate($input, $rules);
        } catch (ValidationException $e) {
            $errors = $e->errors();
        }

        foreach ($input as $key => $value) {
            if (!$errors->has($key)) {
                $comment->{$key} = trim(e($value));
            }
        }

        $comment->save();

        return $comment;
    }

    /**
     * Delete comment by id.
     *
     * @param  int $id
     * @return int
     */
    public function delete($id)
    {
        return Comment::where('id', $id)->take(1)->delete();
    }

    /**
     * Vote comment.
     *
     * @param  int $commentId
     * @param  string $type
     * @return bool
     */
    public function vote($commentId, $type)
    {
        $userId = $this->authUser('id');

        if (!$comment = $this->find($commentId)) {
            return false;
        }

        $comment->loadUser($userId);

        $voted = $comment->userVote;

        $vote = $comment->votes()->where('user_id', $userId)->first();

        // Remove upvote / downvote.
        if ($type === Vote::REMOVE_UP || $type === Vote::REMOVE_DOWN) {
            if ($vote) {
                if ($type === Vote::REMOVE_UP) {
                    $comment->upvotes = absint($comment->upvotes - 1);
                } else {
                    $comment->downvotes = absint($comment->downvotes - 1);
                }

                $vote->delete();
            }
        }
        // Upvote / downvote.
        elseif (is_null($voted) && ($type === Vote::UP || $type === Vote::DOWN)) {
            if ($type === Vote::UP) {
                $comment->upvotes = $comment->upvotes + 1;
            } else {
                $comment->downvotes = $comment->downvotes + 1;
            }

            if ($vote) {
                if ($type === Vote::UP) {
                    $comment->downvotes = absint($comment->downvotes - 1);
                } else {
                    $comment->upvotes = absint($comment->upvotes - 1);
                }

                $vote->vote_type = $type;
                $vote->save();
            } else {
                $comment->votes()->save(new Vote(['user_id' => $userId, 'vote_type' => $type]));
            }
        }

        $comment->save();

        return true;
    }

    /**
     * Get page number by comment id.
     *
     * @param  int $commentId
     * @return int|null
     */
    public function getPageNumber($commentId)
    {
        list($column, $direction) = $this->getOrderBy(null);

        $operator = $direction === 'DESC' ? '>' : '<';

        $perPage = $this['config']['general.per_page'];

        if (!$comment = Comment::find($commentId)) {
            return;
        }

        if ($comment->root_id) {
            $value = $comment->root()->pluck($column);
        } else {
            $value = $comment->{$column};
        }

        if ($value) {
            $count = Comment::query()
                        ->where($column, $operator, $comment->fromDateTime($value))
                        ->whereNull('root_id')
                        ->count('id');

            $page = intval(floor($count / $perPage)) + 1;

            if ($page > 1) {
                return $page;
            }
        }
    }

    /**
     * Get the number of comments grouped by page.
     *
     * @return array
     */
    public function getPageCommentCount()
    {
        return Comment::select('page_id')
                      ->selectRaw('COUNT(id) as aggregate')
                      ->groupBy('page_id')->getQuery()
                      ->lists('aggregate', 'page_id');
    }

    /**
     * Get the number of comments grouped by status.
     *
     * @param  string $pageId
     * @return array
     */
    public function getStatusCount($pageId = null)
    {
        $query = Comment::select('status')
                        ->selectRaw('COUNT(id) as aggregate')
                        ->groupBy('status');
        if ($pageId) {
            $query->where('page_id', $pageId);
        }

        return $query->getQuery()->lists('aggregate', 'status');
    }

    /**
     * Check if the authenticated user can quick edit the comment.
     *
     * @param  \ACS\Comments\Comment $comment
     * @return bool
     */
    public function quickEdit(Comment $comment)
    {
        if ($this->adminCheck()) {
            return true;
        }

        if (!$this->authUser() || $this->authUser('id') !== $comment->user_id) {
            return false;
        }

        $edit = $this['config']['general.quick_edit'];

        if (is_numeric($edit)) {
            return $comment->created_at->getTimestamp() > time() - $edit;
        }

        return $edit === true;
    }

    /**
     * Filter by status.
     *
     * @param  \Illuminate\Database\Eloquent\Builder $query
     * @param  mixed $status
     * @return void
     */
    protected function whereStatus($query, $status)
    {
        if (is_null($status)) return;

        $query->status('!=', Comment::TRASH);

        $query->where(function ($query) use ($status) {
            $query->status($status);

            if ($id = $this->authUser('id')) {
                $query->userId($id, 'or');
            } elseif ($email = $this->getAuthorEmailCookie()) {
                $query->authorEmail($email, 'or');
            }
        });
    }

    /**
     * Get order by column and direction.
     *
     * @param  int $sortBy
     * @return array
     */
    protected function getOrderBy($sortBy)
    {
        $order = [
            static::SORT_NEWEST => ['created_at', 'DESC'],
            static::SORT_OLDEST => ['created_at', 'ASC'],
            static::SORT_BEST   => ['upvotes', 'DESC'],
        ];

        if (isset($order[$sortBy])) {
            return $order[$sortBy];
        }

        return $this->getOrderBy($this['config']['general.default_sort']);
    }

    /**
     * Format comment content.
     *
     * @param  string $content
     * @return string
     */
    public function formatContent($content)
    {
        if ($this['config']['general.markdown']) {
            $content = html_entity_decode($content, ENT_QUOTES, 'UTF-8');
            $content = $this['markdown']->text($content);
        } elseif ($this['config']['general.clickable']) {
            $content = $this['clickable']->convert($content);
        }

        if ($this['config']['general.smilies']) {
            $content = $this['smilies']->convert($content);
        }

        if ($this['config']['general.bbcode']) {
            $content = $this['bbcode']->parse($content)->getAsHtml();
        }

        if (!$this['config']['general.markdown']) {
            $content = str_replace("\n", '<br>', $content);
        }

        return $content;
    }

    /**
     * Remember the author email in cookie.
     *
     * @param  string $email
     * @return void
     */
    public function setAuthorEmailCookie($email)
    {
        $this['cookie']->forever('author_email_'.md5(get_class($this)), $email);
    }

    /**
     * Get author email from cookie.
     *
     * @return string|null
     */
    public function getAuthorEmailCookie()
    {
       return $this['cookie']->get('author_email_'.md5(get_class($this)));
    }

    /**
     * Check if captcha is required.
     *
     * @return bool
     */
    public function captchaRequired()
    {
        $level = $this['config']['general.captcha'];

        if ($level === static::CAPTCHA_GUESTS && !$this->authUser()) {
            return true;
        } elseif ($level === static::CAPTCHA_USERS && $this->authUser()) {
            return true;
        } elseif ($level === static::CAPTCHA_ALL) {
            return true;
        }

        return false;
    }

    /**
     * Get the authenticated user (attribute).
     *
     * @param  string $attribute
     * @return mixed
     */
    public function authUser($attribute = null)
    {
        $response = $this['events']->fire('auth.user', $attribute);

        return is_array($response) ? reset($response) : null;
    }

    /**
     * Check if the user is authenticated as admin.
     *
     * @param  string $permission
     * @return bool
     */
    public function adminCheck()
    {
        $response = $this['events']->fire('admin.check');

        return is_array($response) ? reset($response) === true : false;
    }

    /**
     * Render the template.
     *
     * @param  string $pageId
     * @return void
     */
    public static function render($pageId = null)
    {
        $instance = static::getInstance();

        include $instance['paths.views'].'/template.php';
    }

    /**
     * Load configuration files.
     *
     * @param  array|string $files
     * @return void
     */
    public function loadConfig($files)
    {
        $path = $this['paths.config'];

        foreach ((array) $files as $key) {
            if (file_exists("$path/dev/$key.php")) {
                $this['config']->set($key, require "$path/dev/$key.php");
            } else {
                $this['config']->set($key, require "$path/$key.php");
            }
        }
    }

    /**
     * Get / set the specified configuration value.
     *
     * @param  array|string $key
     * @param  mixed  $default
     * @return mixed
     */
    public static function config($key = null, $default = null)
    {
        $instance = static::getInstance();

        if (is_null($key)) {
            return $instance['config'];
        }

        if (is_array($key)) {
            return $instance['config']->set($key);
        }

        return $instance['config']->get($key, $default);
    }

    /**
     * Get the user model.
     *
     * @return string
     */
    public static function userModel()
    {
        return static::config('general.user_model');
    }

    /**
     * Check if the application is in debug mode.
     *
     * @return bool
     */
    public function debug()
    {
        return $this['config']['general']['debug'];
    }
}
