<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Comments;

use Illuminate\Pagination\LengthAwarePaginator;

class Paginator extends LengthAwarePaginator
{
    /**
     * @var int
     */
    protected $count;

    /**
     * @var int
     */
    public function count()
    {
        return $this->count;
    }

    /**
     * Get the next page.
     *
     * @return int|null
     */
    public function nextPage()
    {
        if ($this->lastPage() > $this->currentPage()) {
            return $this->currentPage() + 1;
        }
    }

    /**
     * Get the previous page.
     *
     * @return int|null
     */
    public function previousPage()
    {
        if ($this->currentPage() > 1) {
            return $this->currentPage() - 1;
        }
    }

    /**
     * Get the first and last adjacent pages.
     *
     * @return array
     */
    public function getAdjacentPages()
    {
        $count = 1;

        if ($this->currentPage() <= $count + $count) {
            $first = 1;
            $last  = min(1 + $count + $count, $this->lastPage());
        } elseif ($this->currentPage() > $this->lastPage() - $count - $count) {
            $last  = $this->lastPage();
            $first = $this->lastPage() - $count - $count;
        } else {
            $first = $this->currentPage() - $count;
            $last  = $this->currentPage() + $count;
        }

        return [$first, $last];
    }

    /**
     * Get the instance as an array.
     *
     * @return array
     */
    public function toArray()
    {
        list($firstAdjacentPage, $lastAdjacentPage) = $this->getAdjacentPages();

        return [
            'total'                   => $this->count(),
            'comments'                => $this->items->toArray(),
            'pagination'              => [
                'total'               => $this->total(),
                'per_page'            => $this->perPage(),
                'current_page'        => $this->currentPage(),
                'last_page'           => $this->lastPage(),
                'next_page'           => $this->nextPage(),
                'prev_page'           => $this->previousPage(),
                'first_adjacent_page' => $firstAdjacentPage,
                'last_adjacent_page'  => $lastAdjacentPage,
            ],
        ];
    }
}
