<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Comments;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    const PENDING  = 'pending';
    const APPROVED = 'approved';
    const SPAM     = 'spam';
    const TRASH    = 'trash';

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'comments';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'page_id', 'root_id', 'parent_id', 'user_id', 'author_name', 'author_url',
        'author_email', 'author_ip', 'user_agent', 'content', 'status', 'permalink',
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id'        => 'integer',
        'upvotes'   => 'integer',
        'downvotes' => 'integer',
        'root_id'   => 'integer',
        'parent_id' => 'integer',
        'user_id'   => 'integer',
    ];

    /**
     * Get the instance as an array.
     *
     * @return array
     */
    public function toArray()
    {
        $isAdmin = Comments::getInstance()->adminCheck();

        return [
            'id'         => $this->id,
            'page_id'    => $this->page_id,
            'root_id'    => $this->root_id,
            'parent_id'  => $this->parent_id,
            'content'    => [
                'raw'      => $this->content,
                'formated' => $this->formatedContent,
            ],
            'status'     => $this->status,
            'created_at' => $this->created_at->toIso8601String(),
            'upvotes'    => $this->upvotes,
            'downvotes'  => $this->downvotes,
            'voted'      => isset($this->userVote) ? $this->userVote->vote_type : null,
            'author'     => [
                'name'   => $this->author_name,
                'email'  => $isAdmin ? $this->author_email : null,
                'url'    => $this->author_url,
                'avatar' => $this->author_avatar,
            ],
            'user_id'    => $this->user_id,
            'edit_link'  => $this->editLink,
            'quick_edit' => Comments::getInstance()->quickEdit($this),
            'moderate'   => $isAdmin,
            'replies'    => isset($this->replies) ? $this->replies : [],
        ];
    }

    /**
     * Author name accessor.
     *
     * @param  string $value
     * @return string
     */
    public function getAuthorNameAttribute($value)
    {
        return $this->getUserAttr('name', $value);
    }

    /**
     * Author email accessor.
     *
     * @param  string $value
     * @return string
     */
    public function getAuthorEmailAttribute($value)
    {
        return $this->getUserAttr('email', $value);
    }

    /**
     * Author avatar accessor.
     *
     * @return string
     */
    public function getAuthorAvatarAttribute()
    {
        return $this->getUserAttr('avatar', gravatar($this->author_email));
    }

    /**
     * Author url accessor.
     *
     * @param  string $value
     * @return string
     */
    public function getAuthorUrlAttribute($value)
    {
        return $this->getUserAttr('url', $value);
    }

    /**
     * Get user attribute or default value.
     *
     * @param  string $attribute
     * @param  string $default
     * @return string
     */
    protected function getUserAttr($attribute, $default = null)
    {
        $model = Comments::userModel();

        if ($model && $this->user) {
           $author = $this->user->getAuthor();

           return array_key_exists($attribute, $author) ? $author[$attribute] : $default;
       }

       return $default;
    }

    /**
     * Permalink accessor.
     *
     * @param  string $value
     * @return string
     */
    public function getPermalinkAttribute($value)
    {
        return "{$value}#!comment={$this->id}";
    }

    /**
     * Admin edit link accessor.
     *
     * @return string
     */
    public function getEditLinkAttribute()
    {
        $url = Comments::config('general.url');

        return "{$url}admin/#!edit={$this->id}";
    }

    /**
     * Formated content accessor.
     *
     * @return string
     */
    public function getFormatedContentAttribute()
    {
        return Comments::getInstance()->formatContent($this->content);
    }

    /**
     * Eager load the comment user and vote for the given user id.
     *
     * @param  \Illuminate\Database\Eloquent\Builder $query
     * @param  int|null $userId
     * @param  \Illuminate\Database\Eloquent\Builder
     */
    public function scopeLoadUser($query, $userId = null)
    {
        if (!$model = Comments::userModel()) {
            return $query;
        }

        $query->with('user');

        if ($userId) {
            $query->with(['userVote' => function ($query) use ($userId) {
                $query->where('user_id', $userId);
            }]);
        }

        return $query;
    }

    /**
     * User id scope.
     *
     * @param  \Illuminate\Database\Query\Builder $query
     * @param  int $id
     * @param  string $boolean
     * @return \Illuminate\Database\Query\Builder
     */
    public function scopeUserId($query, $id, $boolean = 'and')
    {
        return $query->where($this->table.'.user_id', '=', $id, $boolean);
    }

    /**
     * Author email scope.
     *
     * @param  \Illuminate\Database\Query\Builder $query
     * @param  string $email
     * @param  string $boolean
     * @return \Illuminate\Database\Query\Builder
     */
    public function scopeAuthorEmail($query, $email, $boolean = 'and')
    {
        return $query->where('author_email', '=', $email, $boolean);
    }

    /**
     * Status scope.
     *
     * @param  \Illuminate\Database\Query\Builder $query
     * @param  string $operator
     * @param  string $status
     * @return \Illuminate\Database\Query\Builder
     */
    public function scopeStatus($query, $operator, $status = null)
    {
        return $query->where('status', $operator, $status);
    }

    /**
     * Get the user relation.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
    */
    public function user()
    {
        return $this->belongsTo(Comments::userModel(), 'user_id', 'id');
    }

    /**
     * Get the user vote relation.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOneOrMany
    */
    public function userVote()
    {
        return $this->hasOne('ACS\Comments\Vote');
    }

    /**
     * Get the votes relation.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOneOrMany
    */
    public function votes()
    {
        return $this->hasMany('ACS\Comments\Vote');
    }

    /**
     * Get the replies relation.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOneOrMany
     */
    public function replies()
    {
        return $this->hasMany(get_class($this), 'root_id');
    }

    /**
     * Get the parent comment relation.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOneOrMany
    */
    public function parent()
    {
        return $this->hasOne(get_class($this), 'id', 'parent_id');
    }

    /**
     * Get the root comment relation.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOneOrMany
    */
    public function root()
    {
        return $this->hasOne(get_class($this), 'id', 'root_id');
    }

    /**
     * Get status constants.
     *
     * @return array
     */
    public static function statuses()
    {
        return [static::PENDING, static::APPROVED, static::SPAM, static::TRASH];
    }
}
