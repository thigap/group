<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Formatting;

/**
 * Convert text equivalent of smilies to images.
 *
 * Implementation borrowed from WordPress with some modifications.
 * https://github.com/WordPress/WordPress/blob/master/wp-includes/formatting.php
 */
class Smilies
{
    /**
     * Smilies images path.
     *
     * @var string
     */
    protected $path = '';

    /**
     * Smilies array.
     *
     * @var array
     */
    protected $smilies = [];

    /**
     * Create a new smilies instance.
     *
     * @param array  $smilies
     * @param string $path
     */
    public function __construct(array $smilies, $path = '')
    {
        $this->path = $path;
        $this->smilies = $smilies;
    }

    /**
     * Convert text equivalent of smilies to images.
     *
     * @param  string $text
     * @return string
     */
    public function convert($text)
    {
        if (!count($this->smilies)) {
            return $text;
        }

        $subchar = '';
        $spaces = '[\r\n\t ]|\xC2\xA0|&nbsp;';
        $smiliessearch = '/(?<='.$spaces.'|^)';

        foreach ((array) $this->smilies as $smiley => $image) {
            $firstchar = substr($smiley, 0, 1);
            $rest = substr($smiley, 1);

            if ($firstchar !== $subchar) {
                if ($subchar !== '') {
                    $smiliessearch .= ')(?='.$spaces.'|$)';
                    $smiliessearch .= '|(?<='.$spaces.'|^)';
                }

                $subchar = $firstchar;
                $smiliessearch .= preg_quote($firstchar, '/') . '(?:';
            } else {
                $smiliessearch .= '|';
            }

            $smiliessearch .= preg_quote($rest, '/');
        }

        $smiliessearch .= ')(?='.$spaces.'|$)/m';

        $output  = '';
        $textarr = preg_split('/(<.*>)/U', $text, -1, PREG_SPLIT_DELIM_CAPTURE);

        $ignoreTags  = 'code|pre|style|script|textarea';
        $ignoreBlock = '';

        for ($i = 0; $i < count($textarr); $i++) {
            $content = $textarr[$i];

            if ($ignoreBlock === '' && preg_match('/^<('.$ignoreTags.')>/', $content, $matches))  {
                $ignoreBlock = $matches[1];
            }

            if ($ignoreBlock === '' && mb_strlen($content) > 0 && $content[0] !== '<') {
                $content = preg_replace_callback($smiliessearch, [__NAMESPACE__.'\\Smilies', 'replace'], $content);
            }

            if ($ignoreBlock !== '' && $content === '</'.$ignoreBlock.'>') {
                $ignoreBlock = '';
            }

            $output .= $content;
        }

        return $output;
    }

    /**
     * @see convert()
     */
    protected function replace($matches)
    {
        if (!count($matches)) {
            return '';
        }

        return $this->getImage(trim(reset($matches)));
    }

    /**
     * Get smiley image tag.
     *
     * @param  string $smiley
     * @return string
     */
    public function getImage($smiley)
    {
        if (!isset($this->smilies[$smiley])) {
            return '';
        }

        $src = $this->path.'/'.$this->smilies[$smiley];

        return sprintf('<img src="%s" alt="%s" title="%s" class="smiley">', $src, $smiley, $smiley);
    }

    /**
     * Get smilies.
     *
     * @return array
     */
    public function getSmilies()
    {
        return $this->smilies;
    }
}
