<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Formatting;

use JBBCode\CodeDefinitionSet;
use JBBCode\CodeDefinitionBuilder;

class BBCodeDefinitionSet implements CodeDefinitionSet
{
    /**
     * The code definitions in this set.
     *
     * @var array
     */
    protected $definitions = [];

    /**
     * Create a new instance.
     */
    public function __construct()
    {
        // [code]
        $builder = new CodeDefinitionBuilder('code', '<pre><code class="language-{option}">{param}</code></pre>');
        $builder->setParseContent(false)->setUseOption(true);
        $this->addCodeDefinition($builder);

        // [quote]
        $builder = new CodeDefinitionBuilder('quote', '<blockquote>{param}</blockquote>');
        $builder->setParseContent(false);
        $this->addCodeDefinition($builder);

        // [youtube]
        $builder = new CodeDefinitionBuilder('youtube', '<div class="embed-responsive embed-responsive-16by9">
          <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/{param}?rel=0&amp;showinfo=0" allowfullscreen></iframe>
        </div>');
        $builder->setParseContent(false);
        $this->addCodeDefinition($builder);
    }

    /**
     * Add code definition to the definitions array.
     *
     * @param \JBBCode\CodeDefinitionBuilder $builder
     * @return void
     */
    protected function addCodeDefinition(CodeDefinitionBuilder $builder)
    {
        array_push($this->definitions, $builder->build());
    }

    /**
     * Get the code definitions.
     *
     * @return array
     */
    public function getCodeDefinitions()
    {
        return $this->definitions;
    }
}
