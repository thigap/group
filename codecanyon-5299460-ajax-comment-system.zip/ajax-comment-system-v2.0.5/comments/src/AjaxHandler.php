<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS;

use Exception;
use ACS\Support\Captcha;
use ACS\Comments\Comment;
use ACS\Comments\Comments;
use ACS\Support\ResponseTrait;
use Illuminate\Contracts\Validation\ValidationException;

class AjaxHandler
{
    use ResponseTrait;

    /**
     * @var \ACS\Comments\Comments
     */
    protected $comments;

    /**
     * Create a new handler instnace.
     *
     * @param \ACS\Comments\Comments $comments
     */
    public function __construct(Comments $comments)
    {
        $this->comments = $comments;
    }

    /**
     * Get comments.
     */
    function getAction()
    {
        $args = array_merge($_GET, [
            'status' => Comment::APPROVED,
        ]);

        return $this->json($this->comments->get($args));
    }


    /**
     * Get a single comment (Admin).
     */
    public function getCommentAction()
    {
        $this->adminMiddleware();

        $id = isset($_GET['id']) ? $_GET['id'] : 0;

        if (!$comment = $this->comments->find($id)) {
            return $this->json('Not found.', 404);
        }

        return $this->json($comment);
    }


    /**
     * Post comment.
     */
    public function postAction()
    {
        if (!$this->comments['config']['general.guest'] && !$this->comments->authUser()) {
            return $this->json('Unauthorized.', 401);
        }

        try {
            $comment = $this->comments->post($_POST);
        } catch (ValidationException $e) {
            $this->comments['captcha']->refresh();

            throw $e;
        }

        return $this->comments->notification($comment, function() use ($comment) {
            return $this->json($comment, 201);
        });
    }

    /**
     * Update comment.
     */
    public function updateAction()
    {
        if (!$this->comments->authUser()) {
            return $this->json('Unauthorized.', 401);
        }

        if (isset($_POST['page_id']) && $this->comments->adminCheck()) {
            if (!$comment = $this->comments->update($_POST)) {
                return $this->json('Not found.', 404);
            }

            $statuses = $this->comments->getStatusCount($_POST['page_id']);

            return $this->json(compact('comment', 'statuses'));
        }

        $comment = $this->comments->update($_POST);

        if (!$comment) {
            return $this->json('Not found.', 404);
        }

        return $this->json($comment);
    }


    /**
     * Delete comment (Admin).
     */
    public function deleteAction()
    {
        $this->adminMiddleware();

        if (!$this->comments->delete(@$_POST['id'])) {
            return $this->json('Not found.', 404);
        }

        $statuses = $this->comments->getStatusCount($_POST['page_id']);

        return $this->json(compact('statuses'));
    }


    /**
     * Vote comment.
     */
    public function voteAction()
    {
        if (!$this->comments->authUser() || !$this->comments['config']['general.votes']) {
            return $this->json('Unauthorized.', 401);
        }

        if ($this->comments->vote($_POST['id'], $_POST['type'])) {
            return $this->json(true);
        }

        return $this->json('Not found.', 404);
    }


    /**
     * Get captcha image.
     */
    public function captchaAction()
    {
        $this->comments['captcha']->refresh();

        return $this->json($this->comments['captcha']->image());
    }

    /**
     * Handle an incoming action.
     *
     * @return string
     */
    public function handle()
    {
        if (!$this->verifyCsrfToken()) {
            return $this->json('CSRF Token Mismatch Error.', 500);
        }

        $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : null;

        if (!method_exists($this, $action.'Action')) {
            return $this->json("Action [$action] not found.", 405);
        }

        try {
            return $this->{$action.'Action'}();
        } catch (ValidationException $e) {
            return $this->json($e, 422);
        } catch (Exception $e) {
            if ($this->comments->debug()) {
                throw $e;
            }

            return $this->json('Oops! Something went wrong.', 500);
        }
    }

    /**
     * Admin middleware.
     *
     * @return void
     */
    public function adminMiddleware()
    {
        if (!$this->comments->adminCheck()) {
            exit($this->json('Unauthorized.', 401));
        }
    }

    /**
     * Verify csrf token.
     *
     * @return bool
     */
    protected function verifyCsrfToken()
    {
        if ($this->comments->config['general.csrf'] === false) {
            return true;
        }

        $method = strtoupper($_SERVER['REQUEST_METHOD']);

        if (in_array($method, ['GET'])) {
            return true;
        }

        return $this->comments['csrf']->verifyToken();
    }
}
