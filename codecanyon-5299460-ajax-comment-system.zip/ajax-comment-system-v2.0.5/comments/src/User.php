<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'email', 'password'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['password', 'remember_token'];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = ['id' => 'integer'];

    /**
     * Get author attributes.
     *
     * @return array
     */
    public function getAuthor()
    {
        return [
            'id'     => $this->id,
            'name'   => $this->name,
            'email'  => $this->email,
            'avatar' => $this->avatar,
            'url'    => null,
        ];
    }

    /**
     * Avatar accessor.
     *
     * @return string
     */
    public function getAvatarAttribute()
    {
        return gravatar($this->email);
    }

    /**
     * Get the comments relation.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOneOrMany
    */
    public function comments()
    {
        return $this->hasMany('ACS\Comments\Comment');
    }
}
