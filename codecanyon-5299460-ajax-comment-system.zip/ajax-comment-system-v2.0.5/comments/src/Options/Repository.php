<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Options;

use Illuminate\Support\Arr;
use Illuminate\Config\Repository as Config;

class Repository extends Config
{
    /**
     * All of the configuration options.
     *
     * @var array
     */
    protected $options = [];

    /**
     * Option groups to load from database.
     *
     * @var array
     */
    protected $loadOnly = ['general', 'moderation', 'mail', 'services'];

    /**
     * Create a new instance.
     *
     * @param \Illuminate\Config\Repository $config
     */
    public function __construct(Config $config)
    {
        $this->items = $config->all();
    }

    /**
     * Get the specified configuration value.
     *
     * @param  string $key
     * @param  mixed  $default
     * @return mixed
     */
    public function get($key, $default = null)
    {
        if (is_null($key)) {
            return array_merge($this->items, $this->options);
        }

        // Extract option group name.
        if (!$group = $this->extractGroupName($key)) {
           return parent::get($key, $default);
        }

        // If the option item was already loaded.
        if (isset($this->options[$key])) {
            return array_merge(parent::get($key, []), $this->options[$key]);
        }

        // Load option group.
        if (!isset($this->options[$group])) {
            $this->loadGroup($group);
        }

        // If option group exists in database.
        if (isset($this->options[$group])) {
            $options = array_merge(parent::get($group, []), $this->options[$group]);

            return Arr::get([$group => $options], $key, $default);
        }

        return parent::get($key, $default);
    }

    /**
     * Set a given configuration value.
     *
     * @param  array|string $key
     * @param  mixed $value
     * @return void
     */
    public function set($key, $value = null)
    {
        if (is_array($key)) {
            foreach ($key as $innerKey => $innerValue) {
                Arr::set($this->options, $innerKey, $innerValue);
            }
        } else {
            Arr::set($this->options, $key, $value);
        }

        parent::set($key, $value);
    }

    /**
     * Load a option group from database.
     *
     * @param  string $group
     * @return void
     */
    public function loadGroup($group)
    {
        $this->options[$group] = [];

        foreach ($this->getGroup($group) as $option) {
            $value = $this->castValue($option->option_value, $option->option_type);

            $this->set($group.'.'.$option->option_key, $value);
        }
    }

    /**
     * Select option group from database.
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getGroup($group)
    {
        return Option::where('option_group', $group)->get();
    }

    /**
     * Save all options.
     *
     * @param  string $group
     * @return void
     */
    public function save($group = null)
    {
        if ($group) {
            return $this->saveGroup($group);
        }

        foreach ($this->options as $group => $options) {
            $this->saveGroup($group);
        }
    }

    /**
     * Save group options.
     *
     * @param  string $group
     * @return void
     */
    public function saveGroup($group)
    {
        if (!in_array($group, $this->loadOnly)) {
            return;
        }

        $options = Arr::get($this->options, $group);

        foreach ($options as $key => $value) {
            $this->updateOrCreate($group, $key, $value);
        }
    }

    /**
     * Update or create option.
     *
     * @param  string $group
     * @param  string $key
     * @param  mixed  $value
     * @return \ACS\Options\Option
     */
    public function updateOrCreate($group, $key, $value)
    {
        $type = gettype($value);

        if ($type === 'array' || $type === 'object') {
            $value = json_encode($value);
        }

        return Option::updateOrCreate(
            ['option_group' => $group, 'option_key' => $key],
            ['option_value' => $value, 'option_type' => $type]
        );
    }

    /**
     * Delete option from database.
     *
     * @param  string $group
     * @param  string|null $key
     * @return
     */
    public function delete($group, $key = null)
    {
        $query = Option::where('option_group');

        if ($key) {
            $query->where('option_key')->limit(1);
        }

        return $query->delete();
    }

    /**
     * Extract group name from key.
     *
     * @param  string $key
     * @return string|false
     */
    protected function extractGroupName($key)
    {
        $segments = explode('.', $key);

        $group = isset($segments[0]) ? $segments[0] : $key;

        if (in_array($group, $this->loadOnly)) {
            return $group;
        }
    }

    /**
     * Cast a value to a native PHP type.
     *
     * @param  string $value
     * @param  mixed  $type
     * @return mixed
     */
    protected function castValue($value, $type)
    {
        if (is_null($value)) {
            return $value;
        }

        switch ($type) {
            case 'int':
            case 'integer':
                return (int) $value;

            case 'real':
            case 'float':
            case 'double':
                return (float) $value;

            case 'string':
                return (string) $value;

            case 'bool':
            case 'boolean':
                return (bool) $value;

            case 'object':
                return json_decode($value);

            case 'array':
            case 'json':
                return json_decode($value, true);

            default:
                return $value;
        }
    }

    /**
     * Set which option groups to load from database.
     *
     * @param  array $groups
     * @return void
     */
    public function loadOnly(array $groups)
    {
        $this->loadOnly = $groups;
    }
}
