<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Auth;

use Illuminate\Container\Container;

class Auth
{
    /**
     * The authentication guard instance.
     *
     * @var \ACS\Auth\Guard
     */
    protected static $guard;

    /**
     * Register the authentication service.
     *
     * @param  \Illuminate\Container\Container $app
     * @return void
     */
    public static function register(Container $app)
    {
        if (!$model = $app->userModel()) {
            return;
        }

        static::$guard = new Guard($model, new Session);

        if ($app['encrypter']) {
            static::$guard->setCookie($app['cookie']);
        }
    }

    /**
     * Call guard methods dynamically.
     *
     * @param  string $method
     * @param  array  $arguments
     * @return mixed
     */
    public static function __callStatic($method, $arguments)
    {
        if (isset(static::$guard)) {
            return call_user_func_array([static::$guard, $method], $arguments);
        }
    }
}
