<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Auth;

class Hasher
{
    /**
     * Hash the given value.
     *
     * @param  string $value
     * @return string
     */
    public static function make($password)
    {
        // return md5($password);

        return password_hash($password, PASSWORD_BCRYPT);
    }

    /**
     * Check the given plain value against a hash.
     *
     * @param  string  $value
     * @param  string  $hashedValue
     * @return bool
     */
    public static function check($value, $hashedValue)
    {
        // return md5($value) === $hashedValue;

        return password_verify($value, $hashedValue);
    }
}
