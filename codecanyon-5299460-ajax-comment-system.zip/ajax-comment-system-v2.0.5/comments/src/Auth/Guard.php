<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Auth;

use Illuminate\Support\Str;
use Hazzard\Cookie\CookieJarInterface;
use Illuminate\Database\Eloquent\Model;

class Guard
{
    /**
     * The currently authenticated user.
     *
     * @var \Illuminate\Database\Eloquent\Model
     */
    protected $user;

    /**
     * @var \ACS\Auth\Session
     */
    protected $session;

    /**
     * @var \Hazzard\Cookie\CookieJarInterface
     */
    protected $cookie;

    /**
     * Indicates if the logout method has been called.
     *
     * @var bool
     */
    protected $loggedOut = false;

    /**
     * Indicates if a token user retrieval has been attempted.
     *
     * @var bool
     */
    protected $tokenRetrievalAttempted = false;

    /**
     * Create a new authentication guard.
     *
     * @param string $model
     * @param \ACS\Auth\Session $session
     */
    public function __construct($model, Session $session)
    {
        $this->model = $model;
        $this->session = $session;
    }

    /**
     * Determine if the current user is authenticated.
     *
     * @return bool
     */
    public function check()
    {
        return !is_null($this->user());
    }

    /**
     * Get the authenticated user.
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function user()
    {
        if ($this->loggedOut) {
            return;
        }

        if (!is_null($this->user)) {
            return $this->user;
        }

        $id = $this->session->get($this->getName());

        $user = null;

        if (!is_null($id)) {
            $user = $this->retrieveUserById($id);
        }

        $recaller = $this->getRecaller();

        if (is_null($user) && !is_null($recaller)) {
            $user = $this->getUserByRecaller($recaller);

            if ($user) {
                $this->updateSession($user->getKey());
            }
        }

        return $this->user = $user;
    }

    /**
     * Attempt to authenticate a user using the given credentials.
     *
     * @param  array $credentials
     * @param  bool  $remember
     * @param  bool  $login
     * @return bool
     */
    public function attempt(array $credentials = [], $remember = false, $login = true)
    {
        $user = $this->retrieveUser($credentials);

        if ($user && $this->validateCredentials($user, $credentials)) {
            if ($login) {
                $this->login($user, $remember);
            }

            return true;
        }

        return false;
    }

    /**
     * Log a user in.
     *
     * @param  \Illuminate\Database\Eloquent\Model $user
     * @param  bool $remember
     * @return void
     */
    public function login(Model $user, $remember = false)
    {
        $this->updateSession($user->getKey());

        if ($remember) {
            if (empty($user->remember_token)) {
                $this->refreshRememberToken($user);
            }

            $this->setRecallerCookie($user);
        }

        $this->setUser($user);
    }

    /**
     * Log the user out.
     *
     * @return void
     */
    public function logout()
    {
        if (!is_null($this->user)) {
            $this->refreshRememberToken($this->user);
        }

        $this->session->delete($this->getName());

        if (isset($this->cookie)) {
            $this->cookie->forget($this->getRecallerName());
        }

        $this->user = null;

        $this->loggedOut = true;
    }

    /**
     * Retrieve a user by the given credentials.
     *
     * @param  array $credentials
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function retrieveUser(array $credentials)
    {
        $query = $this->createModel()->newQuery();

        foreach ($credentials as $key => $value) {
            if ($key !== 'password') {
                $query->where($key, $value);
            }
        }

        return $query->first();
    }

    /**
     * Retrieve a user by the given id.
     *
     * @param  int $id
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function retrieveUserById($id)
    {
        $keyName = $this->createModel()->getKeyName();

        return $this->retrieveUser([$keyName => $id]);
    }

    /**
     * Validate a user against the given credentials.
     *
     * @param  \Illuminate\Database\Eloquent\Model $user
     * @param  array $credentials
     * @return bool
     */
    public function validateCredentials(Model $user, array $credentials)
    {
        return Hasher::check($credentials['password'], $user->password);
    }

    /**
     * Refresh the "remember me" token for the user.
     *
     * @param  \Illuminate\Database\Eloquent\Model $user
     * @return void
     */
    protected function refreshRememberToken(Model $user)
    {
        $user->remember_token = Str::random(60);

        $user->save();
    }

    /**
     * Set the current user.
     *
     * @param  \Illuminate\Database\Eloquent\Model $user
     * @return void
     */
    protected function setUser(Model $user)
    {
        $this->user = $user;
    }

    /**
     * Update the session with the given ID.
     *
     * @param  string $id
     * @return void
     */
    protected function updateSession($id)
    {
        $this->session->set($this->getName(), $id);
    }

    /**
     * Set the recaller cookie.
     *
     * @param  \Illuminate\Database\Eloquent\Model $user
     * @return void
     */
    protected function setRecallerCookie(Model $user)
    {
        if (isset($this->cookie)) {
            $value = $user->getKey().'|'.$user->remember_token;

            $this->cookie->forever($this->getRecallerName(), $value);
        }
    }

    /**
     * Get a user by its recaller ID.
     *
     * @param  string $recaller
     * @return mixed
     */
    protected function getUserByRecaller($recaller)
    {
        if ($this->validRecaller($recaller) && !$this->tokenRetrievalAttempted) {
            $this->tokenRetrievalAttempted = true;

            list($id, $remember_token) = explode('|', $recaller, 2);

            return $this->retrieveUser(compact('id', 'remember_token'));
        }
    }

    /**
     * Determine if the recaller cookie is in a valid format.
     *
     * @param  string $recaller
     * @return bool
     */
    protected function validRecaller($recaller)
    {
        if (!is_string($recaller) || !Str::contains($recaller, '|')) {
            return false;
        }

        $segments = explode('|', $recaller);

        return count($segments) == 2 && trim($segments[0]) !== '' && trim($segments[1]) !== '';
    }

    /**
     * Get the decrypted recaller cookie.
     *
     * @return string|null
     */
    protected function getRecaller()
    {
        if (isset($this->cookie)) {
            return $this->cookie->get($this->getRecallerName());
        }
    }

    /**
     * Get the name of the cookie used to store the "recaller".
     *
     * @return string
     */
    public function getRecallerName()
    {
        return 'remember_'.md5(get_class($this));
    }

    /**
     * Get a unique identifier for the auth session value.
     *
     * @return string
     */
    public function getName()
    {
        return 'login_'.md5(get_class($this));
    }

    /**
     * Create a new instance of the model.
     *
     * @return \Illuminate\Database\Eloquent\Model
     */
    public function createModel()
    {
        $class = '\\'.ltrim($this->model, '\\');

        return new $class;
    }

    /**
     * Set the cookie instance.
     *
     * @param \Hazzard\Cookie\CookieJarInterface $cookie
     */
    public function setCookie(CookieJarInterface $cookie)
    {
        $this->cookie = $cookie;
    }
}
