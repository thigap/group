<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Auth;

use Illuminate\Support\Arr;

class Session
{
    /**
     * Set a key / value pair or array of key / value pairs in the session.
     *
     * @param  string|array $key
     * @param  mixed|null   $value
     * @return void
     */
    public function set($key, $value = null)
    {
        if (!is_array($key)) {
            $key = [$key => $value];
        }

        foreach ($key as $arrayKey => $arrayValue) {
            Arr::set($_SESSION, $arrayKey, $arrayValue);
        }
    }

    /**
     * Retrieve an item from the session.
     *
     * @param  string $key
     * @param  mixed  $default
     * @return mixed
     */
    public function get($key, $default = null)
    {
        return Arr::get($_SESSION, $key, $default);
    }

    /**
     * Remove an item from the session.
     *
     * @param  string $key
     * @return void
     */
    public function delete($key)
    {
        Arr::forget($_SESSION, $key);
    }
}
