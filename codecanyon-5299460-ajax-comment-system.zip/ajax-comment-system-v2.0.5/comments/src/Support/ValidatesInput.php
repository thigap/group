<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Support;

use Illuminate\Contracts\Validation\ValidationException;

trait ValidatesInput
{
    /**
     * Validate the given input with the given rules.
     *
     * @param  array $input
     * @param  array $rules
     * @param  array $messages
     * @return void
     *
     * @throws \Illuminate\Contracts\Validation\ValidationException
     */
    public function validate($input, array $rules, array $messages = [])
    {
        $validator = $this['validator']->make($input, $rules, $messages);

        if ($validator->fails()) {
            throw new ValidationException($validator->errors());
        }
    }

    /**
     * Register a custom validator extension.
     *
     * @param  string $rule
     * @param  \Closure|string $extension
     * @param  string $message
     * @return $this
     */
    public function extendValidator($rule, $extension, $message = null)
    {
        $this['validator']->extend($rule, $extension, $message);

        return $this;
    }
}
