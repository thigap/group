<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Support;

class Captcha
{
    /**
     * Session name.
     *
     * @var string
     */
    public $session = '__captcha';

    /**
     * Captcha character length.
     *
     * @var integer
     */
    public $length = 4;

    /**
     * Image width.
     *
     * @var integer
     */
    public $width = 80;

    /**
     * Image height.
     *
     * @var integer
     */
    public $height = 34;

    /**
     * Background RGB color.
     *
     * @var array
     */
    public $backgroundRGB = [52, 73, 94];

    /**
     * Line RGB color.
     *
     * @var array
     */
    public $lineRGB = [233, 239, 239];

    /**
     * Text RGB color.
     *
     * @var array
     */
    public $textRGB = [255, 255, 255];

    /**
     * Get captcha image.
     *
     * @return string
     */
    public function image()
    {
        if (!isset($_SESSION[$this->session])) {
            $this->refresh();
        }

        $text = $_SESSION[$this->session];

        $image = imagecreatetruecolor($this->width, $this->height);

        // Set background.
        list($R, $G, $B) = $this->backgroundRGB;
        $backgroundColor = imagecolorallocate($image, $R, $G, $B);

        imagefill($image, 0, 0, $backgroundColor);

        // Line color.
        list($R, $G, $B) = $this->lineRGB;
        $lineColor = imagecolorallocate($image, $R, $G, $B);

        // Text color.
        list($R, $G, $B) = $this->textRGB;
        $textColor = imagecolorallocate($image, $R, $R, $B);

        // Set line 1.
        list($x1, $y1, $x2, $y2) = $this->getLine1Coordinates();
        imageline($image, $x1, $y1, $x2, $y2, $lineColor);

        // Set line 2.
        list($x1, $y1, $x2, $y2) = $this->getLine2Coordinates();
        imageline($image, $x1, $y1, $x2, $y2, $textColor);

        // Set text.
        list($x, $y) = $this->getTextCoordinates();
        imagestring($image, 5, $x, $y, $text, $textColor);

        // Output image.
        ob_start();

        imagejpeg($image, null, 100);

        $imageData = ob_get_contents();

        ob_end_clean();

        return 'data:image/jpeg;base64,'.base64_encode($imageData);
    }

    /**
     * Get text coordinates.
     *
     * @return array
     */
    protected function getTextCoordinates()
    {
        return [$this->width / 2 - 15, $this->height / 2 - 7];
    }

    /**
     * Get line 1 coordinates.
     *
     * @return array
     */
    protected function getLine1Coordinates()
    {
        return [1, 1, $this->width / 2, $this->height];
    }

    /**
     * Get line 2 coordinates.
     *
     * @return array
     */
    protected function getLine2Coordinates()
    {
        return [$this->width * 0.7, 1, $this->width / 2, $this->height];
    }

    /**
     * Refresh captcha.
    *
     * @return void
     */
    public function refresh()
    {
        $_SESSION[$this->session] = substr(md5(rand()), 0, $this->length);
    }

    /**
     * Check if the captcha is valid.
     *
     * @param  string $value
     * @param  bool   $refresh
     * @return bool
     */
    public function check($value, $refresh = true)
    {
        $success = isset($_SESSION[$this->session]) && $value === $_SESSION[$this->session];

        if ($refresh) {
            $this->refresh();
        }

        return $success;
    }

    /**
     * Validator extension.
     *
     * @param  string $attribute
     * @param  string $value
     * @param  array  $parameters
     * @return bool
     */
    public function validate($attribute, $value, $parameters)
    {
        return $this->check($value);
    }
}
