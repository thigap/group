<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Support;

use Illuminate\Support\Arr;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Contracts\Validation\ValidationException;

trait ResponseTrait
{
    /**
     * Respond with JSON.
     *
     * @param  mixed $data
     * @param  int   $statusCode
     * @return string
     */
    public function json($data = null, $statusCode = 200)
    {
        $this->header('Content-Type', 'application/json');

        http_response_code($statusCode);

        if ($data instanceof Arrayable) {
            $data = $data->toArray();
        } elseif ($data instanceof ValidationException) {
            $data = Arr::flatten($data->errors()->getMessages());
        }

        return json_encode($data);
    }

    /**
     * Send header.
     *
     * @param  string $header
     * @param  string $value
     * @return void
     */
    public function header($header, $value)
    {
        header("$header: $value");
    }
}
