<?php

if (!function_exists('gravatar')) {
    /**
     * Get Gravatar image by email.
     *
     * @param  string $email
     * @param  string $default Default imageset to use [ 404 | mm | identicon | monsterid | wavatar ]
     * @param  int    $size
     * @param  int    $rating  Maximum rating (inclusive) [ g | pg | r | x ]
     * @return string
     */
    function gravatar($email, $default = 'monsterid', $size = 100, $rating = 'g')
    {
        $default = Comments::config('general.default_gravatar', $default);

        $id = md5(strtolower(trim($email)));

        return "//gravatar.com/avatar/{$id}/?d={$default}&s={$size}&r=$rating";
    }
}

if (!function_exists('absint')) {
    /**
     * Convert a value to non-negative integer.
     *
     * @param  mixed $value
     * @return int
     */
    function absint($value)
    {
        return abs(intval($value));
    }
}

if (!function_exists('mb_strlen')) {
    /**
     * Get string length.
     *
     * @param  string $str
     * @param  string $encoding
     * @return string
     */
    function mb_strlen($str, $encoding)
    {
        return strlen($str);
    }
}

if (!function_exists('redirect')) {
    /**
     * Redirect to the given URL.
     *
     * @param  string $url
     * @return void
     */
    function redirect($url)
    {
        if (headers_sent()) {
            echo '<script>window.location.href="'.$url.'";</script>';
        } else {
            header("Location: $url");
        }

        exit;
    }
}

if (!function_exists('current_url')) {
    /**
     * Get the current Url.
     *
     * @return string
     */
    function current_url()
    {
        return (isset($_SERVER['HTTPS']) ? 'https' : 'http').'://'.
                $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    }
}

if (!function_exists('csrf_field')) {
    /**
     * Generate a CSRF token form field.
     *
     * @return string
     */
    function csrf_field()
    {
        return '<input type="hidden" name="_token" value="'.csrf_token().'">';
    }
}

if (!function_exists('csrf_token')) {
    /**
     * Get the CSRF token value.
     *
     * @return string
     *
     * @throws RuntimeException
     */
    function csrf_token()
    {
        return Comments::getInstance()['csrf']->getToken();
    }
}
