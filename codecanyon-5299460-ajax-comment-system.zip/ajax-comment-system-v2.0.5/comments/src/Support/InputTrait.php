<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Support;

use Illuminate\Support\Arr;

trait InputTrait
{
    /**
     * @var array
     */
    protected $inputSource;

    /**
     * Retrieve an input item from the request.
     *
     * @param  string $key
     * @param  mixed  $default
     * @return string|array
     */
    public function input($key = null, $default = null)
    {
        $input = isset($this->inputSource) ? $this->inputSource : $_REQUEST;

        return Arr::get($input, $key, $default);
    }

    /**
     * Get a subset of the items from the input data.
     *
     * @param  array $keys
     * @return array
     */
    public function only($keys)
    {
        $keys = is_array($keys) ? $keys : func_get_args();

        $results = [];

        $input = $this->input();

        foreach ($keys as $key) {
            Arr::set($results, $key, Arr::get($input, $key));
        }

        return $results;
    }

    /**
     * Set the input source.
     *
     * @param  array $input
     * @param  bool  $trim
     * @return void
     */
    public function setInputSource(array $input, $trim = true)
    {
        if ($trim) {
            $input = array_map('trim', $input);
        }

        $this->inputSource = $input;
    }
}
