<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Support;

use Illuminate\Support\Str;

class CsrfTokenVerifier
{
    /**
     * Verify csrf token.
     *
     * @return bool
     */
    public function verifyToken()
    {
        return $this->equals($this->getToken(), $this->getRequestToken());
    }

    /**
     * Get the token from request.
     *
     * @return string
     */
    public function getRequestToken()
    {
        $token = isset($_REQUEST['_token']) ? $_REQUEST['_token'] : null;

        if (!$token) {
            $token = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? $_SERVER['HTTP_X_CSRF_TOKEN'] : null;
        }

        return $token;
    }

    /**
     * Compares two strings using a constant-time algorithm.
     *
     * https://github.com/laravel/framework/blob/5.1/src/Illuminate/Support/Str.php#L289
     *
     * @param  string $knownString
     * @param  string $userInput
     * @return bool
     */
    protected function equals($knownString, $userInput)
    {
        if (!is_string($knownString)) {
            $knownString = (string) $knownString;
        }

        if (!is_string($userInput)) {
            $userInput = (string) $userInput;
        }

        if (function_exists('hash_equals')) {
            return hash_equals($knownString, $userInput);
        }

        $knownLength = mb_strlen($knownString);

        if (mb_strlen($userInput) !== $knownLength) {
            return false;
        }

        $result = 0;

        for ($i = 0; $i < $knownLength; ++$i) {
            $result |= (ord($knownString[$i]) ^ ord($userInput[$i]));
        }

        return 0 === $result;
    }

    /**
     * Get the CSRF token value.
     *
     * @return string
     */
    public function getToken()
    {
        return isset($_SESSION['_token']) ? $_SESSION['_token'] : null;
    }

    /**
     * Regenerate the CSRF token value.
     *
     * @return void
     */
    public function regenerateToken()
    {
        $_SESSION['_token'] = Str::random(40);
    }
}
