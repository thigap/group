<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Support;

use PDO;
use Parsedown;
use JBBCode\Parser;
use Hazzard\Mail\Mail;
use ACS\Support\Captcha;
use ACS\Formatting\Smilies;
use Hazzard\Cookie\CookieJar;
use ACS\Formatting\Clickable;
use Illuminate\Events\Dispatcher;
use Hazzard\Validation\Validator;
use Hazzard\Encryption\Encrypter;
use JBBCode\DefaultCodeDefinitionSet;
use ACS\Options\Repository as Options;
use ACS\Formatting\BBCodeDefinitionSet;
use Illuminate\Config\Repository as Config;
use Illuminate\Database\Capsule\Manager as Capsule;

trait BootstrapTrait
{
    /**
     * Bind paths.
     *
     * @param  string $basePath
     * @return void
     */
    public function bindPaths($basePath)
    {
        $this->bindPath('base', realpath($basePath));
        $this->bindPath('app', $this['paths.base'].'/comments');
        $this->bindPath('views', $this['paths.app'].'/views');
        $this->bindPath('config', $this['paths.base'].'/config');
    }

    /**
     * Bind path.
     *
     * @param string $key
     * @param string $valuen
     */
    public function bindPath($key, $value)
    {
        $this["paths.$key"] = $value;
    }

    /**
     * Register the configuration service.
     *
     * @return void
     */
    public function registerConfig()
    {
        $this['config'] = new Config;

        $this->loadConfig(['database', 'general', 'moderation', 'services']);
    }

    /**
     * Register the event dispatcher service.
     *
     * @return void
     */
    public function registerEvents()
    {
        $this['events'] = new Dispatcher($this);
    }

    /**
     * Register the database service.
     *
     * @return void
     */
    public function registerDatabase()
    {
        $capsule = new Capsule($this);
        $capsule->addConnection($this['config']['database']);
        $capsule->bootEloquent();
        $capsule->setFetchMode(PDO::FETCH_OBJ);

        $this['db'] = $capsule->getDatabaseManager();
    }

    /**
     * Register the options service.
     *
     * @return void
     */
    public function registerOptions()
    {
        $this['config'] = new Options($this['config']);
    }

    /**
     * Register the validator service.
     *
     * @return void
     */
    public function registerValidator()
    {
        $this->singleton('validator', function ($app) {
            $this->loadConfig('validation');

            $validator = new Validator($app);
            $validator->setLines($app['config']['validation']);
            $validator->extend('captcha', 'ACS\Support\Captcha@validate');

            return $validator->getFactory();
        });
    }

    /**
     * Register the encrypter service.
     *
     * @return void
     */
    public function registerEncrypter()
    {
        $this->singleton('encrypter', function ($app) {
            $key    = $app['config']['general.key'];
            $cipher = $app['config']['general.cipher'];

            if (!empty($key)) {
                return new Encrypter($key, $cipher);
            }
        });
    }

    /**
     * Register the cookie service.
     *
     * @return void
     */
    public function registerCookie()
    {
        $this->singleton('cookie', function ($app) {
            $cookie = new CookieJar;

            if ($app['encrypter']) {
                $cookie->setEncrypter($app['encrypter']);
            }

            return $cookie;
        });
    }

    /**
     * Register the mailer service.
     *
     * @return void
     */
    public function registerMailer()
    {
        $this->singleton('mailer', function($app) {
            $this->loadConfig('mail');

            return (new Mail($app))->setViewStoragePath($app['paths.views']);
        });
    }

    /**
     * Register the captcha service.
     *
     * @return void
     */
    public function registerCaptcha()
    {
        $this->singleton('captcha', function($app) {
            return new Captcha;
        });
    }

    /**
     * Register the smilies.
     *
     * @return void
     */
    public function registerSmilies()
    {
        $this->singleton('smilies', function ($app) {
            $this->loadConfig('smilies');

            $path = $app['config']['smilies.path'];
            $smilies = $app['config']['smilies.smilies'];

            return new Smilies($smilies, $path);
        });
    }

    /**
     * Register the clickable class.
     *
     * @return void
     */
    public function registerClickable()
    {
        $this->singleton('clickable', function ($app) {
            return new Clickable;
        });
    }

    /**
     * Register the Markdown parser.
     *
     * @return void
     */
    public function registerMarkdownParser()
    {
        $this->singleton('markdown', function ($app) {
            return $parsedown = (new Parsedown)->setMarkupEscaped(true);
        });
    }

    /**
     * Register the BBCode parser.
     *
     * @return void
     */
    public function registerBBCodeParser()
    {
        $this->singleton('bbcode', function ($app) {
            return (new Parser)->addCodeDefinitionSet(new DefaultCodeDefinitionSet)
                               ->addCodeDefinitionSet(new BBCodeDefinitionSet);
        });
    }

    /**
     * Register class aliases.
     *
     * @return void
     */
    public function registerClassAliases()
    {
        $aliases = [
            'ACS\Auth\Auth'         => 'Auth',
            'ACS\Comments\Comment'  => 'Comment',
            'ACS\Comments\Comments' => 'Comments',
        ];

        foreach ($aliases as $class => $alias) {
            class_alias($class, $alias);
        }
    }

    /**
     * Register the CSRF verifier service.
     *
     * @return void
     */
    public function registerCsrfVerifier()
    {
        $this['csrf'] = new CsrfTokenVerifier;

        if (!$this['csrf']->getToken()) {
            $this['csrf']->regenerateToken();
        }
    }
}
