<?php

/**
 * This file is part of Ajax Comment System.
 *
 * (c) HazzardWeb <hazzardweb@gmail.com>
 *
 * For the full copyright and license information, please visit:
 * http://codecanyon.net/licenses/standard
 */

namespace ACS\Support;

class Akismet
{
    /**
     *  API key.
     *
     * @var string
     */
    protected $key;

    /**
     * Create a new akismet instance.
     *
     * @param string $key
     */
    public function __construct($key)
    {
        $this->key = $key;
    }

    /**
     * Check if comment is spam.
     *
     * Comment parameters:
     * https://akismet.com/development/api/#comment-check
     *
     * @param  array $comment
     * @return bool  Returns true if the comment is spam, false otherwise.
     */
    public function commentCheck(array $comment)
    {
        $url = "https://{$this->key}.rest.akismet.com/1.1/comment-check";

        return $this->httpPost($url, $comment) === 'true';
    }

    /**
     * Perform a cURL post.
     *
     * @param  string $url
     * @param  array  $data
     * @return string
     */
    protected function httpPost($url, $data)
    {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, count($data));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);

        curl_close($ch);

        return $result;
    }
}
