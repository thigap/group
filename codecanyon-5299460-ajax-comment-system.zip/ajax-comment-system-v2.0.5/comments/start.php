<?php

use ACS\Comments\Comments;

if (session_id() === '' && !headers_sent()) {
	session_start();
}

if (!defined('ACS')) {
    define('ACS', true);
}

require_once __DIR__.'/src/Support/helpers.php';
require_once __DIR__.'/../vendor/autoload.php';

Comments::setInstance($app = new Comments);

$app->bindPaths(__DIR__.'/..');

$app->registerConfig();
$app->registerEvents();
$app->registerDatabase();
// $app->registerOptions();
$app->registerCaptcha();
$app->registerValidator();
$app->registerMailer();
$app->registerEncrypter();
$app->registerCookie();
$app->registerSmilies();
$app->registerClickable();
$app->registerMarkdownParser();
$app->registerBBCodeParser();
$app->registerClassAliases();
$app->registerCsrfVerifier();

Auth::register($app);

if ($app->debug()) {
    ini_set('display_errors', 'On');
}

// date_default_timezone_set('UTC');

require $app['paths.app'].'/events.php';
