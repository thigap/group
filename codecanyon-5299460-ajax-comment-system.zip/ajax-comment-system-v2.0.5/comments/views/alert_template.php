<script id="alertTemplate" type="text/template">
    <div class="alert alert-danger">
        <span class="close" data-dismiss="alert">&times;</span>
        {% if (typeof message === 'object') { %}
            <ul>
                {% for (var i in message) { %}
                    <li>{%= message[i] %}</li>
                {% } %}
            </ul>
        {% } else { %}
            {%= message %}
        {% } %}
    </div>
</script>
