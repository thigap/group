<?php if (!defined('ACS')) exit('No direct script access allowed.');

$comments = Comments::getInstance();
$config = $comments['config'];
$pageId = isset($pageId) ? $pageId : current_url();
$maxlength = $config['general.maxlength'];

?>
<div class="comments">
    <h3 class="total"></h3>
    <div class="clearfix hr"></div>

    <?php if (!$config['general.guest'] && !$comments->authUser()) { ?>
        <div class="alert alert-warning">You must be logged in to leave comments.</div>
    <?php } else { ?>
        <form method="POST" class="post-form clearfix">
            <?php if (!$comments->authUser()) { ?>
                <div class="form-group">
                    <input type="text" name="author_name" class="form-control" placeholder="Name">
                </div>
                <div class="form-group">
                    <input type="text" name="author_email" class="form-control" placeholder="Email">
                </div>
                <div class="form-group">
                    <input type="text" name="author_url" class="form-control" placeholder="Url">
                </div>
            <?php } ?>

            <?php if ($comments->captchaRequired()) { ?>
            <div class="form-group captcha">
                <div class="input-group">
                    <input type="text" name="captcha" class="form-control" placeholder="Captcha" autocomplete="off">
                    <span class="input-group-addon">
                        <img src="<?php echo $comments['captcha']->image(); ?>" title="Refresh">
                    </span>
                </div>
            </div>
            <?php } ?>

            <?php if ($comments->authUser()) { ?>
                <div class="avatar pull-left"><img src="<?php echo $comments->authUser('avatar'); ?>"></div>
            <?php } ?>

            <div class="postbox">
                <div class="form-group">
                    <textarea name="content" class="form-control" wrap="hard" maxlength="<?php echo $maxlength; ?>" placeholder="Comment"></textarea>
                </div>

                <div class="pull-left">
                    <button type="submit" class="btn btn-primary" data-loading-text="Loading...">Post</button>
                    <button type="button" class="btn btn-default cancel">Cancel</button>
                </div>

                <?php if ($maxlength) { ?>
                    <div class="character-count pull-right"><?php echo $maxlength; ?></div>
                <?php } ?>

                <div class="clearfix"></div>
                <div class="response"></div>
            </div>

            <input type="hidden" name="root_id">
            <input type="hidden" name="parent_id">
            <input type="hidden" name="action" value="post">
            <input type="hidden" name="page_id" value="<?php echo $pageId; ?>">
            <input type="hidden" name="permalink" value="<?php echo current_url(); ?>">
            <input type="hidden" name="referrer" value="<?php echo isset($_SERVER['HTTP_REFERER']) ? e($_SERVER['HTTP_REFERER']) : ''; ?>">
        </form>

        <div class="placeholder">Leave a comment...</div>

        <div class="sort dropdown">
            <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
                Sort by
                <span class="current">Newest</span>
                <span class="caret"></span>
            </button>
            <ul class="dropdown-menu">
                <li>
                    <a href="#" data-sort="<?php echo $comments::SORT_NEWEST; ?>">
                        Newest <span class="glyphicon glyphicon-ok"></span>
                    </a>
                </li>
                <li>
                    <a href="#" data-sort="<?php echo $comments::SORT_OLDEST; ?>">
                        Oldest <span class="glyphicon glyphicon-ok"></span>
                    </a>
                </li>
                <?php if ($config['general.votes']) { ?>
                <li>
                    <a href="#" data-sort="<?php echo $comments::SORT_BEST; ?>">
                        Best <span class="glyphicon glyphicon-ok"></span>
                    </a>
                </li>
                <?php } ?>
            </ul>
        </div>
    <?php } ?>

    <div class="loader"></div>
    <ul class="list"></ul>
    <div class="text-center pagination-container"></div>
</div>

<?php
    require_once __DIR__.'/comment_template.php';
    require_once __DIR__.'/pagination_template.php';
    require_once __DIR__.'/alert_template.php';
?>

<script>
    jQuery(document).ready(function($) {
        new Comments($('.comments'), {
            ajaxUrl: "<?php echo $config['general.ajaxurl']; ?>",
            pageId: "<?php echo $pageId; ?>",
            sortBy: <?php echo $config['general.default_sort']; ?>,
            replies: <?php echo $config['general.replies'] ? 'true' : 'false' ?>,
            maxDepth: <?php echo $config['general.max_depth'] ?: 'null'; ?>,
            csrfToken: "<?php echo csrf_token(); ?>",
        });
    });
</script>
