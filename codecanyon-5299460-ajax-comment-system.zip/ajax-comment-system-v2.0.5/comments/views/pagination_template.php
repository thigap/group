<script id="paginationTemplate" type="text/template">
    <ul class="pagination pagination-sm">
        <li {% if (current_page === 1) { %} class="disabled" {% } %}>
            <a href="#!page={%= prev_page %}" data-page="{%= prev_page %}" title="Previous">&laquo;</a>
        </li>

        {% if (first_adjacent_page > 1) { %}
            <li>
                <a href="#!page=1" data-page="1">1</a>
            </li>
            {% if (first_adjacent_page > 2) { %}
               <li class="disabled"><a>...</a></li>
            {% } %}
        {% } %}

        {% for (var i = first_adjacent_page; i <= last_adjacent_page; i++) { %}
            <li {% if (current_page === i) { %} class="active" {% } %}>
                <a href="#!page={%= i %}" data-page="{%= i %}">{%= i %}</a>
            </li>
        {% } %}

        {% if (last_adjacent_page < last_page) { %}
            {% if (last_adjacent_page < last_page - 1) { %}
                <li class="disabled"><a>...</a></li>
            {% } %}
            <li><a href="#!page={%= last_page %}" data-page="{%= last_page %}">{%= last_page %}</a></li>
        {% } %}

        <li {% if (current_page === last_page) { %} class="disabled" {% } %}>
            <a href="#!page={%= next_page %}" data-page="{%= next_page %}" title="Next">&raquo</a>
        </li>
    </ul>
</script>
