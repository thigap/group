<?php if (!defined('ACS')) exit('No direct script access allowed.'); ?>

<script id="commentTemplate" type="text/template">
    <li class="comment" data-id="{%= id %}">
        <div class="content clearfix">
            <div class="avatar pull-left">
                {% if (author.url) { %}
                    <a href="{%= author.url %}" target="_blank"><img src="{%= author.avatar %}"></a>
                {% } else { %}
                    <img src="{%= author.avatar %}">
                {% } %}
            </div>

            <div class="body">
                <div class="header">
                    {% if (author.url) { %}
                        <a href="{%= author.url %}" target="_blank" class="author">{%= author.name %}</a>
                    {% } else { %}
                        <span class="author">{%= author.name %}</span>
                    {% } %}

                    {% if (parent) { %}
                        <a href="#!comment={%= parent.id %}" data-parent="{%= parent.id %}"
                           class="parent" title="in reply to {%= parent.author.name %}
                        ">
                            <span class="glyphicon glyphicon-share-alt"></span>
                            {%= parent.author.name %}
                        </a>
                    {% } %}

                    <span class="bullet">&bull;</span>

                    <a href="#!comment={%= id %}" class="time">
                        <time class="timeago" datetime="{%= created_at %}" title="{%= created_at %}"></time>
                    </a>

                    <span class="linked">Linked</span>

                    <div class="pull-right dropdown">
                        <span class="collapse" title="Collapse">−</span>
                        <span class="expand" title="Expand">+</span>

                        {% if ((quick_edit && status === '<?php echo Comment::APPROVED; ?>') || moderate) { %}
                            <div class="edit-menu">
                                <span class="sep"></span>
                                <div class="dropdown-toggle" data-toggle="dropdown">
                                    <span class="caret"></span>
                                </div>
                                <ul class="dropdown-menu">
                                    {% if (moderate) { %}
                                        <li><a href="{%= edit_link %}" class="edit">Edit</a></li>
                                        <li><a href="#" class="quick-edit">Quick Edit</a></li>
                                    {% } else { %}
                                        <li><a href="#" class="quick-edit">Edit</a></li>
                                    {% } %}
                                </ul>
                            </div>
                        {% } %}
                    </div>
                </div>

                <div class="on-hold{% if (status !== '<?php echo Comment::APPROVED; ?>') { %} show{% } %}">
                    Your comment is awaiting moderation.
                </div>

                <div class="text">{%= content.formated %}</div>

                <form method="POST" class="edit-form clearfix">
                    <input type="hidden" name="id" value="{%= id %}">
                    <input type="hidden" name="action" value="update">

                    <div class="form-group">
                        <textarea name="content" class="form-control" wrap="hard" maxlength="<?php echo $maxlength; ?>" data-content="{%= content.raw %}" placeholder="Comment" ></textarea>
                    </div>

                    <div class="pull-left">
                        <button type="submit" class="btn btn-primary" data-loading-text="Loading...">Save</button>
                        <button type="button" class="btn btn-default cancel">Cancel</button>
                    </div>

                    <?php if ($maxlength) { ?>
                        <div class="character-count pull-right"><?php echo $maxlength; ?></div>
                    <?php } ?>

                    <div class="clearfix"></div>
                    <div class="response"></div>
                </form>

                <div class="footer">
                    {% if (reply) { %}
                        <a href="#" class="reply" data-parent="{%= id %}" data-root="{%= root_id || id %}">Reply</a>
                    {% } %}

                    <?php if ($config['general.votes']) { ?>
                        <span class="bullet">&bull;</span>

                        <div class="votes">
                            <span class="upvotes" data-votes="{%= upvotes %}">
                                {%= upvotes || '' %}
                            </span>
                            <a href="#" title="Upvote"
                                <?php if ($comments->authUser()) { ?>
                                    class="upvote {%= (voted === 'up' ? 'voted' : '') %}"
                                <?php } else { ?>
                                    onclick="alert('You must be logged in to vote.')"
                                <?php } ?>
                            >
                                <span class="glyphicon glyphicon-thumbs-up"></span>
                            </a>

                            <span class="sep"></span>

                            <span class="downvotes" data-votes="{%= downvotes %}">
                                {%= downvotes || '' %}
                            </span>
                            <a href="#" title="Downvote"
                                <?php if ($comments->authUser()) { ?>
                                    class="downvote {%= (voted === 'down' ? 'voted' : '') %}"
                                <?php } else { ?>
                                    onclick="alert('You must be logged in to vote.')"
                                <?php } ?>
                            >
                                <span class="glyphicon glyphicon-thumbs-down"></span>
                            </a>
                        </div>
                    <?php } ?>
                </div>
            </div>

            <div class="replybox"></div>
        </div>

        <ul class="list children"></ul>
    </li>
</script>
