<?php if (!defined('ACS')) exit('No direct script access allowed.');

$message->subject("$comment->author_name replied to your comment");

?>
<div style="color: #555;">
<?php echo $comment->content; ?>
</div>
<br>
Go check it out! <br>
<a href="<?php echo $comment->permalink; ?>"><?php echo $comment->permalink; ?></a>
