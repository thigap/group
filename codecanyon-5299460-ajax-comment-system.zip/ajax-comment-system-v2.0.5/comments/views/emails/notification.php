<?php if (!defined('ACS')) exit('No direct script access allowed.');

$message->subject("New comment from $comment->author_name");

?>
From: <?php echo $comment->author_name; ?><br>
Email: <?php echo $comment->author_email; ?><br>
IP: <?php echo $comment->author_ip; ?><br>
Status: <?php echo $comment->status; ?><br>
Date: <?php echo $comment->created_at; ?><br>
Permalink: <a href="<?php echo $comment->permalink; ?>"><?php echo $comment->permalink; ?></a><br>
Edit link: <a href="<?php echo $comment->editLink; ?>"><?php echo $comment->editLink; ?></a><br>
<div style="color: #555;">
<?php echo $comment->content; ?>
</div>
