<?php if (!defined('ACS')) exit('No direct script access allowed.');

$app = Comments::getInstance();

$schema = $app['db']->getSchemaBuilder();

if (isset($_GET['force'])) {
    $schema->dropIfExists('comment_votes');
    $schema->dropIfExists('comments');
    $schema->dropIfExists('options');
    $schema->dropIfExists('users');
}

/**
 * Create `users` table.
 */
if ($app->userModel()) {
    $schema->create('users', function ($table) {
        $table->increments('id');
        $table->string('name');
        $table->string('email')->unique();
        $table->string('password', 60);
        $table->enum('role', ['user', 'admin'])->default('user');
        $table->rememberToken();
        $table->timestamps();
    });
}

/**
 * Create `comments` table.
 */
$schema->create('comments', function ($table) {
    $table->increments('id');
    $table->string('page_id')->index();
    $table->integer('user_id')->unsigned()->nullable();
    $table->string('author_name', 100);
    $table->string('author_email');
    $table->string('author_url');
    $table->string('author_ip');
    $table->text('content');
    $table->enum('status', ['pending', 'approved', 'spam', 'trash'])->default('approved');
    $table->string('permalink');
    $table->string('user_agent');
    $table->integer('upvotes')->default(0);
    $table->integer('downvotes')->default(0);
    $table->integer('root_id')->unsigned()->nullable();
    $table->integer('parent_id')->unsigned()->nullable();
    $table->timestamps();

    $table->foreign('root_id')->references('id')->on('comments')->onDelete('cascade');
    $table->foreign('parent_id')->references('id')->on('comments')->onDelete('cascade');
});

/**
 * Create `comment_votes` table.
 */
$schema->create('comment_votes', function ($table) {
    $table->increments('id');
    $table->integer('user_id')->unsigned();
    $table->integer('comment_id')->unsigned();
    $table->enum('vote_type', ['up', 'down'])->default('up');
    $table->timestamps();

    // $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
    $table->foreign('comment_id')->references('id')->on('comments')->onDelete('cascade');
});

/*
$schema->create('comment_meta', function ($table) {
    $table->increments('id');
    $table->integer('comment_id')->unsigned();
    $table->string('meta_name');
    $table->text('meta_value');

    $table->foreign('comment_id')->references('id')->on('comments')->onDelete('cascade');
});
*/

/**
 * Create `options` table.
 */
$schema->create('options', function ($table) {
    $table->increments('id');
    $table->string('option_group');
    $table->string('option_key');
    $table->text('option_value')->nullable();
    $table->string('option_type');
});
