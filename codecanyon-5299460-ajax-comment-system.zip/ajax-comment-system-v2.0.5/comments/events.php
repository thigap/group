<?php if (!defined('ACS')) exit('No direct script access allowed.');

$events = Comments::getInstance()['events'];

/**
 * Get the authenticated user event.
 *
 * @param  string $attribute
 * @return mixed
 */
$events->listen('auth.user', function ($attribute = null) {
    if (!Auth::check()) {
        return;
    }

    if ($attribute) {
        return Auth::user()->{$attribute};
    }

    return Auth::user();

    // if (!isset($_SESSION['user'])) {
    //     return;
    // }

    // if ($attribute) {
    //     return $_SESSION['user'][$attribute];
    // }

    // return true;
});

/**
 * Check if the user is authenticated as admin event.
 *
 * @return bool
 */
$events->listen('admin.check', function () {
    return Auth::user() && Auth::user()->role === 'admin';

    // return isset($_SESSION['admin']);
});

/**
 * Admin log in event.
 *
 * @param  string $username
 * @param  string $password
 * @param  bool   $remember
 * @return bool
 */
$events->listen('admin.login', function ($username, $password, $remember = false) {
    $credentials = ['email' => $username, 'password' => $password];

    $user = Auth::retrieveUser($credentials);

    if ($user && Auth::validateCredentials($user, $credentials) && $user->role === 'admin') {
        Auth::login($user, $remember);

        return true;
    }

    // $success = $username === 'admin' && $password === 'admin';

    // if ($success) {
    //     $_SESSION['admin'] = true;
    // }

    // return $success;
});

/**
 * Admin log out event.
 *
 * @return void
 */
$events->listen('admin.logout', function () {
    Auth::logout();

    // unset($_SESSION['admin']);
});

/**
 * Comment model events.
 *
 * http://laravel.com/docs/5.0/eloquent#model-events
 */

Comment::saving(function ($comment) {
    // throw new Illuminate\Contracts\Validation\ValidationException(
    //     new Illuminate\Support\MessageBag(['error' => 'Custom error message.'])
    // );
});

Comment::saved(function ($comment) {

});
