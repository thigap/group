<?php

use ACS\AjaxHandler;

require __DIR__.'/start.php';

$comments = Comments::getInstance();

echo (new AjaxHandler($comments))->handle();
