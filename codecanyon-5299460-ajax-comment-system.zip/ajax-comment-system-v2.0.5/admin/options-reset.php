<?php

require __DIR__.'/load.php';

if (isset($_POST['submit'])) {
    ACS\Options\Option::query()->delete();
}

admin_header('Reset Settings', 'options-reset');
?>

<div class="row">
    <div class="col-md-6">
        <?php admin_options_alert(); ?>
        <form action="" method="POST">
            <div class="form-group">
                <p>If something went wrong with the settings saved in database you can reset them to the default values from the config files.</p>
            </div>
            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-danger">Reset Settings</button>
            </div>
        </form>
    </div>
</div>
