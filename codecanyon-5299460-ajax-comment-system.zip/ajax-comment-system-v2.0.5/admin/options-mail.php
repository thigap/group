<?php

require __DIR__.'/load.php';

admin_update_options();

$config = $comments['config'];
$drivers = ['smtp', 'mail', 'sendmail', 'mailgun', 'mandrill'];

admin_header('Mail Settings', 'options-mail');
?>

<div class="row">
    <div class="col-md-6">
        <?php admin_options_alert(); ?>
        <form action="" method="POST">
            <input type="hidden" name="group" value="mail">

            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
            </div>

            <div class="form-group">
                <label for="driver">Mail Driver</label>
                <select name="driver" id="driver" class="form-control">
                    <?php foreach ($drivers as $driver) {
                        echo '<option value="'.$driver.'" '.($config['mail.driver'] === $driver ? 'selected' : '').'>'.$driver.'</option>';
                    } ?>
                </select>
                <p class="help-block">For <code>mailgun</code> and <code>mandrill</code> set the API keys in the <a href="options-services.php#mailgun">Services</a> Settings.</p>
            </div>

            <div class="form-group">
                <label for="host">SMTP Host Address</label>
                <input type="text" name="host" id="host" value="<?php echo $config['mail.host']; ?>" class="form-control">
                <p class="help-block">The host address of the SMTP server.</p>
            </div>

            <div class="form-group">
                <label for="port">SMTP Host Port</label>
                <input type="text" name="port" id="port" value="<?php echo $config['mail.port']; ?>" class="form-control">
                <p class="help-block">The SMTP port used by your application to deliver e-mails.</p>
            </div>

            <div class="form-group">
                <label for="from_address">Global "From" Address</label>
                <input type="text" name="from[address]" id="from_address" placeholder="Email" value="<?php echo $config['mail.from.address'] ?>" class="form-control">
                <input type="text" name="from[name]" id="from_name" placeholder="Name" value="<?php echo $config['mail.from.name']; ?>" class="form-control">
                <p class="help-block">The name and address that is used globally for all e-mails.</p>
            </div>

            <div class="form-group">
                <label for="encryption">E-Mail Encryption Protocol</label>
                <input type="text" name="encryption" id="encryption" value="<?php echo $config['mail.encryption']; ?>" class="form-control">
                <p class="help-block">The encryption protocol that should be used when sending e-mails.</p>
            </div>

            <div class="form-group">
                <label for="username">SMTP Server Username</label>
                <input type="text" name="username" id="username" value="<?php echo $config['mail.username']; ?>" class="form-control">
                <p class="help-block">If your SMTP server requires a username for authentication set it here. You may also set the <code>password</code> value below this one.</p>
            </div>

            <div class="form-group">
                <label for="password">SMTP Server Password</label>
                <input type="text" name="password" id="password" value="<?php echo $config['mail.password']; ?>" class="form-control">
                <p class="help-block">The password required by your SMTP server.</p>
            </div>

            <div class="form-group">
                <label for="sendmail">Sendmail System Path</label>
                <input type="text" name="sendmail" id="sendmail" value="<?php echo $config['mail.sendmail']; ?>" class="form-control">
                <p class="help-block">Required when using the <code>sendmail</code> driver to send e-mails.</p>
            </div>

            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
    </div>
</div>

<?php admin_footer(); ?>
