<?php

require __DIR__.'/load.php';

admin_update_options();

$config = $comments['config'];

admin_header('Services Settings', 'options-services');
?>

<div class="row">
    <div class="col-md-6">
        <?php admin_options_alert(); ?>
        <form action="" method="POST">
            <input type="hidden" name="group" value="services">

            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
            </div>

            <div class="form-group">
                <label for="akismet_key">Akismet API Key</label>
                <input type="text" name="akismet_key" id="akismet_key" value="<?php echo $config['services.akismet_key']; ?>" class="form-control">
                <p class="help-block">Go to <a href="https://akismet.com/account/" target="_blank">akismet.com</a> to get your API key.</p>
            </div>

            <div class="form-group">
                <label for="mandrill">Mandrill API Key</label>
                <input type="text" name="mandrill[secret]" id="mandrill" value="<?php echo $config['services.mandrill.secret']; ?>" class="form-control">
                <p class="help-block">
                    Go to <a href="https://mandrill.com" target="_blank">mandrill.com</a> to get your API key.
                </p>
            </div>

            <div class="form-group">
                <label for="mailgun">Mailgun API Key</label>
                 <div class="input-group">
                    <span class="input-group-addon secret">secret</span>
                    <input type="text" name="mailgun[secret]" id="mailgun" value="<?php echo $config['services.mailgun.secret']; ?>" class="form-control">
                </div>
                <div class="input-group">
                    <span class="input-group-addon">domain</span>
                    <input type="text" name="mailgun[domain]" value="<?php echo $config['services.mailgun.domain']; ?>" class="form-control">
                </div>
                <p class="help-block">
                    Go to <a href="https://mailgun.com" target="_blank">mailgun.com</a> to get your API key.
                </p>
            </div>

            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
    </div>
</div>

<?php admin_footer(); ?>
