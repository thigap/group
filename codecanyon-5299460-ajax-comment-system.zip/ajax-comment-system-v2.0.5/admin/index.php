<?php

use Illuminate\Pagination\Paginator;

require __DIR__.'/load.php';

$comments = Comments::getInstance();

$status = isset($_GET['status']) ? $_GET['status'] : 'all';
$pageId = !empty($_GET['page_id']) ? e($_GET['page_id']) : null;

if (isset($_POST['action'])) {
    foreach ((array) $_POST['comments'] as $id) {
        if ($_POST['action'] === 'delete') {
            $comments->delete($id);
        } else {
            $comments->update(['id' => $id, 'status' => $_POST['action']]);
        }
    }

    redirect("?status=$status".($pageId?"&page_id=$pageId":''));
}

$query = Comment::orderBy('created_at', 'DESC')->loadUser()->with('parent.user');

if (!is_null($pageId)) {
    $query->where('page_id', $pageId);
}

if ($status === 'all') {
    $query->where('status', Comment::APPROVED)
          ->orWhere('status', Comment::PENDING);
} else {
    $query->where('status', $status);
}

Paginator::currentPageResolver(function () {
    return !empty($_GET['page']) ? $_GET['page'] : 1;
});

$paginator = $query->paginate()->setPath('index.php')->appends(['page_id' => $pageId]);

$statuses = Comment::statuses();;

$pageCount   = $comments->getPageCommentCount();
$statusCount = $comments->getStatusCount($pageId);

$title = $pageId ? 'Comments on &#8220;'.$pageId.'&#8221 <a href="?status=all" class="close">&times;</a>' : 'Comments';

admin_header($title, 'comments');

?>
<!-- Status filter -->
<ul class="status-filter">
    <?php foreach (array_merge(['all'], $statuses) as $i => $key) { ?>
        <li <?php echo $status === $key ? 'class="active"' : ''; ?>>
            <a href="?status=<?php echo $key.($pageId ? "&page_id=$pageId" : ''); ?>" class="<?php echo $key; ?>">
                <?php echo ucfirst($key); ?>
                <?php if ($key !== 'all') { ?>
                    <span class="count">(<?php echo isset($statusCount[$key]) ? $statusCount[$key] : 0; ?>)</span>
                <?php } ?>
            </a>
            <?php echo ($i < 4) ? '|' : ''; ?>
        </li>
    <?php } ?>
</ul>

<form action="" method="POST" id="bulk-actions">
<!-- Bulk actions -->
<div class="bulk-actions">
    <select name="action" class="form-control">
        <option value="0">Bulk Actions</option>
        <?php
        if ($status !== Comment::APPROVED) {
            echo '<option value="'.Comment::APPROVED.'">Approve</option>';
        }

        if (in_array($status, ['all', Comment::APPROVED])) {
            echo '<option value="'.Comment::PENDING.'">Unapprove</option>';
        }

        if (!in_array($status, [Comment::SPAM, Comment::TRASH])) {
            echo '<option value="'.Comment::SPAM.'">Mark as Spam</option>';
        }

        if (in_array($status, [Comment::SPAM, Comment::TRASH])) {
            echo'<option value="delete">Delete Permanently</option>';
        }

        if (in_array($status, ['all', Comment::APPROVED, Comment::PENDING])) {
            echo'<option value="'.Comment::TRASH.'">Move to Trash</option>';
        }
        ?>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Apply</button>
</div>

<!-- Comments table -->
<table class="table table-striped" id="comments">
    <thead>
        <tr>
            <th class="column-check"><input type="checkbox" class="mark-all" title="Mark all comments"></th>
            <th class="column-author">Author</th>
            <th class="column-comment">Comment</th>
            <th class="column-page">In Response To</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($paginator as $comment) { ?>
            <tr class="<?php echo $comment->status === Comment::PENDING && $status !== Comment::PENDING ? 'warning' : ''; ?>"
                data-id="<?php echo $comment->id; ?>"
            >
                <td>
                    <input type="checkbox" name="comments[]" value="<?php echo $comment->id; ?>" class="mark" title="Mark this comment">
                </td>

                <!-- Author column -->
                <td class="column-author">
                    <div>
                        <img src="<?php echo $comment->author_avatar; ?>" class="avatar">
                        <b><?php echo $comment->author_name; ?></b>
                        <small><?php echo $comment->user_id ? '(user)' : ''; ?></small>
                    </div>

                    <div>
                        <a href="mailto:<?php echo $comment->author_email; ?>" class="email">
                            <?php echo $comment->author_email; ?>
                        </a>
                    </div>

                    <?php if (!empty($comment->author_url)) { ?>
                        <div>
                            <a href="<?php echo $comment->author_url; ?>" target="_blank">
                                <?php echo $comment->author_url; ?>
                            </a>
                        </div>
                    <?php } ?>

                    <a href="http://whatismyipaddress.com/ip/<?php echo $comment->author_ip; ?>" target="_blank"
                       data-toggle="tooltip" data-original-title="<?php echo $comment->user_agent; ?>"
                    >
                        <?php echo $comment->author_ip; ?>
                    </a>
                </td>

                <!-- Comment column. -->
                <td class="column-comment">
                    <div class="submitted-on">
                        Submitted
                        <a href="#" title="<?php echo $comment->created_at->toIso8601String(); ?>">
                            <?php echo $comment->created_at->diffForHumans(); ?>
                        </a>
                        <?php if ($comment->parent) { ?>
                            in reply to <a href="<?php echo $comment->parent->permalink; ?>"><?php echo $comment->parent->author_name; ?></a>
                        <?php } ?>
                    </div>

                    <div class="content"><?php echo $comment->content; ?></div>

                    <!-- Row actions -->
                    <div class="row-actions">
                        <?php $spamOrTrash = in_array($status, [Comment::TRASH, Comment::SPAM]); ?>

                        <?php if (!$spamOrTrash) { ?>
                            <span <?php echo $comment->status !== Comment::APPROVED ? '' : 'style="display:none;"'; ?>>
                                <a href="#" class="approve">Approve</a> |
                            </span>

                            <span <?php echo $comment->status !== Comment::PENDING ? '' : 'style="display:none;"'; ?>>
                                <a href="#" class="unapprove">Unapprove</a> |
                            </span>

                            <a href="#!edit=<?php echo $comment->id; ?>" class="edit">Edit</a>
                            | <a href="#" class="spam">Spam</a>
                        <?php } else { ?>
                            <a href="#" class="approve not-spam">Approve</a>
                        <?php } ?>

                        <?php if ($spamOrTrash) { ?>
                            | <a href="#" class="delete">Delete Permanently</a>
                        <?php } else { ?>
                            | <a href="#" class="trash">Trash</a>
                        <?php } ?>
                    </div>
                </td>

                <!-- Comment page column. -->
                <td>
                    <a href="?page_id=<?php echo $comment->page_id; ?>" class="page-com-count">
                        <span class="label label-primary">
                            <?php echo isset($pageCount[$comment->page_id]) ? $pageCount[$comment->page_id] : 0; ?>
                        </span>
                    </a>
                    <a href="<?php echo $comment->permalink; ?>">View Page</a>
                </td>
            </tr>
        <?php } ?>
        <?php if (!$paginator->total()) { ?>
            <tr>
                <td colspan="4">No comments found.</td>
            </tr>
        <?php } ?>
    </tbody>
</table>
</form>

<div class="clearfix">
    <div class="pull-left"><?php echo $paginator->total(); ?> comment(s)</div>
    <div class="pull-right"><?php echo $paginator->render(); ?></div>
</div>

<?php require __DIR__.'/partials/edit-comment-modal.php'; ?>

<script>
    window.admin.initComments({
        pageId: "<?php echo $pageId; ?>",
        status: "<?php echo $status; ?>",
        csrfToken: "<?php echo csrf_token(); ?>",
    });
</script>

<?php admin_footer(); ?>
