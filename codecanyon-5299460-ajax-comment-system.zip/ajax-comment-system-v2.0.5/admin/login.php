<?php

define('LOGIN_PAGE', true);

require __DIR__.'/load.php';

$comments = Comments::getInstance();

if ($comments->adminCheck()) {
    redirect('index.php');
}

if (isset($_POST['login'])) {
    $success = $comments['events']->fire('admin.login', [
        isset($_POST['username']) ? trim($_POST['username']) : null,
        isset($_POST['password']) ? trim($_POST['password']) : null,
        isset($_POST['remember']),
    ]);

    if (reset($success)) {
        redirect('index.php');
    } else {
        $error = true;
    }
}
?>

<?php admin_header('Log in'); ?>

<div class="container">
    <div class="login">
        <?php if (isset($error)) { ?>
            <div class="error">Invalid credentials.</div>
        <?php } ?>

        <form action="" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" class="form-control">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control">
            </div>
            <div class="checkbox pull-left">
                <label><input type="checkbox" name="remember" value="1"> Remember me</label>
            </div>
            <div class="clearfix">
                <button type="submit" name="login" class="btn btn-primary pull-right">Log in</button>
            </div>
        </form>

        <a href="../index.php">&#8592; Back home</a>
    </div>
</div>

<?php admin_footer(); ?>
