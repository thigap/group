<?php

require __DIR__.'/load.php';

admin_update_options();

$config = $comments['config'];

$captcha = [
    0 => 'None',
    Comments::CAPTCHA_GUESTS => 'Guests',
    Comments::CAPTCHA_USERS  => 'Logged users',
    Comments::CAPTCHA_ALL    => 'All',
];

$sort = [
    Comments::SORT_NEWEST => 'Newest first',
    Comments::SORT_OLDEST => 'Oldest first',
    Comments::SORT_BEST   => 'Best first',
];

admin_header('General Settings', 'options-general');
?>

<div class="row">
    <div class="col-md-6">
        <?php admin_options_alert(); ?>
        <form action="" method="POST">
            <input type="hidden" name="group" value="general">

            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
            </div>

            <div class="form-group">
                <label for="debug">Debug Mode</label>
                <select name="debug" id="debug" class="form-control">
                    <option value="1" <?php echo $config['general.debug'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['general.debug'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">When the debug mode is enabled, detailed error messages will be shown on every error that occurs. If disabled, a simple generic error message is shown.</p>
            </div>

            <div class="form-group">
                <label for="csrf">CSRF Protection</label>
                <select name="csrf" id="csrf" class="form-control">
                    <option value="1" <?php echo $config['general.csrf'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['general.csrf'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">Protects the comment system from cross-site request forgeries.</p>
            </div>

            <div class="form-group">
                <label for="guest">Guest Comments</label>
                <select name="guest" id="guest" class="form-control">
                    <option value="1" <?php echo $config['general.guest'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['general.guest'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">Specify if guest users can leave comments.</p>
            </div>

            <div class="form-group">
                <label for="captcha">Captcha Level</label>
                <select name="captcha" id="captcha" class="form-control">
                    <?php foreach ($captcha as $val => $text) {
                        echo '<option value="'.$val.'" '.($config['general.captcha'] === $val ? 'selected' : '').'>'.$text.'</option>';
                    } ?>
                </select>
                <p class="help-block">Specify for which users captcha is enabled.</p>
            </div>

            <div class="form-group">
                <label for="notify_email">Admin Email Notifications</label>
                <input type="text" name="notify_email" id="notify_email" value="<?php echo $config['general.notify_email']; ?>" class="form-control">
                <p class="help-block">An email address to which notifications will be sent when a new comment is posted. Spam won't be reported.</p>
            </div>

            <div class="form-group">
                <label for="reply_email">Reply Email Notifications</label>
                <select name="reply_email" id="reply_email" class="form-control">
                    <option value="1" <?php echo $config['general.reply_email'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['general.reply_email'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">Specify if users should be notified when their comments receive replies.</p>
            </div>

            <div class="form-group">
                <label for="votes">Comment Votes</label>
                <select name="votes" id="votes" class="form-control">
                    <option value="1" <?php echo $config['general.votes'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['general.votes'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">Specify if authenticated users can vote.</p>
            </div>

            <div class="form-group">
                <label for="quick_edit">Quick Edit</label>
                <select name="quick_edit" id="quick_edit" class="form-control">
                    <option value="true" <?php echo $config['general.quick_edit'] === true ? 'selected' : ''; ?>>Always</option>
                    <option value="false" <?php echo $config['general.quick_edit'] === false ? 'selected':'' ?>>No</option>

                    <option value="60"  <?php echo $config['general.quick_edit'] === 60  ? 'selected':'' ?>>1 minute after posting</option>
                    <option value="120" <?php echo $config['general.quick_edit'] === 120 ? 'selected':'' ?>>2 minute after posting</option>
                    <option value="240" <?php echo $config['general.quick_edit'] === 240 ? 'selected':'' ?>>4 minute after posting</option>
                    <option value="480" <?php echo $config['general.quick_edit'] === 480 ? 'selected':'' ?>>8 minute after posting</option>
                </select>
                <p class="help-block">Specify if authenticated users can edit their comments.</p>
            </div>

            <div class="form-group">
                <label for="smilies">Comment Smilies</label>
                <select name="smilies" id="smilies" class="form-control">
                    <option value="1" <?php echo $config['general.smilies'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['general.smilies'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">Specify if you want to enable smilies. (See <code>config/smilies.php</code>)</p>
            </div>

            <div class="form-group">
                <label for="bbcode">BBCode</label>
                <select name="bbcode" id="bbcode" class="form-control">
                    <option value="1" <?php echo $config['general.bbcode'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['general.bbcode'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">Specify if comments should be parsed as <a href="https://en.wikipedia.org/wiki/BBCode" target="_blank">BBCode</a>.</p>
            </div>

            <div class="form-group">
                <label for="markdown">Markdown</label>
                <select name="markdown" id="markdown" class="form-control">
                    <option value="1" <?php echo $config['general.markdown'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['general.markdown'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">Specify if comments should be parsed as Markdown (<a href="https://help.github.com/articles/github-flavored-markdown" target="_blank">GitHub flavored</a>).</p>
            </div>

            <div class="form-group">
                <label for="clickable">Clickable Links</label>
                <select name="clickable" id="clickable" class="form-control">
                    <option value="1" <?php echo $config['general.clickable'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['general.clickable'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">Specify if the links in comments should be clickable.</p>
            </div>

            <div class="form-group">
                <label for="maxlength">Maximum Comment Length</label>
                <input type="text" name="maxlength" id="maxlength" value="<?php echo $config['general.maxlength']; ?>" class="form-control">
                <p class="help-block">The maximum comment length. To disable leave it empty.</p>
            </div>

            <div class="form-group">
                <label for="max_depth">Maximum Nested Depth</label>
                <input type="text" name="max_depth" id="max_depth" value="<?php echo $config['general.max_depth']; ?>" class="form-control">
                <p class="help-block">Specify the maximum nested depth. To disable leave it empty.</p>
            </div>

            <div class="form-group">
                <label for="per_page">Comments Per Page</label>
                <input type="text" name="per_page" id="per_page" value="<?php echo $config['general.per_page']; ?>" class="form-control">
                <p class="help-block">Specify the number of comments to bde displayed per page. To disable leave it empty.</p>
            </div>

            <div class="form-group">
                <label for="default_sort">Default Sort</label>
                <select name="default_sort" id="default_sort" class="form-control">
                    <?php foreach ($sort as $val => $text) {
                        echo '<option value="'.$val.'" '.($config['general.default_sort'] === $val ? 'selected' : '').'>'.$text.'</option>';
                    } ?>
                </select>
                <p class="help-block">Specify the default sorting.</p>
            </div>

            <div class="form-group">
                <label for="replies">Comment Replies</label>
                <select name="replies" id="replies" class="form-control">
                    <option value="1" <?php echo $config['general.replies'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['general.replies'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">Specify if comment replies are allowed.</p>
            </div>

            <div class="form-group">
                <label for="default_gravatar">Default Avatar Imageset</label>
                <select name="default_gravatar" id="default_gravatar" class="form-control">
                    <?php foreach (['404', 'mm', 'identicon', 'monsterid', 'wavatar'] as $set) { ?>
                        <option value="<?php echo $set; ?>" <?php echo $config['general.default_gravatar'] === $set ? 'selected' : ''; ?>><?php echo $set; ?></option>
                    <?php } ?>
                </select>
                <p class="help-block">Specify the default imageset to use for avatars.</p>
            </div>

            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
    </div>
</div>

<?php admin_footer(); ?>
