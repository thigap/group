<?php

require __DIR__.'/load.php';

admin_update_options();

$config = $comments['config'];

admin_header('Moderation Settings', 'options-moderation');
?>

<div class="row">
    <div class="col-md-6">
        <?php admin_options_alert(); ?>
        <form action="" method="POST">
            <input type="hidden" name="group" value="moderation">

            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
            </div>

            <div class="form-group">
                <label for="moderation">Comment Moderation</label>
                <select name="moderation" id="moderation" class="form-control">
                    <option value="1" <?php echo $config['moderation.moderation'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['moderation.moderation'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">Specify if all comments should be approved by a moderator.</p>
            </div>

            <div class="form-group">
                <label for="akismet">Akismet Spam Detection</label>
                <select name="akismet" id="akismet" class="form-control">
                    <option value="1" <?php echo $config['moderation.akismet'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['moderation.akismet'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">Make sure to set your API Key in the <a href="options-services.php">Services</a> Settings.</p>
            </div>

            <div class="form-group">
                <label for="moderation_keys">Moderation Keys</label>
                <textarea name="moderation_keys" id="moderation_keys" class="form-control" rows="4"><?php echo implode('\n', $config['moderation.moderation_keys']); ?></textarea>
                <p class="help-block">When a comment contains any of these words in its content, name, URL, e-mail, or IP, it will be held in the moderation queue. One word or IP per line.</p>
            </div>

            <div class="form-group">
                <label for="blacklist_keys">Blacklist Keys</label>
                <textarea name="blacklist_keys" id="blacklist_keys" class="form-control" rows="4"><?php echo implode('\n', $config['moderation.blacklist_keys']); ?></textarea>
                <p class="help-block">When a comment contains any of these words in its content, name, URL, e-mail, or IP, it will be marked as spam. One word or IP per line.</p>
            </div>

            <div class="form-group">
                <label for="time_between">Time Between Comments</label>
                <input type="text" name="time_between" id="time_between" value="<?php echo $config['moderation.time_between']; ?>" class="form-control">
                <p class="help-block">The number of seconds between comments to prevent comment flood. To disable leave it empty.</p>
            </div>

            <div class="form-group">
                <label for="duplicate">Duplicate Comment Detection</label>
                <select name="duplicate" id="duplicate" class="form-control">
                    <option value="1" <?php echo $config['moderation.duplicate'] ? 'selected' : ''; ?>>Yes</option>
                    <option value="0" <?php echo !$config['moderation.duplicate'] ? 'selected':'' ?>>No</option>
                </select>
                <p class="help-block">If enabled, duplicate comments on the same page and user are not allowed.</p>
            </div>

            <div class="form-group">
                <label for="max_pending">Maximum Pending Comments</label>
                <input type="text" name="max_pending" id="max_pending" value="<?php echo $config['moderation.max_pending']; ?>" class="form-control">
                <p class="help-block">Block comments form users that have to many unapproved comments. To disable leave it empty.</p>
            </div>

            <div class="form-group">
                <label for="max_links">Maximum Links</label>
                <input type="text" name="max_links" id="max_links" value="<?php echo $config['moderation.max_links']; ?>" class="form-control">
                <p class="help-block">Here you may specify if comments that contains too many links should be hold in the moderation queue. To disable leave it empty.</p>
            </div>

            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
    </div>
</div>

<?php admin_footer(); ?>
