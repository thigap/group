<?php

/**
 * Display admin header.
 *
 * @param string $title
 * @param string $activePage
 */
function admin_header($title = null, $activePage = null)
{
    include __DIR__.'/partials/header.php';
}

/**
 * Display admin footer.
 */
function admin_footer()
{
    include __DIR__.'/partials/footer.php';
}

/**
 * Display options alert.
 */
function admin_options_alert()
{
    include __DIR__.'/partials/alert.php';
}

/**
 * Update options.
 *
 * @return void
 */
function admin_update_options()
{
    if (!isset($_POST['submit'])) {
        return;
    }

    $config = Comments::config();

    $group = isset($_POST['group']) ? $_POST['group'] : null;

    switch ($group) {
        case 'general':
            $config['general.debug']     = (boolean) $_POST['debug'];
            $config['general.csrf']      = (boolean) $_POST['csrf'];
            $config['general.guest']     = (boolean) $_POST['guest'];
            $config['general.votes']     = (boolean) $_POST['votes'];
            $config['general.smilies']   = (boolean) $_POST['smilies'];
            $config['general.bbcode']    = (boolean) $_POST['bbcode'];
            $config['general.markdown']  = (boolean) $_POST['markdown'];
            $config['general.clickable'] = (boolean) $_POST['clickable'];
            $config['general.maxlength'] = empty($_POST['maxlength']) ? null : (int) $_POST['maxlength'];
            $config['general.max_depth'] = empty($_POST['max_depth']) ? null : (int) $_POST['max_depth'];
            $config['general.per_page']  = empty($_POST['per_page']) ? null : (int) $_POST['per_page'];
            $config['general.replies']   = (boolean) $_POST['replies'];
            $config['general.notify_email'] = trim(e($_POST['notify_email']));
            $config['general.reply_email']  = (boolean) $_POST['reply_email'];
            $config['general.default_gravatar'] = trim(e($_POST['default_gravatar']));

            if (in_array($_POST['captcha'], ['0', '1', '2', '3'])) {
                $config['general.captcha'] = (int) $_POST['captcha'];
            }

            if (in_array($_POST['default_sort'], ['1', '2', '3'])) {
                $config['general.default_sort'] = (int) $_POST['default_sort'];
            }

            if (is_numeric($_POST['quick_edit'])) {
                $config['general.quick_edit'] = (int) $_POST['quick_edit'];
            } else {
                $config['general.quick_edit'] = $_POST['quick_edit'] === 'true';
            }

            break;

        case 'moderation':
            $moderationKeys = explode('\n', $_POST['moderation_keys']);
            $blacklistKeys  = explode('\n', $_POST['blacklist_keys']);

            if (empty($moderationKeys[0])) {
                $moderationKeys = [];
            }

            if (empty($moderationKeys[0])) {
                $blacklistKeys = [];
            }

            $moderationKeys = array_map(function ($key) {
                return trim(e($key));
            }, $moderationKeys);

            $blacklistKeys = array_map(function ($key) {
                return trim(e($key));
            }, $blacklistKeys);

            $config['moderation.moderation']      = (boolean) $_POST['moderation'];
            $config['moderation.akismet']         = (boolean) $_POST['akismet'];
            $config['moderation.moderation_keys'] = $moderationKeys;
            $config['moderation.blacklist_keys']  = $blacklistKeys;
            $config['moderation.time_between']    = empty($_POST['time_between']) ? null : (int) $_POST['time_between'];
            $config['moderation.duplicate']       = (boolean) $_POST['duplicate'];
            $config['moderation.max_pending']     = empty($_POST['max_pending']) ? null : (int) $_POST['max_pending'];
            $config['moderation.max_links']       = empty($_POST['max_links']) ? null : (int) $_POST['max_links'];
            break;

        case 'mail':
            $drivers = ['smtp', 'mail', 'sendmail', 'mailgun', 'mandrill'];

            if (in_array($_POST['driver'], $drivers)) {
                $config['mail.driver'] = $_POST['driver'];
            }

            $config['mail.host'] = trim(e($_POST['host']));
            $config['mail.port'] = trim(e($_POST['port']));
            $config['mail.from'] = [
                'name'    => trim(e($_POST['from']['name'])),
                'address' => trim(e($_POST['from']['address'])),
            ];
            $config['mail.encryption'] = trim(e($_POST['encryption']));
            $config['mail.username'] = trim(e($_POST['username']));
            $config['mail.password'] = trim(e($_POST['password']));
            $config['mail.sendmail'] = trim(e($_POST['sendmail']));
            break;

        case 'services':
            $config['services.akismet_key'] = trim(e($_POST['akismet_key']));
            $config['services.mailgun'] = [
                'secret' => trim(e($_POST['mailgun']['secret'])),
                'domain' => trim(e($_POST['mailgun']['domain'])),
            ];
            $config['services.mandrill'] = [
                'secret' => trim(e($_POST['mandrill']['secret'])),
            ];
            break;
    }

    $config->save($group);

    redirect("options-$group.php#updated");
}
