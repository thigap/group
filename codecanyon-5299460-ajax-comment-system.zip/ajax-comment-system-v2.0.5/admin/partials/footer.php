<?php if (!defined('ACS')) exit('No direct script access allowed.');

$comments = Comments::getInstance();

if ($comments->adminCheck()) {
?>
    </div></div>
<?php }  ?>

</body></html>
