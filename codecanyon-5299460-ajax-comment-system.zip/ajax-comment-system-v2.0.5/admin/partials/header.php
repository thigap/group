<?php if (!defined('ACS')) exit('No direct script access allowed.');

$comments = Comments::getInstance();

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $title ? strip_tags($title).' | ' : '' ?>Admin | Ajax Comment System</title>
        <link rel="stylesheet" href="../assets/css/vendor/bootstrap.css">
        <link rel="stylesheet" href="../assets/css/demo.css">
        <link rel="stylesheet" href="../assets/css/admin.css">
        <script src="../assets/js/vendor/jquery.js"></script>
        <script src="../assets/js/vendor/bootstrap.js"></script>
        <script src="../assets/js/admin.js"></script>
        <script>
            <?php $ajaxurl = $comments['config']['general.ajaxurl']; ?>
            window.admin = new Admin({
                ajaxUrl: "<?php echo strpos($ajaxurl, 'http') === false ? '../'.$ajaxurl : $ajaxurl; ?>",
            });
        </script>
    </head>
    <body>
        <?php if ($comments->adminCheck()) { ?>
            <div class="navbar navbar-top">
                <div class="container">
                    <div class="col-md-11 col-md-offset-1">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a href="../" class="navbar-brand">Home</a>
                        </div>
                        <div class="navbar-collapse collapse">
                            <ul class="nav navbar-nav">
                                <li <?php echo $activePage === 'comments' ? 'class="active"' : ''; ?>>
                                    <a href="index.php"><span class="glyphicon glyphicon-comment"></span> Dashboard</a>
                                </li>
                                <li class="dropdown <?php echo strpos($activePage, 'options') !== false ? 'active' : ''; ?>">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <span class="glyphicon glyphicon-cog"></span>
                                        Settings
                                        <b class="caret"></b>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="options-general.php">General</a></li>
                                        <li><a href="options-moderation.php">Moderation</a></li>
                                        <li><a href="options-mail.php">Mail</a></li>
                                        <li><a href="options-services.php">Services</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="http://docs.hazzardweb.com/ajax-comment-system"><span class="glyphicon glyphicon-question-sign"></span> Documentation</a>
                                </li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">
                                <li>
                                    <a href="?logout"><span class="glyphicon glyphicon-log-out"></span> Log out</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container">
                <div id="admin" class="col-md-11 col-md-offset-1">
                    <h3 class="page-header">
                        <?php echo $title; ?>
                    </h3>
        <?php }
