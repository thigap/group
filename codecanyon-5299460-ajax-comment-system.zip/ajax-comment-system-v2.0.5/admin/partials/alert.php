<?php if (!defined('ACS')) exit('No direct script access allowed.');

if (!Comments::config() instanceof ACS\Options\Repository) {
    ?>
    <div class="alert alert-danger">
        The Options driver is not enabled!
        <a href="http://docs.hazzardweb.com/ajax-comment-system/2.0/configuration#admin-settings">Help!</a>
    </div>

    <script>
        jQuery(document).ready(function($) {
            $('form').find('input, select, button, textarea').prop('disabled', true);
        });
    </script>
    <?php
} else { ?>
    <div class="alert alert-success hidden">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        Your changes have been saved.
    </div>

    <script>
        jQuery(document).ready(function($) {
            if (window.location.hash === '#updated') {
                $('.alert').removeClass('hidden');
            }

            $('.alert').on('closed.bs.alert', function() {
                window.location.hash = '';
            });
        });
    </script>
<?php }
