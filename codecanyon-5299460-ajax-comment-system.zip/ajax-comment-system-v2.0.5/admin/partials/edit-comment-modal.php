<?php if (!defined('ACS')) exit('No direct script access allowed.'); ?>

<div class="modal fade" id="edit-comment-modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="POST" class="edit-form">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="approved">
                <input type="hidden" name="page_id" value="<?php echo $pageId; ?>">
                <input type="hidden" name="id">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">&times;</button>
                    <h4 class="modal-title">Edit comment</h4>
                </div>
                <div class="modal-body">
                    <div class="alert"></div>

                    <div class="form-group">
                        <label for="author_name">Author Name</label>
                        <input type="text" name="author_name" id="author_name" class="form-control guest">
                    </div>
                    <div class="form-group">
                        <label for="author_email">Author Email</label>
                        <input type="text" name="author_email" id="author_email" class="form-control guest">
                    </div>
                    <div class="form-group">
                        <label for="author_url">Author Url</label>
                        <input type="text" name="author_url" id="author_url" class="form-control guest">
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select name="status" id="status" class="form-control">
                            <?php foreach ($statuses as $key) {
                                echo '<option value="'.$key.'">'.ucfirst($key).'</option>';
                            } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="content">Comment</label>
                        <textarea name="content" id="content" class="form-control"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
