<?php

require_once __DIR__.'/../comments/start.php';
require_once __DIR__.'/functions.php';

$comments = Comments::getinstance();

if (isset($_GET['logout'])) {
    $comments->events->fire('admin.logout');

    redirect('index.php');
}

if (!$comments->adminCheck() && !defined('LOGIN_PAGE')) {
    redirect('login.php');
}
