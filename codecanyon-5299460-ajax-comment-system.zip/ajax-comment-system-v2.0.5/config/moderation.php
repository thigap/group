<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Comment Moderation
    |--------------------------------------------------------------------------
    |
    | Here you may specify if all comments should be approved by a moderator.
    |
    */

    'moderation' => false,

    /*
    |--------------------------------------------------------------------------
    | Akismet Spam Detection
    |--------------------------------------------------------------------------
    |
    | Here you may enable Akismet for spam detection.
    | ! Make sure to set your API Key in services.php.
    |
    */

    'akismet' => false,

    /*
    |--------------------------------------------------------------------------
    | Moderation Keys
    |--------------------------------------------------------------------------
    |
    | When a comment contains any of these words in its content, name, URL,
    | e-mail, or IP, it will be held in the moderation queue.
    |
    */

    'moderation_keys' => [],

    /*
    |--------------------------------------------------------------------------
    | Blacklist Keys
    |--------------------------------------------------------------------------
    |
    | When a comment contains any of these words in its content, name, URL,
    | e-mail, or IP, it will be marked as spam.
    |
    */

    'blacklist_keys' => [],

    /*
    |--------------------------------------------------------------------------
    | Time Between Comments
    |--------------------------------------------------------------------------
    |
    | The number of seconds between comments to prevent comment flood.
    | Set null to disable.
    |
    */

    'time_between' => null,

    /*
    |--------------------------------------------------------------------------
    | Duplicate Comment Detection
    |--------------------------------------------------------------------------
    |
    | If enabled, duplicate comments on the same page and user are not allowed.
    |
    */

    'duplicate' => true,

    /*
    |--------------------------------------------------------------------------
    | Maximum Pending Comments
    |--------------------------------------------------------------------------
    |
    | Block comments form users that have to many unapproved comments.
    | To disable set null.
    |
    */

    'max_pending' => null,

    /*
    |--------------------------------------------------------------------------
    | Maximum Links
    |--------------------------------------------------------------------------
    |
    | Here you may specify if comments that contains too many links should be
    | hold in the moderation queue. To disable set null.
    |
    */

    'max_links' => null,
];
