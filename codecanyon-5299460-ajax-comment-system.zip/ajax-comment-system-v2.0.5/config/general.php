<?php

use ACS\Comments\Comment;
use ACS\Comments\Comments;

return [

    /*
    |--------------------------------------------------------------------------
    | Debug Mode
    |--------------------------------------------------------------------------
    |
    | When the debug mode is enabled, detailed error messages with
    | stack traces will be shown on every error that occurs.
    | If disabled, a simple generic error message is shown.
    |
    */

    'debug' => false,

    /*
    |--------------------------------------------------------------------------
    | CSRF Protection
    |--------------------------------------------------------------------------
    |
    | Protects the comment system from cross-site request forgeries.
    |
    */

    'csrf' => true,

    /*
    |--------------------------------------------------------------------------
    | Encryption Key
    |--------------------------------------------------------------------------
    |
    | This key is used by the encrypt/decrypt cookies and should be set
    | to a random, 32 character string.
    |
    */

    'key'    => '',
    'cipher' => 'AES-256-CBC',

    /*
    |--------------------------------------------------------------------------
    | User Model
    |--------------------------------------------------------------------------
    |
    | The Eloquent model used by the comments and authentication driver.
    | If you already have a "users" table you can specify another model here.
    | If not specified only guests will be able to comment.
    |
    */

    'user_model' => 'ACS\User',

    /*
    |--------------------------------------------------------------------------
    | Guest Comments
    |--------------------------------------------------------------------------
    |
    | Specify if guest users can leave comments.
    |
    */

    'guest' => true,

    /*
    |--------------------------------------------------------------------------
    | Captcha Level
    |--------------------------------------------------------------------------
    |
    | Specify for which users captcha is enabled.
    |
    | Comments::CAPTCHA_GUESTS - Guest users
    | Comments::CAPTCHA_USERS  - Logged in users
    | Comments::CAPTCHA_ALL    - All users
    |
    | Set false to disable.
    |
    */

    'captcha' => Comments::CAPTCHA_GUESTS,

    /*
    |--------------------------------------------------------------------------
    | Admin Email Notifications
    |--------------------------------------------------------------------------
    |
    | An email address to which notifications will be sent
    | when a new comment is posted. Spam won't be reported.
    |
    */

    'notify_email' => null,

    /*
    |--------------------------------------------------------------------------
    | Reply Email Notifications
    |--------------------------------------------------------------------------
    |
    | Specify if users should be notified when their comments receive replies.
    |
    */

    'reply_email' => false,

    /*
    |--------------------------------------------------------------------------
    | Comment Votes
    |--------------------------------------------------------------------------
    |
    | Specify if authenticated users can vote.
    |
    */

    'votes' => true,

    /*
    |--------------------------------------------------------------------------
    | Quick Edit
    |--------------------------------------------------------------------------
    |
    | Specify if authenticated users can edit their comments.
    |
    | false   - Users can't edit comments.
    | true    - Users cant edit comments anytime.
    | numeric - Users can edit comments for the sepecified number of seconds.
    |
    */

    'quick_edit' => 120,

    /*
    |--------------------------------------------------------------------------
    | Comment Smilies
    |--------------------------------------------------------------------------
    |
    | Specify if you want to enable smilies. See smilies.php.
    |
    */

    'smilies' => false,

    /*
    |--------------------------------------------------------------------------
    | BBCode
    |--------------------------------------------------------------------------
    |
    | Specify if comments should be parsed as BBCode.
    | https://en.wikipedia.org/wiki/BBCode
    |
    */

    'bbcode' => false,

    /*
    |--------------------------------------------------------------------------
    | Markdown (GitHub flavored)
    |--------------------------------------------------------------------------
    |
    | Specify if comments should be parsed as Markdown.
    | https://help.github.com/articles/github-flavored-markdown/
    |
    */

    'markdown' => false,

    /*
    |--------------------------------------------------------------------------
    | Clickable Links
    |--------------------------------------------------------------------------
    |
    | Specify if the links in comments should be clickable.
    |
    */

    'clickable' => true,

    /*
    |--------------------------------------------------------------------------
    | Maximum Comment Length
    |--------------------------------------------------------------------------
    |
    | Specify the maximum comment length. To disable set null.
    |
    */

    'maxlength' => 500,

    /*
    |--------------------------------------------------------------------------
    | Maximum Nested Depth
    |--------------------------------------------------------------------------
    |
    | Specify the maximum nested depth. To disable set null.
    |
    */

    'max_depth' => null,

    /*
    |--------------------------------------------------------------------------
    | Comments Per Page
    |--------------------------------------------------------------------------
    |
    | Specify the number of comments to be displayed per page.
    |
    */

    'per_page' => 15,

    /*
    |--------------------------------------------------------------------------
    | Default Comment Sort
    |--------------------------------------------------------------------------
    |
    | Comments::SORT_NEWEST - Newest first
    | Comments::SORT_OLDEST - Oldest first
    | Comments::SORT_BEST   - Best first
    |
    */

    'default_sort' => Comments::SORT_NEWEST,

    /*
    |--------------------------------------------------------------------------
    | Comment Replies
    |--------------------------------------------------------------------------
    |
    | Specify if comment replies are allowed.
    |
    */

    'replies' => true,

    /*
    |--------------------------------------------------------------------------
    | Default Avatar Imageset
    |--------------------------------------------------------------------------
    |
    | Specify the default imageset to use for avatars.
    |
    | Supported: "404", "mm", "identicon", "monsterid", "wavatar"
    |
    */

    'default_gravatar' => 'monsterid',

    /*
    |--------------------------------------------------------------------------
    | Ajax File URL
    |--------------------------------------------------------------------------
    |
    | The URL to the ajax file.
    |
    */

    'ajaxurl' => 'comments/ajax.php',
];
