<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Mail Driver
    |--------------------------------------------------------------------------
    |
    | Supported: "smtp", "mail", "sendmail", "mailgun", "mandrill"
    |
    | For "mailgun" and "mandrill" set the API keys in services.php.
    |
    */

    'driver' => 'smtp',

    /*
    |--------------------------------------------------------------------------
    | SMTP Host Address
    |--------------------------------------------------------------------------
    |
    | The host address of the SMTP server.
    |
    */

    'host' => 'smtp.mailgun.org',

    /*
    |--------------------------------------------------------------------------
    | SMTP Host Port
    |--------------------------------------------------------------------------
    |
    | The SMTP port used by your application to deliver e-mails.
    |
    */

    'port' => 587,

    /*
    |--------------------------------------------------------------------------
    | Global "From" Address
    |--------------------------------------------------------------------------
    |
    | The name and address that is used globally for all e-mails.
    |
    */

    'from' => ['address' => null, 'name' => null],

    /*
    |--------------------------------------------------------------------------
    | E-Mail Encryption Protocol
    |--------------------------------------------------------------------------
    |
    | The encryption protocol that should be used when sending e-mails.
    |
    */

    'encryption' => 'tls',

    /*
    |--------------------------------------------------------------------------
    | SMTP Server Username
    |--------------------------------------------------------------------------
    |
    | If your SMTP server requires a username for authentication set it here.
    | You may also set the "password" value below this one.
    |
    */

    'username' => '',

    /*
    |--------------------------------------------------------------------------
    | SMTP Server Password
    |--------------------------------------------------------------------------
    |
    | The password required by your SMTP server.
    |
    */

    'password' => '',

    /*
    |--------------------------------------------------------------------------
    | Sendmail System Path
    |--------------------------------------------------------------------------
    |
    | Required when using the "sendmail" driver to send e-mails.
    |
    */

    'sendmail' => '/usr/sbin/sendmail -bs',
];
