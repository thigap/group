<?php

return [

    // https://github.com/laravel/laravel/blob/master/resources/lang/en/validation.php

    'confirmed'  => 'The :attribute confirmation does not match.',
    'email'      => 'The :attribute must be a valid email address.',
    'exists'     => 'The selected :attribute is invalid.',
    'in'         => 'The selected :attribute is invalid.',
    'integer'    => 'The :attribute must be an integer.',
    'max'        => [
        'string' => 'The :attribute may not be greater than :max characters.',
    ],
    'min'        => [
        'string' => 'The :attribute must be at least :min characters.',
    ],
    'numeric'    => 'The :attribute must be a number.',
    'required'   => 'The :attribute field is required.',
    'unique'     => 'The :attribute has already been taken.',
    'url'        => 'The :attribute format is invalid.',

    'custom' => [
        'root_id' => [
            'exists' => 'You can\'t reply to a comment that is awaiting moderation.',
        ],
        'parent_id' => [
            'exists' => 'You can\'t reply to a comment that is awaiting moderation.',
        ],
        'captcha' => [
            'captcha' => 'The :attribute field is invalid.',
        ],
        'content' => [
            'flood'       => 'You are posting comments too quickly. Slow down.',
            'duplicate'   => 'Duplicate comment detected; it looks as though you\'ve already said that!',
            'max_pending' => 'You have too many unapproved comments. Wait until some are approved.',
        ]
    ],

    'attributes' => [
        'content'      => 'comment',
        'captcha'      => 'captcha',
        'author_name'  => 'name',
        'author_email' => 'email',
        'author_url'   => 'url',
    ],
];
