Go to http://docs.hazzardweb.com/ajax-comment-system to get started.

====================================================================

Thank you for purchasing my script!
Don't forget to rate!

HazzardWeb
hazzardweb@gmail.com
