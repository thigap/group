<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ajax Comment System</title>
    <style>
        body { font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; font-size: 14px; }
        a { color: #337ab7; text-decoration: none; }
        #demo { max-width: 800px; padding: 10px; margin: 0 auto; }
    </style>

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap-custom.css">
    <link rel="stylesheet" href="assets/css/vendor/prism-okaidia.css">
    <link rel="stylesheet" href="assets/css/comments.css">

    <!-- JavaScript -->
    <script src="assets/js/vendor/jquery.js"></script>
    <script src="assets/js/vendor/bootstrap.js"></script>
    <script src="assets/js/bundle.js"></script>
</head>
<body>
    <div id="demo">
        <a href="index.php">Home</a> |
        <a href="admin/index.php">Admin</a> |

        <!-- Init file. -->
        <?php require __DIR__.'/comments/start.php'; ?>

        <!-- Basic auth. -->
        <?php if (Auth::check()) { ?>
            Logged as <a href="user.php"><?php echo Auth::user()->name; ?></a> |
            <a href="user.php?action=logout">Logout</a>
        <?php } else { ?>
            <a href="user.php?action=login">Log in</a> |
            <a href="user.php?action=signup">Sign up</a>
        <?php } ?>

        <p>This examples does not require the full Bootstrap framework. <br> It only requires a custom Bootstrap CSS file, which does not conflict with the rest of your CSS.</p>

        <!-- Display comments. -->
        <?php Comments::render('page2'); ?>
    </div>
</body>
</html>
