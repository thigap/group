<?php

use ACS\Auth\Hasher;
use ACS\Support\Captcha;
use Illuminate\Support\MessageBag;

require __DIR__.'/comments/start.php';

$errors = new MessageBag;
$comments = Comments::getInstance();
$validator = $comments['validator'];

$rules = [
    'name'     => 'required|max:100',
    'email'    => 'required|email|max:255|unique:users,email',
    'password' => 'required|confirmed|min:6',
];

$action = isset($_GET['action']) ? $_GET['action'] : 'account';

if (isset($_POST['submit'])) {
    if ($comments->config['general.csrf'] !== false && !$comments['csrf']->verifyToken()) {
        $errors->add('csrf', 'CSRF Token Mismatch Error.');
    } else {
        switch ($action) {
            case 'login':
                if (Auth::check()) redirect('index.php');

                $credentials = ['email' => $_POST['email'], 'password' => $_POST['password']];

                if (Auth::attempt($credentials, isset($_POST['remember']))) {
                    redirect('index.php');
                } else {
                    $errors->add('error', 'Invalid credentials.');
                }

                break;

            case 'signup':
                if (Auth::check()) redirect('index.php');

                $rules['captcha'] = 'required|captcha';

                $validator = $validator->make($_POST, $rules);

                if ($validator->passes()) {
                    $_POST['name'] = trim(e($_POST['name']));
                    $_POST['password'] = Hasher::make($_POST['password']);

                    $user = Auth::createModel()->create($_POST);

                    Auth::login($user);

                    redirect('index.php');
                }

                $errors = $validator->errors();

                break;

            case 'account':
                if (!Auth::check()) redirect('?action=login');

                $rules['email'] .= ',' . Auth::user()->id;

                if (empty($_POST['password'])) {
                    unset($rules['password']);
                }

                $validator = $validator->make($_POST, $rules);

                if ($validator->fails()) {
                    $errors = $validator->errors();
                }

                if (!$errors->has('name')) {
                    Auth::user()->name = trim(e($_POST['name']));
                }

                if (!$errors->has('email')) {
                    Auth::user()->email = $_POST['email'];
                }

                if (isset($rules['password']) && !$errors->has('password')) {
                    Auth::user()->password = Hasher::make($_POST['password']);
                }

                Auth::user()->save();

                break;
        }
    }
}

$comments['captcha']->refresh();

function validation_errors()
{
    global $errors;

    if ($errors->isEmpty()) {
        if (isset($_POST['submit'])) {
            ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                Your changes have been saved.
            </div>
            <?php
        }

        return;
    }
    ?>
    <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <ul>
        <?php foreach ($errors->all('<li>:message</li>') as $message) {
            echo $message;
        } ?>
        </ul>
    </div>
    <?php
}

if ($action === 'logout') {
    Auth::logout();

    redirect('index.php');
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User | Ajax Comment System</title>
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.css">
    <link rel="stylesheet" href="assets/css/demo.css">
    <style>
        form { max-width: 400px; }
        .alert ul { padding-left: 15px; }
        .captcha .input-group-addon {
            padding: 0 0 0 3px;
            background: none;
            border: none;
        }
        .captcha img {
            cursor: pointer;
            border-radius: 2px;
        }
    </style>
    <script src="assets/js/vendor/jquery.js"></script>
    <script src="assets/js/vendor/bootstrap.js"></script>
    <script>
        window.refreshCaptcha = function(image) {
            $.post("<?php echo $comments['config']['general.ajaxurl']; ?>", {
                action: 'captcha',
                _token: "<?php echo csrf_token(); ?>",
            }, function(src) {
                image.src = src;
            });
        }
    </script>
</head>
<body>
    <?php require __DIR__.'/comments/views/demo-nav.php'; ?>

    <div class="container">
        <div id="demo" class="col-md-9 col-md-offset-2">
            <?php if (Auth::check()) { ?>
                <a href="?action=logout" class="pull-right">Log out</a>
            <?php } ?>
            <?php
            switch ($action) {
                case 'login':
                    if (Auth::check()) redirect('index.php');
                    ?>
                    <h3>Log in</h3>
                    <?php validation_errors(); ?>
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" name="email" id="email" class="form-control" value="<?php echo e(@$_POST['email']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" id="password" class="form-control">
                        </div>
                        <div class="checkbox">
                            <label><input type="checkbox" name="remember" value="1"> Remember me</label>
                          </div>
                        <div class="form-group">
                            <button type="submit" name="submit" class="btn btn-primary">Log in</button>
                        </div>
                    </form>
                    <p>Don't have an account? <a href="?action=signup">Sign up</a></p>
                    <?php
                    break;

                case 'signup':
                    if (Auth::check()) redirect('index.php');
                    ?>
                    <h3>Sign up</h3>
                    <?php validation_errors(); ?>
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" id="name" class="form-control" value="<?php echo e(@$_POST['name']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" name="email" id="email" class="form-control" value="<?php echo e(@$_POST['email']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" id="password" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="password_confirmation">Password Confirmation</label>
                            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="captcha">Captcha</label>
                            <div class="input-group captcha">
                                <input type="text" name="captcha" id="captcha" class="form-control" autocomplete="off">
                                <span class="input-group-addon">
                                    <img src="<?php echo $comments['captcha']->image(); ?>" title="Refresh" onclick="refreshCaptcha(this)">
                                </span>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" name="submit" class="btn btn-primary">Sign up</button>
                        </div>
                    </form>
                    <p>Alread have an account? <a href="?action=login">Log in</a></p>
                    <?php
                    break;

                case 'account':
                    if (!Auth::check()) redirect('?action=login');
                    ?>
                    <h3>Account Settings</h3>
                    <?php validation_errors(); ?>
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" id="name" class="form-control" value="<?php echo Auth::user()->name; ?>">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" name="email" id="email" class="form-control" value="<?php echo Auth::user()->email; ?>">
                        </div>
                        <div class="form-group">
                            <label for="password">New Password</label>
                            <input type="password" name="password" id="password" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="password_confirmation">New Password Confirmation</label>
                            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
                        </div>
                        <div class="form-group">
                            <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                    <?php
                    break;
            }
            ?>
        </div>
    </div>
</body>
</html>
